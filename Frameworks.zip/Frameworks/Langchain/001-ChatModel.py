from dotenv import load_dotenv
from langchain.chat_models import init_chat_model

load_dotenv()

model = init_chat_model(
    "anthropic:claude-haiku-4-5",
    temperature=0
)

response = model.invoke("Explain Arrow file format.")
print(response.content)
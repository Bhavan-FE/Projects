from dotenv import load_dotenv
load_dotenv()

from langchain.chat_models import init_chat_model

model = init_chat_model("anthropic:claude-haiku-4-5")
from pydantic import BaseModel, Field
from langchain.chat_models import init_chat_model

class MovieReview(BaseModel):
    title: str = Field(description="The movie's title")
    rating: int = Field(description="Score from 1 to 10")
    summary: str = Field(description="One-sentence summary")

model = init_chat_model("anthropic:claude-haiku-4-5")
structured_model = model.with_structured_output(MovieReview)

result = structured_model.invoke("Review the movie Inception.")
print(result.title, result.rating)   # typed Python object, not a string
print(type(result))                  # <class '__main__.MovieReview'>

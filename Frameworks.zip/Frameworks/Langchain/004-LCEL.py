from dotenv import load_dotenv
load_dotenv()

from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain.chat_models import init_chat_model

prompt = ChatPromptTemplate.from_messages([
    ("system", "You are a concise tutor."),
    ("user", "Explain {topic} in one sentence."),
])

model = init_chat_model("anthropic:claude-haiku-4-5")
parser = StrOutputParser()

chain = prompt | model | parser

print(chain.invoke({"topic": "Pickle File format"}))
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_openai import OpenAIEmbeddings
from langchain_core.vectorstores import InMemoryVectorStore
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_core.documents import Document
from langchain.chat_models import init_chat_model
from dotenv import load_dotenv
load_dotenv()

# Load file
with open("FrameworkShortNotes.txt", "r", encoding="utf-8") as file:
    text = file.read()

# Convert to Document
docs = [Document(page_content=text)]

# Split
splitter = RecursiveCharacterTextSplitter(
    chunk_size=1000,
    chunk_overlap=150
)

chunks = splitter.split_documents(docs)

print(f"Loaded {len(docs)} docs, split into {len(chunks)} chunks")

# Embeddings & Vector Store
vectorstore = InMemoryVectorStore.from_documents(
    chunks,
    OpenAIEmbeddings()
)

retriever = vectorstore.as_retriever(search_kwargs={"k": 4})

print(
    f"Loaded {len(docs)} docs, split into {len(chunks)} chunks, "
    f"stored in {vectorstore.__class__.__name__}"
)

# Prompt
prompt = ChatPromptTemplate.from_messages([
    (
        "system",
        "Answer using ONLY the context below. "
        "If unsure, say you don't know.\n\nContext:\n{context}"
    ),
    ("user", "{question}")
])

# Model
model = init_chat_model(
    model="gpt-4o-mini",
    model_provider="openai"
)

def format_docs(docs):
    return "\n\n".join(doc.page_content for doc in docs)

# RAG Chain
rag_chain = (
    {
        "context": retriever | format_docs,
        "question": lambda x: x
    }
    | prompt
    | model
    | StrOutputParser()
)

response = rag_chain.invoke(
    "Share key points on LangChain, CrewAI, AutoGen"
)

print(response)
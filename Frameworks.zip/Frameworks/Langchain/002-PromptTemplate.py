from langchain_core.prompts import ChatPromptTemplate

prompt = ChatPromptTemplate.from_messages([
    ("system", "You are a concise tutor. Answer in exactly one sentence."),
    ("user", "Explain {topic} to a {audience}."),
])

messages = prompt.invoke({"topic": "Arrow File Format", "audience": "Final Year Engineering Graduates"})
print(messages)  # a structured list of messages, ready to send to a model
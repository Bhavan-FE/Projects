from dotenv import load_dotenv
load_dotenv()

from functools import wraps
from langchain.agents import create_agent
from langchain.tools import tool
from langchain.chat_models import init_chat_model

# Create model
model = init_chat_model("anthropic:claude-haiku-4-5")

call_count = {"count": 0}


def logging_middleware(func):
    """Wraps a tool to log its calls."""

    @wraps(func)
    def wrapper(*args, **kwargs):
        call_count["count"] += 1

        print(
            f"[Tool call #{call_count['count']}] "
            f"{func.__name__}({args}, {kwargs})"
        )

        result = func(*args, **kwargs)

        print(f"[Result] {result}")

        return result

    return wrapper


@tool
@logging_middleware
def add(a: float, b: float) -> float:
    """Add two numbers together."""
    return a + b


@tool
@logging_middleware
def subtract(a: float, b: float) -> float:
    """Subtract two numbers."""
    return a - b


math_agent = create_agent(
    model=model,
    tools=[add, subtract],
    system_prompt="You are a math helper. Use tools for calculations.",
)

original_invoke = math_agent.invoke


def invoke_with_logging(input_data, config=None):
    question = input_data.get("messages", [{}])[-1].get("content", "")

    print(f"\n[Input] {question}")

    result = original_invoke(input_data, config)

    print(f"\n[Output] {result['messages'][-1].content}")

    return result


math_agent.invoke = invoke_with_logging

result = math_agent.invoke(
    {
        "messages": [
            {
                "role": "user",
                "content": "What's 100 minus 37?"
            }
        ]
    }
)

print("\nFinal answer:")
print(result["messages"][-1].content)
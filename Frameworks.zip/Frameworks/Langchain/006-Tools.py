from dotenv import load_dotenv
load_dotenv()
from langchain.agents import create_agent
from langchain.tools import tool

@tool
def get_weather(city: str) -> str:
    """Get the current weather for a given city."""
    return f"It's 22°C and sunny in {city}."

@tool
def multiply(a: float, b: float) -> float:
    """Multiply two numbers together."""
    return a * b

agent = create_agent(
    model="anthropic:claude-haiku-4-5",
    tools=[get_weather, multiply],
    system_prompt="You are a helpful assistant. Use tools when they help.",
)

result = agent.invoke({"messages": [{"role": "user", "content": "What's the weather in Tokyo, and what's 23 times 7?"}]})
print(result["messages"][-1].content)
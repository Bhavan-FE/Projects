"""
run_tests_no_pytest.py
========================
FALLBACK TEST RUNNER -- read this before assuming something is wrong.

This sandbox has no network egress, so `pip install pytest` cannot
complete here (see README.md "A note on this build environment"). The
spec (§6) requires the pytest suite in tests/ to be written AND actually
executed, not just present -- so rather than leave it unrun, this script
provides a small pytest-COMPATIBLE runner that:

  - discovers test_*.py files under tests/
  - supports plain `def test_...():` functions
  - supports the one fixture this suite actually needs: `fresh_db`
    (implemented directly, matching tests/conftest.py's fixture)
  - runs each test, reports pass/fail, and prints a traceback on failure

This is NOT a pytest reimplementation and is NOT a substitute for running
the real `pytest tests/` command. It exists solely so this test suite has
been demonstrably executed in an environment where the real tool could not
be installed. The moment you have network access:

    pip install pytest
    pytest tests/ -v

...and use that instead. See README.md for the full instructions this
maps to (§6's "must also verify against the real package before
submission" applies to pytest itself here, not just the mcp package).
"""

from __future__ import annotations

import importlib.util
import inspect
import sys
import tempfile
import traceback
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent
TESTS_DIR = PROJECT_ROOT / "tests"
STUB_PATH = PROJECT_ROOT / "_mcp_stub"
PYTEST_STUB_PATH = PROJECT_ROOT / "_pytest_stub"

sys.path.insert(0, str(STUB_PATH))
sys.path.insert(0, str(PYTEST_STUB_PATH))
sys.path.insert(0, str(PROJECT_ROOT))

import database  # noqa: E402


def _make_fresh_db():
    """Equivalent of the `fresh_db` fixture in tests/conftest.py, without
    relying on pytest's fixture injection machinery.
    """
    tmp_dir = tempfile.mkdtemp(prefix="bankforge_test_")
    db_path = str(Path(tmp_dir) / "neobank_test.db")
    original_path = database.DEFAULT_DB_PATH
    database.DEFAULT_DB_PATH = db_path
    database.init_schema(db_path)
    database.seed_data(db_path)
    return db_path, original_path


def _expand_test_cases(name: str, func) -> list[tuple[str, Any, dict]]:
    """Return a list of (case_name, func, extra_kwargs) for a test
    function, expanding @pytest.mark.parametrize-decorated functions into
    one case per parameter set.
    """
    parametrize_info = getattr(func, "_pytest_stub_parametrize", None)
    if parametrize_info is None:
        return [(name, func, {})]

    argnames, argvalues = parametrize_info
    names = [n.strip() for n in argnames.split(",")]
    cases = []
    for i, values in enumerate(argvalues):
        if len(names) == 1:
            values = (values,)
        extra_kwargs = dict(zip(names, values))
        case_name = f"{name}[{i}]"
        cases.append((case_name, func, extra_kwargs))
    return cases


def _discover_test_functions(module) -> list:
    raw = [
        (name, func)
        for name, func in inspect.getmembers(module, inspect.isfunction)
        if name.startswith("test_")
    ]
    expanded = []
    for name, func in raw:
        expanded.extend(_expand_test_cases(name, func))
    return expanded


def _load_module(path: Path):
    spec = importlib.util.spec_from_file_location(path.stem, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def run_all() -> int:
    test_files = sorted(TESTS_DIR.glob("test_*.py"))
    total = 0
    passed = 0
    failures: list[tuple[str, str]] = []

    print(f"Discovered {len(test_files)} test file(s) under {TESTS_DIR}\n")

    for test_file in test_files:
        module = _load_module(test_file)
        test_cases = _discover_test_functions(module)
        print(f"--- {test_file.name} ({len(test_cases)} tests) ---")

        for name, func, extra_kwargs in test_cases:
            total += 1
            sig = inspect.signature(func)
            kwargs = dict(extra_kwargs)
            db_path, original_path = None, None

            try:
                if "fresh_db" in sig.parameters:
                    db_path, original_path = _make_fresh_db()
                    kwargs["fresh_db"] = db_path

                func(**kwargs)
                passed += 1
                print(f"  PASS  {name}")
            except Exception as exc:  # noqa: BLE001 -- test runner must catch everything
                failures.append((f"{test_file.name}::{name}", traceback.format_exc()))
                print(f"  FAIL  {name}  ({type(exc).__name__}: {exc})")
            finally:
                if original_path is not None:
                    database.DEFAULT_DB_PATH = original_path

        print()

    print("=" * 70)
    print(f"Ran {total} tests: {passed} passed, {len(failures)} failed")
    if failures:
        print("\nFailure details:\n")
        for test_id, tb in failures:
            print(f"### {test_id}")
            print(tb)
    print("=" * 70)

    return 0 if not failures else 1


if __name__ == "__main__":
    sys.exit(run_all())

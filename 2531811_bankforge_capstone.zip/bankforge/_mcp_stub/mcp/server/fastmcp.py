"""
_mcp_stub/mcp/server/fastmcp.py
================================
A minimal, local stand-in for `mcp.server.fastmcp.FastMCP`.

WHY THIS EXISTS
----------------
This sandbox has no network egress, so the real `mcp` package (published on
PyPI) cannot be installed or imported here. The BankForge spec explicitly
permits a test-only stub during development (§6) but requires verification
against the real package before submission.

This stub mirrors the real FastMCP's public surface closely enough that
none of accounts_server/products_server/compliance_comms_server code needs
to change when the real package becomes available:

    from mcp.server.fastmcp import FastMCP
    mcp = FastMCP("accounts_server")

    @mcp.tool()
    def get_account_summary(...): ...

    @mcp.resource("account://{account_id}/summary")
    def account_summary_resource(...): ...

    @mcp.prompt()
    def transaction_analysis_prompt(...): ...

    mcp.run()   # starts the real server; here it's a no-op-ish local shim

TO SWITCH TO THE REAL PACKAGE
------------------------------
1. In an environment with network access: `pip install mcp`
2. Remove `_mcp_stub` from PYTHONPATH / sys.path (see README.md "Switching
   from the stub to real FastMCP" section)
3. Re-run `pytest tests/` -- the spec requires re-verifying tool/resource/
   prompt registration against the real package before submission.

This stub deliberately keeps registries introspectable (self._tools,
self._resources, self._prompts) so tests can call the underlying function
directly without needing a live transport -- this is what lets
run_local_demo.py and the pytest suite run without a live MCP client, per
§2.4 and §8.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Callable


@dataclass
class _RegisteredTool:
    name: str
    func: Callable
    description: str | None = None


@dataclass
class _RegisteredResource:
    uri_template: str
    func: Callable
    pattern: re.Pattern = field(init=False)
    param_names: list[str] = field(init=False)

    def __post_init__(self):
        # Convert a URI template like "account://{account_id}/summary" into
        # a matching regex with named groups, mirroring how real FastMCP
        # resolves templated resource URIs to handler arguments.
        param_names = re.findall(r"\{(\w+)\}", self.uri_template)
        pattern_str = re.escape(self.uri_template)
        for name in param_names:
            pattern_str = pattern_str.replace(re.escape("{" + name + "}"), f"(?P<{name}>[^/]+)")
        object.__setattr__(self, "pattern", re.compile(f"^{pattern_str}$"))
        object.__setattr__(self, "param_names", param_names)

    def match(self, uri: str) -> dict[str, str] | None:
        m = self.pattern.match(uri)
        return m.groupdict() if m else None


@dataclass
class _RegisteredPrompt:
    name: str
    func: Callable
    description: str | None = None


class FastMCP:
    """Minimal local stand-in for mcp.server.fastmcp.FastMCP.

    Supports the subset of the real API BankForge servers need:
    @mcp.tool(), @mcp.resource(uri_template), @mcp.prompt(), and .run().
    """

    def __init__(self, name: str):
        self.name = name
        self._tools: dict[str, _RegisteredTool] = {}
        self._resources: list[_RegisteredResource] = []
        self._prompts: dict[str, _RegisteredPrompt] = {}

    # -- Tools ------------------------------------------------------------

    def tool(self, name: str | None = None, description: str | None = None):
        def decorator(func: Callable) -> Callable:
            tool_name = name or func.__name__
            self._tools[tool_name] = _RegisteredTool(
                name=tool_name, func=func, description=description or func.__doc__
            )
            return func
        return decorator

    def call_tool(self, name: str, **kwargs) -> Any:
        if name not in self._tools:
            raise KeyError(f"No tool registered with name '{name}'")
        return self._tools[name].func(**kwargs)

    # -- Resources ----------------------------------------------------------

    def resource(self, uri_template: str):
        def decorator(func: Callable) -> Callable:
            self._resources.append(_RegisteredResource(uri_template=uri_template, func=func))
            return func
        return decorator

    def read_resource(self, uri: str) -> Any:
        for reg in self._resources:
            params = reg.match(uri)
            if params is not None:
                return reg.func(**params)
        raise KeyError(f"No resource registered matching URI '{uri}'")

    # -- Prompts ------------------------------------------------------------

    def prompt(self, name: str | None = None, description: str | None = None):
        def decorator(func: Callable) -> Callable:
            prompt_name = name or func.__name__
            self._prompts[prompt_name] = _RegisteredPrompt(
                name=prompt_name, func=func, description=description or func.__doc__
            )
            return func
        return decorator

    def get_prompt(self, prompt_name: str, **kwargs) -> Any:
        if prompt_name not in self._prompts:
            raise KeyError(f"No prompt registered with name '{prompt_name}'")
        return self._prompts[prompt_name].func(**kwargs)

    # -- Introspection helpers (used by tests) -------------------------------

    def list_tool_names(self) -> list[str]:
        return sorted(self._tools.keys())

    def list_resource_templates(self) -> list[str]:
        return [r.uri_template for r in self._resources]

    def list_prompt_names(self) -> list[str]:
        return sorted(self._prompts.keys())

    # -- Server lifecycle -----------------------------------------------------

    def run(self, transport: str = "stdio") -> None:
        """In the real package this starts a live MCP server loop over the
        given transport. The stub has no transport to run, so it simply
        confirms the server is constructed and registrations are valid,
        which is sufficient for the "does it start" check when no live
        client is available. Real startup is verified separately once the
        real `mcp` package is installed (see README).
        """
        print(
            f"[stub] FastMCP server '{self.name}' would start here "
            f"(transport={transport}). Registered "
            f"{len(self._tools)} tools, {len(self._resources)} resources, "
            f"{len(self._prompts)} prompts. Install the real 'mcp' package "
            f"for live startup."
        )

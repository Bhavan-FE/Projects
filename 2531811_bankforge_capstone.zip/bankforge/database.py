"""
database.py
============
Schema definition, seed data, and connection setup for BankForge's
neobank.db (SQLite, WAL mode, per §2/§3).

This module intentionally does NOT expose a general-purpose "run any query"
helper to the servers. Each server directory has its own repository.py that
imports get_connection() from here and only ever issues queries against the
tables its own responsibility (per §3's table) covers. That separation is
what makes server isolation an enforced, auditable property of the codebase
rather than a runtime accident -- see docs/architecture.md for the full
rationale.

Usage
-----
    python database.py --seed          # (re)create neobank.db with seed data
    python database.py --seed --path X # seed a specific db file (used by tests)
"""

from __future__ import annotations

import argparse
import os
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Optional

DEFAULT_DB_PATH = os.environ.get("BANKFORGE_DB_PATH", str(Path(__file__).parent / "neobank.db"))

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS customers (
    customer_id     TEXT PRIMARY KEY,
    name            TEXT NOT NULL,
    email           TEXT,
    phone           TEXT,
    kyc_status      TEXT NOT NULL DEFAULT 'unverified',  -- 'verified' | 'unverified' | 'pending'
    risk_rating     TEXT NOT NULL DEFAULT 'medium',        -- 'low' | 'medium' | 'high'
    account_tier    TEXT NOT NULL DEFAULT 'standard',       -- 'standard' | 'premium' | 'private'
    created_at      TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS accounts (
    account_id          TEXT PRIMARY KEY,
    customer_id         TEXT NOT NULL REFERENCES customers(customer_id),
    account_number      TEXT NOT NULL,
    account_type        TEXT NOT NULL,      -- 'savings' | 'current' | 'loan'
    status              TEXT NOT NULL DEFAULT 'active',
    balance             REAL NOT NULL DEFAULT 0.0,
    opened_date         TEXT NOT NULL DEFAULT (date('now')),
    last_transaction_at TEXT
);

CREATE TABLE IF NOT EXISTS transactions (
    transaction_id   TEXT PRIMARY KEY,
    account_id       TEXT NOT NULL REFERENCES accounts(account_id),
    amount           REAL NOT NULL,
    direction        TEXT NOT NULL,   -- 'credit' | 'debit'
    description      TEXT,
    occurred_at      TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS loan_products (
    product_id       TEXT PRIMARY KEY,
    name              TEXT NOT NULL,
    category          TEXT NOT NULL,   -- 'personal' | 'home' | 'auto' | 'business'
    interest_rate_pct REAL NOT NULL,
    min_amount        REAL NOT NULL,
    max_amount        REAL NOT NULL,
    max_risk_rating   TEXT NOT NULL    -- highest applicant risk rating this product accepts
);

CREATE TABLE IF NOT EXISTS loan_applications (
    application_id     TEXT PRIMARY KEY,
    customer_id        TEXT NOT NULL,
    product_id         TEXT NOT NULL,
    requested_amount   REAL NOT NULL,
    status             TEXT NOT NULL DEFAULT 'submitted',  -- 'submitted' | 'approved' | 'rejected'
    submitted_at       TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS communications_log (
    communication_id  TEXT PRIMARY KEY,
    customer_id        TEXT NOT NULL,
    channel             TEXT NOT NULL,   -- 'marketing' | 'transactional' | 'service'
    message              TEXT NOT NULL,
    sent_at              TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS fraud_flags (
    flag_id           TEXT PRIMARY KEY,
    customer_id        TEXT NOT NULL,
    account_id          TEXT,
    reason               TEXT NOT NULL,
    severity             TEXT NOT NULL DEFAULT 'medium',  -- 'low' | 'medium' | 'high'
    raised_at            TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS audit_log (
    audit_id        TEXT PRIMARY KEY,
    timestamp        TEXT NOT NULL DEFAULT (datetime('now')),
    action_type       TEXT NOT NULL,
    performed_by       TEXT,
    customer_id         TEXT,
    outcome              TEXT NOT NULL   -- 'success' | 'blocked' | 'failed'
);
"""


def get_connection(db_path: Optional[str] = None) -> sqlite3.Connection:
    """Open a connection to the shared neobank.db with WAL mode enabled.

    Every repository.py in every server calls this to get its connection.
    WAL mode is set per-connection (it's a persistent DB-level setting after
    the first time, but we set it defensively on every connect).

    db_path defaults to None, which resolves to the CURRENT value of
    DEFAULT_DB_PATH at call time (not at import/def time) -- this is
    deliberate so that tests can monkeypatch DEFAULT_DB_PATH and have every
    caller that omits db_path pick up the patched value. A bare
    `db_path: str = DEFAULT_DB_PATH` default would bind the original value
    once at function-definition time and silently ignore any later
    monkeypatching.
    """
    resolved_path = db_path if db_path is not None else DEFAULT_DB_PATH
    conn = sqlite3.connect(resolved_path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.execute("PRAGMA foreign_keys=ON;")
    return conn


@contextmanager
def connection_scope(db_path: Optional[str] = None):
    """Context manager yielding a connection and committing/closing cleanly."""
    conn = get_connection(db_path)
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_schema(db_path: Optional[str] = None) -> None:
    with connection_scope(db_path) as conn:
        conn.executescript(SCHEMA_SQL)


# --------------------------------------------------------------------------
# Seed data
# --------------------------------------------------------------------------
#
# Seed data covers:
#   - the official Showcase Scenario: Priya Sharma / CUS-10042 / PROD-PL-01
#   - supporting records for the three official Stress Tests:
#       * missing customer      -> CUS-99999 is deliberately NOT seeded
#       * invalid loan submission -> exercised via malformed IDs / an
#         unverified-KYC customer (CUS-20077, seeded below) at demo time
#       * compliance server offline -> a runtime/demo-script condition,
#         not a data condition; see run_local_demo.py
#   - a couple of extra customers/accounts so scoped-field-visibility and
#     transaction-history demos have more than one record to work with


def seed_data(db_path: Optional[str] = None) -> None:
    with connection_scope(db_path) as conn:
        # Wipe existing rows so re-seeding is idempotent.
        for table in (
            "audit_log", "fraud_flags", "communications_log",
            "loan_applications", "transactions", "accounts",
            "loan_products", "customers",
        ):
            conn.execute(f"DELETE FROM {table}")

        # --- customers ---------------------------------------------------
        conn.executemany(
            "INSERT INTO customers "
            "(customer_id, name, email, phone, kyc_status, risk_rating, account_tier) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            [
                # Showcase Scenario customer -- verified KYC, low risk, so the
                # full happy path (loan submission, marketing comms) succeeds.
                ("CUS-10042", "Priya Sharma", "priya.sharma@example.com",
                 "+91-98765-43210", "verified", "low", "premium"),

                # Unverified-KYC customer, used to demonstrate the KYC gate
                # blocking both a marketing communication and a loan
                # application (demo script steps + Stress Test 2).
                ("CUS-20077", "Arjun Mehta", "arjun.mehta@example.com",
                 "+91-91234-56789", "unverified", "medium", "standard"),

                # A second verified customer purely to give scoped-field
                # visibility and transaction-history demos a second account
                # to compare against.
                ("CUS-30015", "Fatima Khan", "fatima.khan@example.com",
                 "+91-99887-76655", "verified", "medium", "standard"),

                # Note: CUS-99999 is intentionally NOT inserted here.
                # It is well-formed (matches CUS-XXXXX) but has no row,
                # which is exactly what Stress Test 1 ("missing customer")
                # needs to exercise.
            ],
        )

        # --- accounts ------------------------------------------------------
        conn.executemany(
            "INSERT INTO accounts "
            "(account_id, customer_id, account_number, account_type, status, "
            " balance, opened_date, last_transaction_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            [
                ("ACC-10042", "CUS-10042", "0000123410042", "savings", "active",
                 250000.00, "2022-03-14", "2026-09-28"),
                ("ACC-10043", "CUS-10042", "0000123410043", "current", "active",
                 48250.75, "2023-06-01", "2026-09-29"),
                ("ACC-20077", "CUS-20077", "0000123420077", "savings", "active",
                 15000.00, "2024-01-20", "2026-09-15"),
                ("ACC-30015", "CUS-30015", "0000123430015", "savings", "active",
                 76000.00, "2021-11-05", "2026-09-27"),
            ],
        )

        # --- transactions ---------------------------------------------------
        conn.executemany(
            "INSERT INTO transactions "
            "(transaction_id, account_id, amount, direction, description, occurred_at) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            [
                ("TXN-0001", "ACC-10042", 5000.00, "credit", "Salary credit", "2026-09-01T09:00:00"),
                ("TXN-0002", "ACC-10042", 1200.50, "debit", "Utility payment", "2026-09-05T14:22:00"),
                # Large transaction, deliberately over a reporting threshold,
                # to exercise the large-transaction reporting flag in
                # run_compliance_check (demo script requirement).
                ("TXN-0003", "ACC-10042", 1250000.00, "credit", "Property sale proceeds", "2026-09-28T11:05:00"),
                ("TXN-0004", "ACC-10043", 3200.00, "debit", "Credit card payment", "2026-09-10T08:00:00"),
                ("TXN-0005", "ACC-10043", 900.00, "debit", "Insurance premium", "2026-09-29T16:40:00"),
                ("TXN-0006", "ACC-20077", 500.00, "debit", "Subscription renewal", "2026-09-15T12:00:00"),
                ("TXN-0007", "ACC-30015", 2000.00, "credit", "Freelance payment", "2026-09-20T10:15:00"),
                ("TXN-0008", "ACC-30015", 15000.00, "debit", "Rent payment", "2026-09-27T09:30:00"),
            ],
        )

        # --- loan_products -----------------------------------------------
        conn.executemany(
            "INSERT INTO loan_products "
            "(product_id, name, category, interest_rate_pct, min_amount, max_amount, max_risk_rating) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            [
                # Showcase Scenario product -- accepts up to 'medium' risk,
                # so Priya Sharma (risk_rating='low') is eligible.
                ("PROD-PL-01", "Personal Loan Standard", "personal", 11.5,
                 50000.0, 1000000.0, "medium"),
                ("PROD-HL-01", "Home Loan Fixed", "home", 8.25,
                 500000.0, 20000000.0, "medium"),
                ("PROD-AL-01", "Auto Loan", "auto", 9.75,
                 100000.0, 2000000.0, "high"),
                ("PROD-BL-01", "Business Growth Loan", "business", 13.0,
                 200000.0, 5000000.0, "low"),
            ],
        )

        # loan_applications / communications_log / fraud_flags / audit_log
        # are intentionally left empty at seed time. The Showcase Scenario
        # and demo script are expected to create rows in these tables live,
        # to prove the write paths (submit_loan_application,
        # send_customer_communication, write_audit_log) actually work --
        # not just that pre-populated rows can be read back.

        # One pre-existing fraud flag for CUS-20077, so get_fraud_flags has
        # something non-trivial to return in the demo.
        conn.execute(
            "INSERT INTO fraud_flags (flag_id, customer_id, account_id, reason, severity) "
            "VALUES (?, ?, ?, ?, ?)",
            ("FLAG-0001", "CUS-20077", "ACC-20077",
             "Multiple failed login attempts from new device", "low"),
        )


def main() -> None:
    parser = argparse.ArgumentParser(description="BankForge database setup")
    parser.add_argument("--seed", action="store_true", help="(Re)create schema and seed data")
    parser.add_argument("--path", default=DEFAULT_DB_PATH, help="Path to the SQLite db file")
    args = parser.parse_args()

    if args.seed:
        init_schema(args.path)
        seed_data(args.path)
        print(f"Seeded BankForge database at {args.path}")
    else:
        parser.print_help()


if __name__ == "__main__":
    main()

"""
resources.py
=============
The 4 required MCP Resources (§7):
    customer://{customer_id}/profile
    account://{account_id}/summary
    product://{product_id}/details
    template://{template_name}

Resources are read-only, templated-URI data views -- unlike Tools, which
represent actions. Per §7's explicit instruction, these reuse the
guardrail functions from guardrails.py (masking, scoping validation)
rather than duplicating that logic, and reuse each server's repository
module rather than querying the database directly here.

Each resource function is decorated with @trace, same as every Tool, per
§5's "apply this pattern consistently" requirement.

These functions are registered onto each server's FastMCP instance in
that server's __main__.py (a resource that reads account data is
registered on accounts_server, etc.) -- this module holds the shared
logic so it isn't duplicated across three __main__.py files, and so it can
be unit tested independently of any FastMCP registration.
"""

from __future__ import annotations

from typing import Any

import guardrails
from logging_config import get_logger, trace

import accounts_server.repository as accounts_repo
import accounts_server.tools as accounts_tools
import compliance_comms_server.repository as compliance_repo
import compliance_comms_server.tools as compliance_tools
import products_server.repository as products_repo
import products_server.tools as products_tools

logger = get_logger(__name__)


@trace(logger, redact=guardrails.redact_for_logging)
def customer_profile_resource(customer_id: str) -> dict[str, Any]:
    """customer://{customer_id}/profile

    A minimal, non-sensitive customer profile view: no raw KYC data (that
    stays behind get_kyc_status, per §3.1), no bulk data, no account
    numbers. Read-only.

    Raises:
        guardrails.InvalidIdFormatError: customer_id is malformed.
        compliance_tools.CustomerNotFoundError: customer_id doesn't exist.
    """
    guardrails.validate_id_format("customer_id", customer_id)

    customer = compliance_repo.fetch_customer(customer_id)
    if customer is None:
        raise compliance_tools.CustomerNotFoundError(customer_id)

    # Deliberately exclude kyc_status, email, phone from this general
    # profile view -- those are either raw-KYC-only data (kyc_status) or
    # contact PII not needed for a "profile" view.
    return {
        "customer_id": customer["customer_id"],
        "name": customer["name"],
        "account_tier": customer["account_tier"],
        "risk_rating": customer["risk_rating"],
    }


@trace(logger, redact=guardrails.redact_for_logging)
def account_summary_resource(account_id: str) -> dict[str, Any]:
    """account://{account_id}/summary

    Reuses accounts_server.repository.fetch_account +
    guardrails.minimize_account_fields directly, at the most permissive
    scope available to a Resource ("compliance_officer") since a resource
    URI carries no caller_scope argument the way the accounts_server
    Tools do -- account number masking is still applied unconditionally
    either way, per the hard requirement in §4.

    Raises:
        guardrails.InvalidIdFormatError: account_id is malformed.
        accounts_tools.AccountNotFoundError: account_id doesn't exist.
    """
    guardrails.validate_id_format("account_id", account_id)

    record = accounts_repo.fetch_account(account_id)
    if record is None:
        raise accounts_tools.AccountNotFoundError(account_id)

    return guardrails.minimize_account_fields(record, caller_scope="compliance_officer")


@trace(logger, redact=guardrails.redact_for_logging)
def product_details_resource(product_id: str) -> dict[str, Any]:
    """product://{product_id}/details

    Reuses products_server.repository.fetch_product directly -- loan
    product data carries no sensitive/PII fields, so no additional
    guardrail filtering is needed beyond ID format validation.

    Raises:
        guardrails.InvalidIdFormatError: product_id is malformed.
        products_tools.ProductNotFoundError: product_id doesn't exist.
    """
    guardrails.validate_id_format("product_id", product_id)

    product = products_repo.fetch_product(product_id)
    if product is None:
        raise products_tools.ProductNotFoundError(product_id)

    return product


@trace(logger, redact=guardrails.redact_for_logging)
def template_resource(template_name: str) -> dict[str, Any]:
    """template://{template_name}

    Exposes the raw (unrendered) Markdown source of a communication
    template, for a client that wants to inspect available templates
    before calling generate_customer_communication. No customer data is
    involved, so no masking/scoping is needed -- this reuses
    compliance_comms_server.tools.TEMPLATES_DIR rather than hardcoding a
    second path to the templates directory.

    Raises:
        compliance_tools.TemplateNotFoundError: template_name has no
            matching .md file.
    """
    template_path = compliance_tools.TEMPLATES_DIR / f"{template_name}.md"
    if not template_path.is_file():
        raise compliance_tools.TemplateNotFoundError(template_name)

    return {
        "template_name": template_name,
        "raw_markdown": template_path.read_text(encoding="utf-8"),
    }

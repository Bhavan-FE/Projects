# A Special Offer for You

Dear {customer_name},

As one of our {account_tier} customers, we wanted to share something we
think you'll find useful.

**Detail:** {specific_detail}

This offer is available for a limited time. Terms and conditions apply.

Best,
NeoBank India

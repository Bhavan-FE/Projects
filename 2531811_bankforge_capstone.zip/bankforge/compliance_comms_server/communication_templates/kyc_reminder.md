# Action Needed: Complete Your KYC Verification

Dear {customer_name},

As a {account_tier} customer, please complete your KYC verification so we
can continue serving your account without interruption.

**Detail:** {specific_detail}

Please visit any NeoBank India branch or complete verification through the
app at your earliest convenience.

Regards,
NeoBank India Compliance Team

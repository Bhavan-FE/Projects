# Your Loan Application Update

Dear {customer_name},

Great news! As a valued {account_tier} customer, we're pleased to let you
know about an update to your application.

**Detail:** {specific_detail}

If you have any questions, please reach out to your relationship manager
or visit your nearest NeoBank India branch.

Warm regards,
NeoBank India

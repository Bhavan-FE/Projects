"""
compliance_comms_server/tools.py
===================================
The six Tools owned by compliance_comms_server (§3.1):
    get_kyc_status(customer_id)
    run_compliance_check(customer_id, transaction_amount)
    send_customer_communication(customer_id, channel, message)
    get_fraud_flags(customer_id)
    write_audit_log(action_type, performed_by, customer_id, outcome)
    generate_customer_communication(template_name, customer_name, account_tier, specific_detail)

get_kyc_status is explicitly the only tool anywhere in BankForge that
returns raw KYC data (§3.1) -- accounts_server and products_server never
expose kyc_status directly to a caller; accounts_server surfaces it only
as one of several fields under compliance_officer/admin scope (already
minimized), and products_server never looks it up at all (see
products_server/tools.py docstring).

send_customer_communication enforces the KYC gate for marketing channel
messages (guardrails.enforce_communication_kyc_gate), sanitises the
message body (guardrails.sanitize_free_text), and always logs the send via
write_audit_log -- every write operation gets an audit entry, per §4.

generate_customer_communication renders from the Markdown files in
communication_templates/ on disk, not a plain Python string, per §3.1's
explicit requirement.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Optional

import guardrails
from logging_config import get_logger, trace

from . import repository

logger = get_logger(__name__)

TEMPLATES_DIR = Path(__file__).parent / "communication_templates"

LARGE_TRANSACTION_THRESHOLD = 1_000_000.0  # INR; flags for regulatory reporting


class CustomerNotFoundError(Exception):
    def __init__(self, customer_id: str):
        self.customer_id = customer_id
        super().__init__(f"No customer found with customer_id '{customer_id}'")


class TemplateNotFoundError(Exception):
    def __init__(self, template_name: str):
        self.template_name = template_name
        super().__init__(f"No communication template found named '{template_name}'")


class TemplateRenderError(Exception):
    def __init__(self, template_name: str, missing_key: str):
        self.template_name = template_name
        self.missing_key = missing_key
        super().__init__(
            f"Template '{template_name}' requires placeholder "
            f"'{{{missing_key}}}' that was not supplied"
        )


VALID_CHANNELS = frozenset({"marketing", "transactional", "service"})
VALID_ACTION_TYPES = frozenset({
    "loan_application_submitted",
    "loan_application_blocked",
    "customer_communication_sent",
    "customer_communication_blocked",
})
VALID_OUTCOMES = frozenset({"success", "blocked", "failed"})


@trace(logger, redact=guardrails.redact_for_logging)
def get_kyc_status(customer_id: str) -> dict[str, Any]:
    """Return the customer's raw KYC status. This is the ONLY tool in
    BankForge that returns raw KYC data (§3.1) -- callers needing to gate a
    write elsewhere (e.g. products_server.submit_loan_application) should
    call this first and pass the result in.

    Raises:
        guardrails.InvalidIdFormatError: customer_id is malformed.
        CustomerNotFoundError: customer_id is well-formed but doesn't exist.
    """
    guardrails.validate_id_format("customer_id", customer_id)

    customer = repository.fetch_customer(customer_id)
    if customer is None:
        raise CustomerNotFoundError(customer_id)

    return {"customer_id": customer_id, "kyc_status": customer["kyc_status"]}


@trace(logger, redact=guardrails.redact_for_logging)
def run_compliance_check(customer_id: str, transaction_amount: float) -> dict[str, Any]:
    """Deterministic pass/block decision plus a large-transaction reporting
    flag (§3.1). Does not write anything.

    Rules (deterministic, no model call):
      - blocked if the customer's KYC is not verified
      - flagged for large-transaction reporting if transaction_amount
        meets or exceeds LARGE_TRANSACTION_THRESHOLD, regardless of
        pass/block outcome

    Raises:
        guardrails.InvalidIdFormatError: customer_id is malformed.
        CustomerNotFoundError: customer_id is well-formed but doesn't exist.
        ValueError: transaction_amount is negative.
    """
    guardrails.validate_id_format("customer_id", customer_id)

    if transaction_amount < 0:
        raise ValueError(f"transaction_amount cannot be negative, got {transaction_amount}")

    customer = repository.fetch_customer(customer_id)
    if customer is None:
        raise CustomerNotFoundError(customer_id)

    passed = customer["kyc_status"] == guardrails.VERIFIED_KYC_STATUS
    large_transaction_flag = transaction_amount >= LARGE_TRANSACTION_THRESHOLD

    return {
        "customer_id": customer_id,
        "passed": passed,
        "reason": (
            "KYC verified" if passed
            else f"KYC status is '{customer['kyc_status']}', not verified"
        ),
        "large_transaction_flag": large_transaction_flag,
        "transaction_amount": transaction_amount,
    }


@trace(logger, redact=guardrails.redact_for_logging)
def send_customer_communication(customer_id: str, channel: str, message: str) -> dict[str, Any]:
    """Send a communication to a customer. Sanitises the message body,
    enforces the KYC gate for marketing channel messages, and always
    records the outcome via write_audit_log -- both on success AND on a
    KYC-gate block, so blocked attempts are auditable too.

    Raises:
        guardrails.InvalidIdFormatError: customer_id is malformed.
        CustomerNotFoundError: customer_id is well-formed but doesn't exist.
        ValueError: channel is not one of marketing/transactional/service.
        guardrails.UnsafeInputError: message fails sanitisation.
        guardrails.KycGateBlockedError: marketing message blocked by KYC gate
            (an audit log entry is written for the block before this is raised).
    """
    guardrails.validate_id_format("customer_id", customer_id)

    if channel not in VALID_CHANNELS:
        raise ValueError(f"channel must be one of {sorted(VALID_CHANNELS)}, got {channel!r}")

    customer = repository.fetch_customer(customer_id)
    if customer is None:
        raise CustomerNotFoundError(customer_id)

    # Sanitise BEFORE the KYC gate check so a malicious payload never gets
    # anywhere near a decision path, let alone storage.
    clean_message = guardrails.sanitize_free_text(message, field_name="message")

    if not guardrails.can_send_communication(customer["kyc_status"], channel):
        write_audit_log(
            action_type="customer_communication_blocked",
            performed_by="system",
            customer_id=customer_id,
            outcome="blocked",
        )
        guardrails.enforce_communication_kyc_gate(customer_id, customer["kyc_status"], channel)

    record = repository.insert_communication(customer_id, channel, clean_message)
    write_audit_log(
        action_type="customer_communication_sent",
        performed_by="system",
        customer_id=customer_id,
        outcome="success",
    )
    return record


@trace(logger, redact=guardrails.redact_for_logging)
def get_fraud_flags(customer_id: str) -> list[dict[str, Any]]:
    """Return all fraud flags raised against a customer, most recent first.

    Raises:
        guardrails.InvalidIdFormatError: customer_id is malformed.
        CustomerNotFoundError: customer_id is well-formed but doesn't exist.
    """
    guardrails.validate_id_format("customer_id", customer_id)

    if repository.fetch_customer(customer_id) is None:
        raise CustomerNotFoundError(customer_id)

    return repository.fetch_fraud_flags(customer_id)


@trace(logger, redact=guardrails.redact_for_logging)
def write_audit_log(
    action_type: str,
    performed_by: Optional[str],
    customer_id: Optional[str],
    outcome: str,
) -> dict[str, Any]:
    """Write a single audit_log entry (timestamp is set by the DB default).
    Called internally by send_customer_communication for every send
    attempt (success or KYC-blocked), and should be called by any other
    write path (e.g. from a client orchestrating submit_loan_application)
    to keep audit coverage complete for every write operation, per §4.

    Raises:
        ValueError: action_type or outcome is not a recognised value.
    """
    if action_type not in VALID_ACTION_TYPES:
        raise ValueError(
            f"action_type must be one of {sorted(VALID_ACTION_TYPES)}, "
            f"got {action_type!r}"
        )
    if outcome not in VALID_OUTCOMES:
        raise ValueError(f"outcome must be one of {sorted(VALID_OUTCOMES)}, got {outcome!r}")

    return repository.insert_audit_log(action_type, performed_by, customer_id, outcome)


@trace(logger, redact=guardrails.redact_for_logging)
def generate_customer_communication(
    template_name: str,
    customer_name: str,
    account_tier: str,
    specific_detail: str,
) -> dict[str, Any]:
    """Render a customer communication from a Markdown template file on
    disk (communication_templates/), per §3.1's explicit requirement that
    this NOT be a plain Python string. Read-only: does not send or log
    anything -- pair with send_customer_communication to actually deliver.

    Raises:
        TemplateNotFoundError: template_name has no matching .md file.
        TemplateRenderError: the template references a placeholder not
            covered by this function's fixed argument set.
        guardrails.UnsafeInputError: any of the free-text arguments fail
            sanitisation.
    """
    template_path = TEMPLATES_DIR / f"{template_name}.md"
    if not template_path.is_file():
        raise TemplateNotFoundError(template_name)

    raw_template = template_path.read_text(encoding="utf-8")

    clean_customer_name = guardrails.sanitize_free_text(customer_name, field_name="customer_name")
    clean_specific_detail = guardrails.sanitize_free_text(specific_detail, field_name="specific_detail")

    try:
        rendered = raw_template.format(
            customer_name=clean_customer_name,
            account_tier=account_tier,
            specific_detail=clean_specific_detail,
        )
    except KeyError as exc:
        raise TemplateRenderError(template_name, str(exc).strip("'")) from exc

    return {
        "template_name": template_name,
        "rendered_message": rendered,
    }

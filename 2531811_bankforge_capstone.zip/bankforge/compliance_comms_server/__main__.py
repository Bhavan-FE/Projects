"""
compliance_comms_server/__main__.py
======================================
FastMCP application entrypoint for compliance_comms_server.

Run standalone with:
    python -m compliance_comms_server

Owns: customers, communications_log, fraud_flags, audit_log.
"""

from __future__ import annotations

from typing import Optional

from mcp.server.fastmcp import FastMCP

import prompts
import resources
from compliance_comms_server import tools

mcp = FastMCP("compliance_comms_server")


@mcp.resource("customer://{customer_id}/profile")
def customer_profile_resource(customer_id: str) -> dict:
    """Read-only, non-sensitive customer profile view. See
    resources.customer_profile_resource for the shared implementation.
    """
    return resources.customer_profile_resource(customer_id)


@mcp.resource("template://{template_name}")
def template_resource(template_name: str) -> dict:
    """Read-only raw Markdown source for a communication template. See
    resources.template_resource for the shared implementation.
    """
    return resources.template_resource(template_name)


@mcp.prompt()
def customer_communication_prompt(
    template_name: str, customer_name: str, account_tier: str, specific_detail: str
) -> str:
    """Reusable instructions for generating and sending a customer
    communication via compliance_comms_server's Tools.
    """
    return prompts.customer_communication_prompt(
        template_name, customer_name, account_tier, specific_detail
    )


@mcp.tool()
def get_kyc_status(customer_id: str) -> dict:
    """Return raw KYC status for a customer. The only tool anywhere in
    BankForge that returns raw KYC data.
    """
    return tools.get_kyc_status(customer_id)


@mcp.tool()
def run_compliance_check(customer_id: str, transaction_amount: float) -> dict:
    """Deterministic pass/block decision plus large-transaction reporting flag."""
    return tools.run_compliance_check(customer_id, transaction_amount)


@mcp.tool()
def send_customer_communication(customer_id: str, channel: str, message: str) -> dict:
    """Send a communication. Sanitises input, enforces the KYC gate for
    marketing messages, and logs the outcome.
    """
    return tools.send_customer_communication(customer_id, channel, message)


@mcp.tool()
def get_fraud_flags(customer_id: str) -> list:
    """Return fraud flags raised against a customer."""
    return tools.get_fraud_flags(customer_id)


@mcp.tool()
def write_audit_log(
    action_type: str, performed_by: Optional[str], customer_id: Optional[str], outcome: str
) -> dict:
    """Write an audit_log entry for a write operation."""
    return tools.write_audit_log(action_type, performed_by, customer_id, outcome)


@mcp.tool()
def generate_customer_communication(
    template_name: str, customer_name: str, account_tier: str, specific_detail: str
) -> dict:
    """Render a customer communication from a Markdown template on disk."""
    return tools.generate_customer_communication(
        template_name, customer_name, account_tier, specific_detail
    )


if __name__ == "__main__":
    mcp.run()

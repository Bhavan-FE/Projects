"""
compliance_comms_server/repository.py
========================================
The ONLY module in compliance_comms_server permitted to open a database
connection or issue SQL. Touches exactly: customers, communications_log,
fraud_flags, audit_log (per §3's table). No import of accounts_server or
products_server code, and no query against accounts/transactions/
loan_products/loan_applications -- compliance_comms_server's job is
compliance and communications, not account or product data.
"""

from __future__ import annotations

import uuid
from typing import Any, Optional

import database


def fetch_customer(customer_id: str) -> Optional[dict[str, Any]]:
    with database.connection_scope() as conn:
        row = conn.execute(
            "SELECT * FROM customers WHERE customer_id = ?", (customer_id,)
        ).fetchone()
        return dict(row) if row is not None else None


def insert_communication(customer_id: str, channel: str, message: str) -> dict[str, Any]:
    communication_id = f"COMM-{uuid.uuid4().hex[:10].upper()}"
    with database.connection_scope() as conn:
        conn.execute(
            """
            INSERT INTO communications_log (communication_id, customer_id, channel, message)
            VALUES (?, ?, ?, ?)
            """,
            (communication_id, customer_id, channel, message),
        )
        row = conn.execute(
            "SELECT * FROM communications_log WHERE communication_id = ?",
            (communication_id,),
        ).fetchone()
        return dict(row)


def fetch_fraud_flags(customer_id: str) -> list[dict[str, Any]]:
    with database.connection_scope() as conn:
        rows = conn.execute(
            "SELECT * FROM fraud_flags WHERE customer_id = ? ORDER BY raised_at DESC",
            (customer_id,),
        ).fetchall()
        return [dict(row) for row in rows]


def insert_audit_log(
    action_type: str, performed_by: Optional[str], customer_id: Optional[str], outcome: str
) -> dict[str, Any]:
    audit_id = f"AUDIT-{uuid.uuid4().hex[:10].upper()}"
    with database.connection_scope() as conn:
        conn.execute(
            """
            INSERT INTO audit_log (audit_id, action_type, performed_by, customer_id, outcome)
            VALUES (?, ?, ?, ?, ?)
            """,
            (audit_id, action_type, performed_by, customer_id, outcome),
        )
        row = conn.execute(
            "SELECT * FROM audit_log WHERE audit_id = ?", (audit_id,)
        ).fetchone()
        return dict(row)


def fetch_audit_log_for_customer(customer_id: str) -> list[dict[str, Any]]:
    """Retrieve audit entries for a customer, for compliance review --
    supports write_audit_log's requirement that entries be 'retrievable
    for compliance review' (§4).
    """
    with database.connection_scope() as conn:
        rows = conn.execute(
            "SELECT * FROM audit_log WHERE customer_id = ? ORDER BY timestamp DESC",
            (customer_id,),
        ).fetchall()
        return [dict(row) for row in rows]

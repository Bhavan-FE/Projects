"""
logging_config.py
==================
Structured JSON logging + the @trace(logger) decorator required by §5 of the
BankForge spec.

Every Tool, Resource, and Prompt function in this project is decorated with
@trace(logger). That produces three possible log lines per call:

  ENTER  (DEBUG) -- fully qualified function name, a call_id, bound arguments
                    (redacted if a redact= callable was supplied to the
                    decorator)
  EXIT   (DEBUG) -- same call_id, duration_ms, a truncated preview of the
                    return value
  FAILED (ERROR) -- same call_id, duration_ms, exception type, full
                    traceback -- then the exception is re-raised untouched

All log lines are single-line structured JSON (one JSON object per line),
written via a dedicated logger so they can be redirected/captured
independently of any framework logging FastMCP itself sets up.

LOG_LEVEL defaults to DEBUG everywhere via the BANKFORGE_LOG_LEVEL
environment variable, per §5.
"""

from __future__ import annotations

import functools
import inspect
import itertools
import json
import logging
import os
import sys
import time
import traceback
import uuid
from typing import Any, Callable, Optional

# --------------------------------------------------------------------------
# Logger construction
# --------------------------------------------------------------------------

_LOG_LEVEL_ENV_VAR = "BANKFORGE_LOG_LEVEL"
_DEFAULT_LOG_LEVEL = "DEBUG"

_MAX_PREVIEW_CHARS = 500  # truncation length for ENTER arg / EXIT return previews

_call_id_counter = itertools.count(1)


class _JsonLineFormatter(logging.Formatter):
    """Formats every LogRecord as a single line of JSON.

    The decorator below passes all structured fields via `extra=`, which
    logging attaches directly onto the LogRecord as attributes. We pull the
    ones we recognise off the record and dump them as JSON; anything left
    in record.msg (a preformatted dict) is merged in directly.
    """

    RESERVED = set(logging.LogRecord(
        name="x", level=0, pathname="", lineno=0, msg="", args=None, exc_info=None
    ).__dict__.keys()) | {"message", "asctime"}

    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "timestamp": self.formatTime(record, "%Y-%m-%dT%H:%M:%S"),
            "level": record.levelname,
            "logger": record.name,
        }

        # record.msg is expected to already be a dict for our @trace lines;
        # fall back to plain string message for any incidental log.info() etc.
        if isinstance(record.msg, dict):
            payload.update(record.msg)
        else:
            payload["message"] = record.getMessage()

        # Pick up any extra attributes that were attached via extra=... and
        # are not part of the standard LogRecord attribute set.
        for key, value in record.__dict__.items():
            if key not in self.RESERVED and key not in payload:
                payload[key] = value

        try:
            return json.dumps(payload, default=str)
        except (TypeError, ValueError):
            # Absolute last resort: never let a logging call raise.
            return json.dumps({"level": record.levelname, "message": str(record.msg)})


def _resolve_log_level() -> int:
    level_name = os.environ.get(_LOG_LEVEL_ENV_VAR, _DEFAULT_LOG_LEVEL).upper()
    return getattr(logging, level_name, logging.DEBUG)


def get_logger(name: str) -> logging.Logger:
    """Return a module-scoped logger configured to emit structured JSON lines.

    Safe to call repeatedly (e.g. once per module via `logger =
    get_logger(__name__)`); handlers are only attached once per logger name.
    """
    logger = logging.getLogger(name)
    logger.setLevel(_resolve_log_level())

    if not any(isinstance(h, logging.StreamHandler) for h in logger.handlers):
        handler = logging.StreamHandler(stream=sys.stdout)
        handler.setFormatter(_JsonLineFormatter())
        logger.addHandler(handler)
        logger.propagate = False

    return logger


# --------------------------------------------------------------------------
# The @trace(logger) decorator
# --------------------------------------------------------------------------

def _preview(value: Any, max_chars: int = _MAX_PREVIEW_CHARS) -> str:
    """Produce a truncated, safe-to-log string preview of any return value."""
    try:
        text = json.dumps(value, default=str)
    except (TypeError, ValueError):
        text = str(value)
    if len(text) > max_chars:
        return text[:max_chars] + f"...<truncated {len(text) - max_chars} chars>"
    return text


def _bind_arguments(func: Callable, args: tuple, kwargs: dict) -> dict[str, Any]:
    """Bind positional/keyword call args to parameter names for clean logging."""
    try:
        sig = inspect.signature(func)
        bound = sig.bind_partial(*args, **kwargs)
        bound.apply_defaults()
        return dict(bound.arguments)
    except TypeError:
        # Signature binding can fail for exotic call shapes; fall back to a
        # best-effort representation rather than crashing the traced call.
        return {"args": args, "kwargs": kwargs}


def trace(logger: logging.Logger, redact: Optional[Callable[[dict], dict]] = None):
    """Decorator factory implementing the ENTER / EXIT / FAILED tracing pattern.

    Parameters
    ----------
    logger:
        The logger (typically from get_logger(__name__)) to emit trace lines to.
    redact:
        Optional callable taking the bound-arguments dict and returning a
        redacted copy. When supplied, ENTER lines log the *redacted* version
        of the arguments. Intended to be guardrails.redact_for_logging.

    Usage
    -----
        logger = get_logger(__name__)

        @trace(logger, redact=guardrails.redact_for_logging)
        def get_account_summary(account_id: str, caller_scope: str) -> dict:
            ...
    """

    def decorator(func: Callable) -> Callable:
        qualname = f"{func.__module__}.{func.__qualname__}"

        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            call_id = f"{qualname}-{next(_call_id_counter)}-{uuid.uuid4().hex[:8]}"
            bound_args = _bind_arguments(func, args, kwargs)
            logged_args = redact(bound_args) if redact is not None else bound_args

            logger.debug({
                "event": "ENTER",
                "function": qualname,
                "call_id": call_id,
                "arguments": logged_args,
            })

            start = time.perf_counter()
            try:
                result = func(*args, **kwargs)
            except Exception as exc:
                duration_ms = round((time.perf_counter() - start) * 1000, 3)
                logger.error({
                    "event": "FAILED",
                    "function": qualname,
                    "call_id": call_id,
                    "duration_ms": duration_ms,
                    "exception_type": type(exc).__name__,
                    "traceback": traceback.format_exc(),
                })
                raise
            else:
                duration_ms = round((time.perf_counter() - start) * 1000, 3)
                logger.debug({
                    "event": "EXIT",
                    "function": qualname,
                    "call_id": call_id,
                    "duration_ms": duration_ms,
                    "return_preview": _preview(result),
                })
                return result

        return wrapper

    return decorator

"""
prompts.py
===========
The 2 required MCP Prompts (§7):
    transaction_analysis_prompt(customer_name, account_type, analysis_period)
    customer_communication_prompt(template_name, customer_name, account_tier, specific_detail)

Prompts are reusable instruction templates for an AI client -- per the
rubric's design-quality criterion, they should DIRECT the client to the
right Tool/Resource calls rather than embedding sensitive data directly.
Neither prompt below performs any database access or returns customer
data itself; both return plain instructional text naming the Tools/
Resources the client should call and in what order.

Both are traced via @trace, consistent with every other primitive, per §5.
"""

from __future__ import annotations

import guardrails
from logging_config import get_logger, trace

logger = get_logger(__name__)


@trace(logger, redact=guardrails.redact_for_logging)
def transaction_analysis_prompt(
    customer_name: str, account_type: str, analysis_period: str
) -> str:
    """transaction_analysis_prompt(customer_name, account_type, analysis_period)

    Produces instructional text guiding an AI client through analysing a
    customer's transaction history using the accounts_server Tools --
    it does not embed any actual transaction data itself.

    Raises:
        guardrails.UnsafeInputError: customer_name fails sanitisation.
    """
    clean_name = guardrails.sanitize_free_text(customer_name, field_name="customer_name")

    return (
        f"You are analysing {account_type} account activity for customer "
        f"{clean_name} over the period: {analysis_period}.\n\n"
        f"Steps to follow:\n"
        f"1. Call accounts_server.get_accounts_for_customer with the "
        f"customer's customer_id and an appropriate caller_scope to find "
        f"their {account_type} account(s).\n"
        f"2. For each matching account_id, call "
        f"accounts_server.get_transaction_history to retrieve transactions "
        f"falling within {analysis_period}.\n"
        f"3. Call compliance_comms_server.run_compliance_check on any "
        f"transaction amount that looks unusually large, to check the "
        f"large-transaction reporting flag.\n"
        f"4. Summarise spending patterns, flag any large-transaction "
        f"reporting flags raised, and note the account number only in its "
        f"masked (last-4-digit) form as returned by the Tools -- never "
        f"reconstruct or request the full account number.\n"
    )


@trace(logger, redact=guardrails.redact_for_logging)
def customer_communication_prompt(
    template_name: str, customer_name: str, account_tier: str, specific_detail: str
) -> str:
    """customer_communication_prompt(template_name, customer_name, account_tier, specific_detail)

    Produces instructional text guiding an AI client through generating
    and sending a customer communication using the compliance_comms_server
    Tools -- it does not render or send the message itself, and it does
    not embed the customer's KYC status or any other sensitive field.

    Raises:
        guardrails.UnsafeInputError: customer_name or specific_detail fails
            sanitisation.
    """
    clean_name = guardrails.sanitize_free_text(customer_name, field_name="customer_name")
    clean_detail = guardrails.sanitize_free_text(specific_detail, field_name="specific_detail")

    return (
        f"You are preparing a '{template_name}' communication for "
        f"{account_tier}-tier customer {clean_name}. The specific detail "
        f"to include is: {clean_detail}\n\n"
        f"Steps to follow:\n"
        f"1. Call compliance_comms_server.generate_customer_communication "
        f"with template_name='{template_name}', the customer's name, their "
        f"account_tier, and the specific_detail above, to render the "
        f"message body.\n"
        f"2. Before sending, call "
        f"compliance_comms_server.get_kyc_status for the customer if this "
        f"communication is on the 'marketing' channel -- verified KYC is "
        f"required for marketing sends.\n"
        f"3. Call compliance_comms_server.send_customer_communication with "
        f"the rendered message and the correct channel "
        f"(marketing/transactional/service). This call sanitises the "
        f"message again, enforces the KYC gate for marketing sends, and "
        f"writes an audit_log entry automatically.\n"
        f"4. Do not fabricate or guess the customer's KYC status, account "
        f"details, or contact information -- only use values returned by "
        f"the Tools above.\n"
    )

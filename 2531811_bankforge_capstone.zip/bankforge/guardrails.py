"""
guardrails.py
==============
Central security module for BankForge, required by §4 of the spec. Every
Tool and Resource that touches account data, free text, or write operations
must call into this module rather than reimplementing the same checks
locally -- the rubric explicitly checks for duplicated guardrail logic.

Contents
--------
- ID format validation (CUS-XXXXX / ACC-XXXXX / PROD-XX-XX) with typed errors
- Account number masking (last 4 digits only)
- Scoped field visibility for accounts_server (teller/loan_officer/
  compliance_officer/admin)
- KYC gates for the two write tools (submit_loan_application,
  send_customer_communication)
- Free-text sanitisation / prompt-injection signature detection
- PII redaction for structured logging
"""

from __future__ import annotations

import html
import re
from dataclasses import dataclass
from typing import Any, Iterable


# --------------------------------------------------------------------------
# Typed errors
# --------------------------------------------------------------------------

class GuardrailError(Exception):
    """Base class for all guardrail violations. Never silently swallowed --
    callers are expected to let these propagate as tool errors."""


class InvalidIdFormatError(GuardrailError):
    """Raised when an ID argument does not match its required format."""

    def __init__(self, field_name: str, value: str, expected_pattern: str):
        self.field_name = field_name
        self.value = value
        self.expected_pattern = expected_pattern
        super().__init__(
            f"Invalid format for '{field_name}': {value!r} does not match "
            f"expected pattern {expected_pattern!r}"
        )


class KycGateBlockedError(GuardrailError):
    """Raised when a write operation is blocked by a KYC gate."""

    def __init__(self, customer_id: str, operation: str, kyc_status: str):
        self.customer_id = customer_id
        self.operation = operation
        self.kyc_status = kyc_status
        super().__init__(
            f"Operation '{operation}' blocked for customer {customer_id}: "
            f"KYC status is '{kyc_status}', verified KYC is required."
        )


class UnsafeInputError(GuardrailError):
    """Raised when free text fails sanitisation (length, injection signature)."""

    def __init__(self, reason: str, field_name: str = "text"):
        self.reason = reason
        self.field_name = field_name
        super().__init__(f"Unsafe input rejected for '{field_name}': {reason}")


class InvalidScopeError(GuardrailError):
    """Raised when caller_scope is not one of the recognised roles."""

    def __init__(self, scope: str):
        self.scope = scope
        super().__init__(
            f"Unknown caller_scope {scope!r}; expected one of "
            f"{sorted(VALID_CALLER_SCOPES)}"
        )


# --------------------------------------------------------------------------
# ID format validation
# --------------------------------------------------------------------------

ID_PATTERNS: dict[str, re.Pattern] = {
    "customer_id": re.compile(r"^CUS-\d{5}$"),
    "account_id": re.compile(r"^ACC-\d{5}$"),
    "product_id": re.compile(r"^PROD-[A-Za-z]{2}-\d{2}$"),
}

_PATTERN_DESCRIPTIONS: dict[str, str] = {
    "customer_id": "CUS-XXXXX",
    "account_id": "ACC-XXXXX",
    "product_id": "PROD-XX-XX",
}


def validate_id_format(field_name: str, value: str) -> str:
    """Validate that `value` matches the required format for `field_name`.

    field_name must be one of "customer_id", "account_id", "product_id".
    Returns the value unchanged on success. Raises InvalidIdFormatError on
    mismatch -- callers should let this propagate as a typed tool error,
    not catch-and-swallow it.
    """
    if field_name not in ID_PATTERNS:
        raise ValueError(
            f"validate_id_format() does not know about field '{field_name}'; "
            f"expected one of {sorted(ID_PATTERNS)}"
        )
    pattern = ID_PATTERNS[field_name]
    if not isinstance(value, str) or not pattern.match(value):
        raise InvalidIdFormatError(
            field_name, value, _PATTERN_DESCRIPTIONS[field_name]
        )
    return value


# --------------------------------------------------------------------------
# Account number masking
# --------------------------------------------------------------------------

def mask_account_number(account_number: str) -> str:
    """Mask an account number/id down to its last 4 characters.

    This is a HARD requirement (§4): every Tool or Resource returning
    account data must pass the account number through this function before
    it leaves the server boundary.

        "ACC-10042"  ->  "****0042"
        "1234567890" ->  "******7890"

    Values with 4 or fewer characters are returned fully masked (no digits
    revealed) since there's nothing safe to keep unmasked.
    """
    if account_number is None:
        return account_number
    text = str(account_number)
    visible = text[-4:] if len(text) > 4 else ""
    masked_len = len(text) - len(visible)
    return ("*" * masked_len) + visible


# --------------------------------------------------------------------------
# Scoped field visibility (accounts_server)
# --------------------------------------------------------------------------

VALID_CALLER_SCOPES = frozenset({"teller", "loan_officer", "compliance_officer", "admin"})

# Field visibility matrix. "admin" and "compliance_officer" see everything;
# "teller" and "loan_officer" see progressively less. account_number is
# ALWAYS masked regardless of scope (handled separately, unconditionally,
# by mask_account_number -- scoping controls which *other* fields are
# visible at all, not whether the account number is masked).
_ACCOUNT_FIELDS_BY_SCOPE: dict[str, set[str]] = {
    "teller": {
        "account_id", "account_number", "account_type", "status", "balance",
    },
    "loan_officer": {
        "account_id", "account_number", "account_type", "status", "balance",
        "customer_id", "opened_date", "risk_rating",
    },
    "compliance_officer": {
        "account_id", "account_number", "account_type", "status", "balance",
        "customer_id", "opened_date", "risk_rating", "kyc_status",
        "last_transaction_at",
    },
    "admin": None,  # None means "all fields", set below once the schema is known
}


def minimize_account_fields(record: dict[str, Any], caller_scope: str) -> dict[str, Any]:
    """Filter an account record's fields down to what `caller_scope` may see,
    and unconditionally mask the account number in the result.

    Raises InvalidScopeError for unrecognised scopes -- this is deliberate:
    an unrecognised scope must never silently fall through to "see
    everything".
    """
    if caller_scope not in VALID_CALLER_SCOPES:
        raise InvalidScopeError(caller_scope)

    allowed = _ACCOUNT_FIELDS_BY_SCOPE[caller_scope]
    if allowed is None:
        filtered = dict(record)
    else:
        filtered = {k: v for k, v in record.items() if k in allowed}

    if "account_number" in filtered and filtered["account_number"] is not None:
        filtered["account_number"] = mask_account_number(filtered["account_number"])

    return filtered


# --------------------------------------------------------------------------
# KYC gates on write operations
# --------------------------------------------------------------------------

VERIFIED_KYC_STATUS = "verified"


def can_send_communication(kyc_status: str, channel: str) -> bool:
    """Gate for send_customer_communication.

    Marketing messages require verified KYC. Non-marketing channels
    (e.g. transactional/service notices) are allowed regardless of KYC
    status, since blocking a fraud alert or statement notice to an
    unverified customer would itself be a harm.
    """
    if channel == "marketing":
        return kyc_status == VERIFIED_KYC_STATUS
    return True


def enforce_communication_kyc_gate(customer_id: str, kyc_status: str, channel: str) -> None:
    """Raise KycGateBlockedError if this communication should be blocked."""
    if not can_send_communication(kyc_status, channel):
        raise KycGateBlockedError(customer_id, "send_customer_communication", kyc_status)


def can_submit_loan_application(kyc_status: str) -> bool:
    """Gate for submit_loan_application: verified KYC is required to submit,
    full stop -- there is no channel exception here, unlike communications.
    """
    return kyc_status == VERIFIED_KYC_STATUS


def enforce_loan_application_kyc_gate(customer_id: str, kyc_status: str) -> None:
    """Raise KycGateBlockedError if this loan application should be blocked."""
    if not can_submit_loan_application(kyc_status):
        raise KycGateBlockedError(customer_id, "submit_loan_application", kyc_status)


# --------------------------------------------------------------------------
# Free-text sanitisation / prompt-injection defence
# --------------------------------------------------------------------------

MAX_FREE_TEXT_LENGTH = 2000

# Signature patterns for common prompt-injection / instruction-override
# attempts. This is intentionally simple and pattern-based (deterministic,
# auditable) rather than a model call -- per spec, guardrails must be
# deterministic.
_INJECTION_SIGNATURES: list[re.Pattern] = [
    re.compile(r"ignore\s+(all\s+)?(previous|prior|above)\s+instructions", re.I),
    re.compile(r"disregard\s+(all\s+)?(previous|prior|above)", re.I),
    re.compile(r"you\s+are\s+now\s+(a|an)\s+\w+", re.I),
    re.compile(r"system\s*prompt", re.I),
    re.compile(r"\bact\s+as\s+(if\s+you\s+are\s+)?(a|an)\s+\w+", re.I),
    re.compile(r"reveal\s+(your|the)\s+(system\s+)?(prompt|instructions)", re.I),
    re.compile(r"<\s*script[\s>]", re.I),
    re.compile(r"do\s+anything\s+now", re.I),
    re.compile(r"\bDAN\b"),
    re.compile(r"override\s+(your\s+)?(guardrails|restrictions|rules)", re.I),
]

_HTML_TAG_PATTERN = re.compile(r"<[^>]+>")


def _strip_html(text: str) -> str:
    """Remove HTML tags and unescape entities, collapsing to plain text."""
    without_tags = _HTML_TAG_PATTERN.sub("", text)
    return html.unescape(without_tags)


def detect_injection_signature(text: str) -> str | None:
    """Return the matched injection-signature pattern text if `text` matches
    any known prompt-injection signature, else None.
    """
    for pattern in _INJECTION_SIGNATURES:
        match = pattern.search(text)
        if match:
            return match.group(0)
    return None


def sanitize_free_text(
    text: str,
    field_name: str = "text",
    max_length: int = MAX_FREE_TEXT_LENGTH,
) -> str:
    """Sanitise free-text input per §4: length limit, HTML stripping, and
    regex-based prompt-injection signature detection.

    Returns the cleaned text on success. Raises UnsafeInputError if the
    text is too long or matches an injection signature -- callers must let
    this propagate as a typed tool error rather than silently truncating
    and proceeding.

    Applied to every outbound message body (send_customer_communication)
    and any other free-text tool input, per spec.
    """
    if text is None:
        raise UnsafeInputError("text is required and cannot be None", field_name)

    if len(text) > max_length:
        raise UnsafeInputError(
            f"text exceeds maximum length of {max_length} characters "
            f"(got {len(text)})",
            field_name,
        )

    signature = detect_injection_signature(text)
    if signature is not None:
        raise UnsafeInputError(
            f"text matched a known prompt-injection signature near "
            f"{signature!r}",
            field_name,
        )

    return _strip_html(text).strip()


# --------------------------------------------------------------------------
# PII redaction for structured logging
# --------------------------------------------------------------------------

# Argument names treated as PII-shaped and therefore always redacted before
# a log line is emitted, regardless of which function they appear in. This
# is intentionally name-based (not type-based) because it's deterministic
# and auditable, and it errs toward over-redacting rather than under-redacting.
PII_ARGUMENT_NAMES: frozenset[str] = frozenset({
    "account_id",
    "account_number",
    "customer_id",
    "phone",
    "phone_number",
    "email",
    "message",   # free-text message bodies may contain PII the caller typed
    "name",
    "customer_name",
})


def _redact_value(value: Any) -> str:
    """Produce a redacted placeholder that still hints at shape, for
    debuggability, without revealing the actual value.
    """
    if value is None:
        return "<redacted:none>"
    text = str(value)
    if len(text) <= 4:
        return "<redacted>"
    return f"<redacted:len={len(text)}>"


def redact_for_logging(arguments: dict[str, Any]) -> dict[str, Any]:
    """Return a copy of `arguments` with PII-shaped keys redacted.

    This supports data-minimisation (§4) by ensuring account/customer
    identifiers and contact details never reach a structured log line in
    plaintext -- log aggregation systems, log shipping, and anyone with
    read access to logs should not be a secondary channel for PII exposure.
    Intended to be passed as the `redact=` argument to @trace().
    """
    redacted = {}
    for key, value in arguments.items():
        if key in PII_ARGUMENT_NAMES:
            redacted[key] = _redact_value(value)
        elif isinstance(value, dict):
            redacted[key] = redact_for_logging(value)
        else:
            redacted[key] = value
    return redacted

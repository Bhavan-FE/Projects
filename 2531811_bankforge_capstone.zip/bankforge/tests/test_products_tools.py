"""
tests/test_products_tools.py
===============================
Exercises products_server's five tools' business logic directly, with
particular attention to submit_loan_application's KYC gate -- the
pivotal write path called out in §3.1.
"""

from __future__ import annotations

import pytest

import guardrails
from products_server import tools


def test_list_loan_products_returns_all_by_default(fresh_db):
    results = tools.list_loan_products()
    product_ids = {p["product_id"] for p in results}
    assert "PROD-PL-01" in product_ids
    assert len(results) == 4


def test_list_loan_products_filters_by_category(fresh_db):
    results = tools.list_loan_products(category="personal")
    assert all(p["category"] == "personal" for p in results)
    assert len(results) == 1


def test_get_loan_product_details_returns_product(fresh_db):
    product = tools.get_loan_product_details("PROD-PL-01")
    assert product["name"] == "Personal Loan Standard"


def test_get_loan_product_details_missing_product_raises(fresh_db):
    with pytest.raises(tools.ProductNotFoundError):
        tools.get_loan_product_details("PROD-ZZ-99")


def test_get_loan_product_details_malformed_id_raises(fresh_db):
    with pytest.raises(guardrails.InvalidIdFormatError):
        tools.get_loan_product_details("PROD-1-1")


def test_check_eligibility_low_risk_eligible_for_medium_max(fresh_db):
    result = tools.check_eligibility_criteria("PROD-PL-01", "low")
    assert result["eligible"] is True


def test_check_eligibility_high_risk_ineligible_for_medium_max(fresh_db):
    result = tools.check_eligibility_criteria("PROD-PL-01", "high")
    assert result["eligible"] is False


def test_check_eligibility_does_not_write_anything(fresh_db):
    """Eligibility checking must never create a loan_applications row --
    only submit_loan_application does that (§3.1's explicit distinction).
    """
    import database

    before = database.get_connection(fresh_db).execute(
        "SELECT COUNT(*) AS c FROM loan_applications"
    ).fetchone()["c"]

    tools.check_eligibility_criteria("PROD-PL-01", "low")

    after = database.get_connection(fresh_db).execute(
        "SELECT COUNT(*) AS c FROM loan_applications"
    ).fetchone()["c"]

    assert before == after == 0


def test_check_eligibility_invalid_risk_rating_raises(fresh_db):
    with pytest.raises(ValueError):
        tools.check_eligibility_criteria("PROD-PL-01", "extreme")


def test_submit_loan_application_succeeds_for_verified_kyc(fresh_db):
    application = tools.submit_loan_application(
        "CUS-10042", "PROD-PL-01", 200000.0, kyc_status="verified"
    )
    assert application["status"] == "submitted"
    assert application["customer_id"] == "CUS-10042"


def test_submit_loan_application_blocked_for_unverified_kyc(fresh_db):
    with pytest.raises(guardrails.KycGateBlockedError):
        tools.submit_loan_application(
            "CUS-20077", "PROD-PL-01", 100000.0, kyc_status="unverified"
        )


def test_submit_loan_application_blocked_kyc_writes_no_row(fresh_db):
    """A KYC-blocked submission must not leave a partial/rejected row
    behind -- the gate fires before any write happens.
    """
    import database

    try:
        tools.submit_loan_application(
            "CUS-20077", "PROD-PL-01", 100000.0, kyc_status="unverified"
        )
    except guardrails.KycGateBlockedError:
        pass

    row_count = database.get_connection(fresh_db).execute(
        "SELECT COUNT(*) AS c FROM loan_applications WHERE customer_id = 'CUS-20077'"
    ).fetchone()["c"]
    assert row_count == 0


def test_submit_loan_application_amount_below_minimum_raises(fresh_db):
    with pytest.raises(tools.InvalidAmountError):
        tools.submit_loan_application(
            "CUS-10042", "PROD-PL-01", 100.0, kyc_status="verified"
        )


def test_submit_loan_application_amount_above_maximum_raises(fresh_db):
    with pytest.raises(tools.InvalidAmountError):
        tools.submit_loan_application(
            "CUS-10042", "PROD-PL-01", 5_000_000.0, kyc_status="verified"
        )


def test_submit_loan_application_missing_product_raises(fresh_db):
    with pytest.raises(tools.ProductNotFoundError):
        tools.submit_loan_application(
            "CUS-10042", "PROD-ZZ-99", 100000.0, kyc_status="verified"
        )


def test_submit_loan_application_malformed_customer_id_raises(fresh_db):
    with pytest.raises(guardrails.InvalidIdFormatError):
        tools.submit_loan_application(
            "NOT-A-CUSTOMER", "PROD-PL-01", 100000.0, kyc_status="verified"
        )


def test_get_loan_application_status_returns_submitted_application(fresh_db):
    application = tools.submit_loan_application(
        "CUS-10042", "PROD-PL-01", 150000.0, kyc_status="verified"
    )
    status = tools.get_loan_application_status(application["application_id"])
    assert status["application_id"] == application["application_id"]
    assert status["status"] == "submitted"


def test_get_loan_application_status_missing_application_raises(fresh_db):
    with pytest.raises(tools.ApplicationNotFoundError):
        tools.get_loan_application_status("APP-DOES-NOT-EXIST")

"""
tests/test_logging_config.py
===============================
Unit coverage for logging_config.py: the @trace decorator's ENTER/EXIT/
FAILED behavior and structured JSON output. §6 calls for inspecting this
output line by line before submission -- these tests capture the emitted
log records directly (via a custom handler) rather than parsing stdout,
so assertions are precise regardless of terminal formatting.
"""

from __future__ import annotations

import json
import logging

import pytest

from logging_config import get_logger, trace


class _CapturingHandler(logging.Handler):
    """Collects formatted log lines in memory so tests can inspect them."""

    def __init__(self):
        super().__init__()
        self.lines: list[str] = []

    def emit(self, record: logging.LogRecord) -> None:
        self.lines.append(self.format(record))


def _make_captured_logger(name: str):
    logger = get_logger(name)
    # Remove any existing stdout handler's formatter dependency and attach
    # our own capturing handler using the same JSON formatter class the
    # real handler uses, so we test the real formatting path.
    from logging_config import _JsonLineFormatter

    handler = _CapturingHandler()
    handler.setFormatter(_JsonLineFormatter())
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)
    return logger, handler


def test_trace_emits_enter_and_exit_on_success():
    logger, handler = _make_captured_logger("test_trace_success")

    @trace(logger)
    def add(a, b):
        return a + b

    result = add(2, 3)
    assert result == 5

    events = [json.loads(line)["event"] for line in handler.lines]
    assert events == ["ENTER", "EXIT"]


def test_trace_enter_line_contains_function_name_and_call_id():
    logger, handler = _make_captured_logger("test_trace_enter_fields")

    @trace(logger)
    def greet(name):
        return f"hello {name}"

    greet("Priya")

    enter_record = json.loads(handler.lines[0])
    assert enter_record["event"] == "ENTER"
    assert "greet" in enter_record["function"]
    assert "call_id" in enter_record
    assert enter_record["arguments"] == {"name": "Priya"}


def test_trace_exit_line_contains_duration_and_preview():
    logger, handler = _make_captured_logger("test_trace_exit_fields")

    @trace(logger)
    def compute():
        return {"ok": True}

    compute()

    exit_record = json.loads(handler.lines[1])
    assert exit_record["event"] == "EXIT"
    assert "duration_ms" in exit_record
    assert exit_record["duration_ms"] >= 0
    assert "ok" in exit_record["return_preview"]


def test_trace_enter_and_exit_share_call_id():
    logger, handler = _make_captured_logger("test_trace_call_id_consistency")

    @trace(logger)
    def noop():
        return None

    noop()

    enter_record = json.loads(handler.lines[0])
    exit_record = json.loads(handler.lines[1])
    assert enter_record["call_id"] == exit_record["call_id"]


def test_trace_emits_failed_on_exception_and_reraises():
    logger, handler = _make_captured_logger("test_trace_failure")

    @trace(logger)
    def boom():
        raise ValueError("simulated failure")

    with pytest.raises(ValueError, match="simulated failure"):
        boom()

    events = [json.loads(line)["event"] for line in handler.lines]
    assert events == ["ENTER", "FAILED"]

    failed_record = json.loads(handler.lines[1])
    assert failed_record["exception_type"] == "ValueError"
    assert "Traceback" in failed_record["traceback"]
    assert "duration_ms" in failed_record


def test_trace_applies_redact_function_to_enter_arguments():
    logger, handler = _make_captured_logger("test_trace_redaction")

    def fake_redact(args):
        return {k: "REDACTED" if k == "secret" else v for k, v in args.items()}

    @trace(logger, redact=fake_redact)
    def handle(secret, public):
        return "done"

    handle(secret="sensitive-value", public="fine")

    enter_record = json.loads(handler.lines[0])
    assert enter_record["arguments"]["secret"] == "REDACTED"
    assert enter_record["arguments"]["public"] == "fine"


def test_trace_without_redact_logs_arguments_plainly():
    logger, handler = _make_captured_logger("test_trace_no_redaction")

    @trace(logger)
    def handle(value):
        return value

    handle(value="plain-value")

    enter_record = json.loads(handler.lines[0])
    assert enter_record["arguments"]["value"] == "plain-value"


def test_all_log_lines_are_valid_single_line_json():
    logger, handler = _make_captured_logger("test_trace_json_validity")

    @trace(logger)
    def f(x):
        return x * 2

    f(21)

    for line in handler.lines:
        assert "\n" not in line
        parsed = json.loads(line)  # raises if not valid JSON
        assert "timestamp" in parsed
        assert "level" in parsed


def test_return_preview_is_truncated_for_large_output():
    logger, handler = _make_captured_logger("test_trace_truncation")

    @trace(logger)
    def big_output():
        return {"data": "x" * 2000}

    big_output()

    exit_record = json.loads(handler.lines[1])
    assert "truncated" in exit_record["return_preview"]
    assert len(exit_record["return_preview"]) < 2000

"""
tests/conftest.py
===================
Shared pytest fixtures for the BankForge test suite.

The key fixture is `fresh_db`, which points BANKFORGE_DB_PATH at a
temporary SQLite file, (re)initialises the schema, and seeds it -- so
every test function gets a clean, isolated database rather than sharing
mutable state with other tests or with the developer's own neobank.db.

This also adds `_mcp_stub` to sys.path at collection time, so `import
mcp.server.fastmcp` resolves to the local stub during test runs. See
README.md for how this is swapped out when the real `mcp` package is
available.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

import pytest

PROJECT_ROOT = Path(__file__).parent.parent
STUB_PATH = PROJECT_ROOT / "_mcp_stub"

# Make the local FastMCP stub importable as `mcp` for the duration of the
# test session, and make the project root importable so `import database`,
# `import guardrails`, `import accounts_server`, etc. resolve.
sys.path.insert(0, str(STUB_PATH))
sys.path.insert(0, str(PROJECT_ROOT))

import database  # noqa: E402  (import after sys.path manipulation, intentional)


@pytest.fixture()
def fresh_db(tmp_path, monkeypatch):
    """Point database.DEFAULT_DB_PATH at a fresh temp file, schema-init and
    seed it, and make sure any module that already imported
    `database.DEFAULT_DB_PATH` as a default argument still gets redirected
    -- by patching the module attribute itself, every call to
    database.connection_scope() with no explicit path argument uses the
    temp file for the duration of the test.
    """
    db_path = str(tmp_path / "neobank_test.db")
    monkeypatch.setattr(database, "DEFAULT_DB_PATH", db_path)
    database.init_schema(db_path)
    database.seed_data(db_path)
    return db_path

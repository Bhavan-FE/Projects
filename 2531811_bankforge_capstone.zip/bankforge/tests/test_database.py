"""
tests/test_database.py
=========================
Unit coverage for database.py: schema creation, WAL mode, and seed data
correctness. Run directly (not just written) per §6.
"""

from __future__ import annotations

import sqlite3

import database


def test_init_schema_creates_all_required_tables(fresh_db):
    conn = database.get_connection(fresh_db)
    tables = {
        row["name"]
        for row in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ).fetchall()
    }
    conn.close()

    expected = {
        "customers", "accounts", "transactions", "loan_products",
        "loan_applications", "communications_log", "fraud_flags", "audit_log",
    }
    assert expected.issubset(tables)


def test_wal_mode_is_enabled(fresh_db):
    conn = database.get_connection(fresh_db)
    mode = conn.execute("PRAGMA journal_mode;").fetchone()[0]
    conn.close()
    assert mode.lower() == "wal"


def test_seed_data_creates_showcase_customer(fresh_db):
    conn = database.get_connection(fresh_db)
    row = conn.execute(
        "SELECT * FROM customers WHERE customer_id = 'CUS-10042'"
    ).fetchone()
    conn.close()

    assert row is not None
    assert row["name"] == "Priya Sharma"
    assert row["kyc_status"] == "verified"


def test_seed_data_creates_showcase_product(fresh_db):
    conn = database.get_connection(fresh_db)
    row = conn.execute(
        "SELECT * FROM loan_products WHERE product_id = 'PROD-PL-01'"
    ).fetchone()
    conn.close()

    assert row is not None
    assert row["max_risk_rating"] == "medium"


def test_missing_customer_stress_fixture_is_not_seeded(fresh_db):
    """CUS-99999 must be well-formed but absent, per Stress Test 1."""
    conn = database.get_connection(fresh_db)
    row = conn.execute(
        "SELECT * FROM customers WHERE customer_id = 'CUS-99999'"
    ).fetchone()
    conn.close()
    assert row is None


def test_unverified_kyc_customer_seeded_for_stress_tests(fresh_db):
    conn = database.get_connection(fresh_db)
    row = conn.execute(
        "SELECT * FROM customers WHERE customer_id = 'CUS-20077'"
    ).fetchone()
    conn.close()

    assert row is not None
    assert row["kyc_status"] == "unverified"


def test_large_transaction_seeded_for_showcase_customer(fresh_db):
    conn = database.get_connection(fresh_db)
    rows = conn.execute(
        "SELECT * FROM transactions WHERE account_id = 'ACC-10042' "
        "ORDER BY amount DESC LIMIT 1"
    ).fetchall()
    conn.close()

    assert len(rows) == 1
    assert rows[0]["amount"] >= 1_000_000.0


def test_seed_data_is_idempotent(fresh_db):
    """Re-seeding must not duplicate rows or raise a constraint error."""
    database.seed_data(fresh_db)
    database.seed_data(fresh_db)

    conn = database.get_connection(fresh_db)
    count = conn.execute("SELECT COUNT(*) AS c FROM customers").fetchone()["c"]
    conn.close()
    assert count == 3  # still exactly the 3 seeded customers, not 9


def test_connection_scope_commits_on_success(fresh_db):
    with database.connection_scope(fresh_db) as conn:
        conn.execute(
            "INSERT INTO fraud_flags (flag_id, customer_id, reason) "
            "VALUES ('FLAG-TEST', 'CUS-10042', 'test reason')"
        )

    conn = database.get_connection(fresh_db)
    row = conn.execute(
        "SELECT * FROM fraud_flags WHERE flag_id = 'FLAG-TEST'"
    ).fetchone()
    conn.close()
    assert row is not None


def test_connection_scope_rolls_back_on_exception(fresh_db):
    try:
        with database.connection_scope(fresh_db) as conn:
            conn.execute(
                "INSERT INTO fraud_flags (flag_id, customer_id, reason) "
                "VALUES ('FLAG-ROLLBACK', 'CUS-10042', 'should not persist')"
            )
            raise RuntimeError("simulated failure mid-transaction")
    except RuntimeError:
        pass

    conn = database.get_connection(fresh_db)
    row = conn.execute(
        "SELECT * FROM fraud_flags WHERE flag_id = 'FLAG-ROLLBACK'"
    ).fetchone()
    conn.close()
    assert row is None

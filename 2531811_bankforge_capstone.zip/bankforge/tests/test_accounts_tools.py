"""
tests/test_accounts_tools.py
===============================
Exercises accounts_server's three tools' business logic directly (per §6:
"exercise every tool function").
"""

from __future__ import annotations

import pytest

import guardrails
from accounts_server import tools


def test_get_account_summary_teller_scope(fresh_db):
    result = tools.get_account_summary("ACC-10042", "teller")
    assert result["account_id"] == "ACC-10042"
    assert "customer_id" not in result
    assert result["account_number"] == "*********0042"


def test_get_account_summary_admin_scope_sees_more_fields(fresh_db):
    result = tools.get_account_summary("ACC-10042", "admin")
    assert "customer_id" in result
    assert "kyc_status" in result


def test_get_account_summary_missing_account_raises(fresh_db):
    with pytest.raises(tools.AccountNotFoundError):
        tools.get_account_summary("ACC-99999", "teller")


def test_get_account_summary_malformed_id_raises(fresh_db):
    with pytest.raises(guardrails.InvalidIdFormatError):
        tools.get_account_summary("NOT-AN-ID", "teller")


def test_get_account_summary_invalid_scope_raises(fresh_db):
    with pytest.raises(guardrails.InvalidScopeError):
        tools.get_account_summary("ACC-10042", "superuser")


def test_get_accounts_for_customer_returns_all_accounts(fresh_db):
    results = tools.get_accounts_for_customer("CUS-10042", "loan_officer")
    account_ids = {r["account_id"] for r in results}
    assert account_ids == {"ACC-10042", "ACC-10043"}


def test_get_accounts_for_customer_missing_customer_raises(fresh_db):
    with pytest.raises(tools.CustomerNotFoundError):
        tools.get_accounts_for_customer("CUS-99999", "teller")


def test_get_accounts_for_customer_with_no_accounts_returns_empty_list(fresh_db):
    # CUS-30015 exists but has exactly one account in seed data; verify a
    # customer with accounts returns a non-empty list, and that the
    # function's contract (empty list vs exception) is list-shaped, not
    # an exception, when accounts legitimately number zero. We simulate
    # zero accounts by using a customer that exists but query a scope
    # that still returns a list type either way.
    results = tools.get_accounts_for_customer("CUS-30015", "teller")
    assert isinstance(results, list)
    assert len(results) == 1


def test_get_transaction_history_orders_most_recent_first(fresh_db):
    results = tools.get_transaction_history("ACC-10042", limit=10)
    occurred_ats = [r["occurred_at"] for r in results]
    assert occurred_ats == sorted(occurred_ats, reverse=True)


def test_get_transaction_history_respects_limit(fresh_db):
    results = tools.get_transaction_history("ACC-10042", limit=1)
    assert len(results) == 1


def test_get_transaction_history_missing_account_raises(fresh_db):
    with pytest.raises(tools.AccountNotFoundError):
        tools.get_transaction_history("ACC-99999", limit=5)


def test_get_transaction_history_invalid_limit_raises(fresh_db):
    with pytest.raises(ValueError):
        tools.get_transaction_history("ACC-10042", limit=0)


def test_get_transaction_history_includes_large_transaction(fresh_db):
    results = tools.get_transaction_history("ACC-10042", limit=10)
    amounts = [r["amount"] for r in results]
    assert any(amount >= 1_000_000.0 for amount in amounts)

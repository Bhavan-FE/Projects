"""
tests/test_resources.py
=========================
Exercises the 4 required MCP Resources (§7): customer://, account://,
product://, template://. Verifies they reuse guardrail functions (masking
shows up in account:// output) and return typed errors for missing data.
"""

from __future__ import annotations

import pytest

import guardrails
import resources
from accounts_server import tools as accounts_tools
from compliance_comms_server import tools as compliance_tools
from products_server import tools as products_tools


def test_customer_profile_resource_returns_non_sensitive_fields(fresh_db):
    profile = resources.customer_profile_resource("CUS-10042")
    assert profile["name"] == "Priya Sharma"
    assert "kyc_status" not in profile  # raw KYC stays behind get_kyc_status
    assert "email" not in profile
    assert "phone" not in profile


def test_customer_profile_resource_missing_customer_raises(fresh_db):
    with pytest.raises(compliance_tools.CustomerNotFoundError):
        resources.customer_profile_resource("CUS-99999")


def test_customer_profile_resource_malformed_id_raises(fresh_db):
    with pytest.raises(guardrails.InvalidIdFormatError):
        resources.customer_profile_resource("NOT-A-CUSTOMER")


def test_account_summary_resource_masks_account_number(fresh_db):
    summary = resources.account_summary_resource("ACC-10042")
    assert summary["account_number"] == "*********0042"


def test_account_summary_resource_missing_account_raises(fresh_db):
    with pytest.raises(accounts_tools.AccountNotFoundError):
        resources.account_summary_resource("ACC-99999")


def test_product_details_resource_returns_product(fresh_db):
    details = resources.product_details_resource("PROD-PL-01")
    assert details["name"] == "Personal Loan Standard"


def test_product_details_resource_missing_product_raises(fresh_db):
    with pytest.raises(products_tools.ProductNotFoundError):
        resources.product_details_resource("PROD-ZZ-99")


def test_template_resource_returns_raw_markdown(fresh_db):
    result = resources.template_resource("loan_approved")
    assert result["template_name"] == "loan_approved"
    assert "{customer_name}" in result["raw_markdown"]


def test_template_resource_missing_template_raises(fresh_db):
    with pytest.raises(compliance_tools.TemplateNotFoundError):
        resources.template_resource("does_not_exist")

"""
tests/test_server_isolation.py
=================================
Asserts, programmatically, the structural isolation claim from §3's note:
"products_server should be structurally unable to query customer data,
and each server should only be able to reach the tables its own
responsibility requires." This is checked by static inspection of each
repository module's source (grepping for table names it must never
reference) rather than by behavioral testing alone, since the whole point
is that the *possibility* of cross-domain access shouldn't exist in the
code, not just that no test happens to trigger it.
"""

from __future__ import annotations

import inspect
from pathlib import Path

import accounts_server.repository as accounts_repo
import compliance_comms_server.repository as compliance_repo
import products_server.repository as products_repo

FORBIDDEN_TABLES_BY_SERVER = {
    accounts_repo: {
        "loan_products", "loan_applications", "communications_log",
        "fraud_flags", "audit_log",
    },
    products_repo: {
        "customers", "accounts", "transactions",
        "communications_log", "fraud_flags", "audit_log",
    },
    compliance_repo: {
        "accounts", "transactions", "loan_products", "loan_applications",
    },
}


def _source_without_comments_and_docstrings(module) -> str:
    """Return the module's source code with its module-level docstring
    removed, so mentions of forbidden table names in explanatory prose
    (which every repository.py's docstring deliberately contains, to
    document what it does NOT touch) don't produce false positives.
    """
    source = inspect.getsource(module)
    doc = inspect.getdoc(module) or ""
    if doc:
        # Strip the first triple-quoted block, which is the module docstring.
        first_quote = source.find('"""')
        second_quote = source.find('"""', first_quote + 3)
        if first_quote != -1 and second_quote != -1:
            source = source[second_quote + 3:]
    return source


def test_accounts_repository_never_references_forbidden_tables():
    source = _source_without_comments_and_docstrings(accounts_repo)
    for table in FORBIDDEN_TABLES_BY_SERVER[accounts_repo]:
        assert table not in source, (
            f"accounts_server/repository.py references forbidden table "
            f"'{table}' -- isolation is violated"
        )


def test_products_repository_never_references_forbidden_tables():
    source = _source_without_comments_and_docstrings(products_repo)
    for table in FORBIDDEN_TABLES_BY_SERVER[products_repo]:
        assert table not in source, (
            f"products_server/repository.py references forbidden table "
            f"'{table}' -- isolation is violated"
        )


def test_compliance_repository_never_references_forbidden_tables():
    source = _source_without_comments_and_docstrings(compliance_repo)
    for table in FORBIDDEN_TABLES_BY_SERVER[compliance_repo]:
        assert table not in source, (
            f"compliance_comms_server/repository.py references forbidden "
            f"table '{table}' -- isolation is violated"
        )


def test_products_repository_has_no_import_of_other_server_repositories():
    """products_server must have no import path to accounts_server or
    compliance_comms_server's repository modules -- checked via the
    module's actual import statements, not just table-name grepping.
    Docstring prose describing what is deliberately NOT imported is
    excluded, since that prose legitimately names the other servers.
    """
    source = _source_without_comments_and_docstrings(products_repo)
    assert "accounts_server" not in source
    assert "compliance_comms_server" not in source


def test_accounts_repository_has_no_import_of_other_server_repositories():
    source = _source_without_comments_and_docstrings(accounts_repo)
    assert "products_server" not in source
    assert "compliance_comms_server" not in source


def test_compliance_repository_has_no_import_of_other_server_repositories():
    source = _source_without_comments_and_docstrings(compliance_repo)
    assert "accounts_server" not in source
    assert "products_server" not in source


def test_products_server_tools_never_import_customer_repositories():
    """Even one level up from repository.py, products_server/tools.py
    must not reach for another server's repository module as a
    workaround.
    """
    import products_server.tools as products_tools
    source = _source_without_comments_and_docstrings(products_tools)
    assert "accounts_server.repository" not in source
    assert "compliance_comms_server.repository" not in source

"""
tests/test_mcp_registration.py
=================================
Verifies that each server registers the exact tool/resource/prompt
inventory required by §3.1 and §7, via the FastMCP `mcp` object each
server's __main__.py constructs.

IMPORTANT -- READ BEFORE TRUSTING THIS FILE ALONE:
This currently runs against _mcp_stub's local FastMCP stand-in, because
this development environment has no network access to install the real
`mcp` package (see README.md). §6 explicitly requires re-verifying
registration against the REAL mcp package before submission -- these
tests passing here is necessary but not sufficient. Once you have
network access:

    pip install mcp
    # remove _mcp_stub from sys.path / PYTHONPATH
    pytest tests/test_mcp_registration.py -v

These tests should pass unchanged against the real package, since they
only call methods (list_tool_names, list_resource_templates,
list_prompt_names, call_tool, read_resource, get_prompt) that mirror the
real FastMCP's introspectable surface closely. If the real package's
introspection API differs, that is exactly the kind of gap this
re-verification step exists to catch.
"""

from __future__ import annotations

import importlib


def _reload_server_main(module_name: str):
    """Import (or reload) a server's __main__ module fresh, so each test
    gets its own FastMCP instance rather than sharing mutated global state
    across test files that also import these modules.
    """
    if module_name in importlib.sys.modules:
        return importlib.reload(importlib.sys.modules[module_name])
    return importlib.import_module(module_name)


def test_accounts_server_registers_exactly_its_three_tools(fresh_db):
    main = _reload_server_main("accounts_server.__main__")
    assert main.mcp.list_tool_names() == sorted([
        "get_account_summary",
        "get_accounts_for_customer",
        "get_transaction_history",
    ])


def test_accounts_server_registers_its_resource_and_prompt(fresh_db):
    main = _reload_server_main("accounts_server.__main__")
    assert main.mcp.list_resource_templates() == ["account://{account_id}/summary"]
    assert main.mcp.list_prompt_names() == ["transaction_analysis_prompt"]


def test_products_server_registers_exactly_its_five_tools(fresh_db):
    main = _reload_server_main("products_server.__main__")
    assert main.mcp.list_tool_names() == sorted([
        "list_loan_products",
        "get_loan_product_details",
        "check_eligibility_criteria",
        "submit_loan_application",
        "get_loan_application_status",
    ])


def test_products_server_registers_its_resource(fresh_db):
    main = _reload_server_main("products_server.__main__")
    assert main.mcp.list_resource_templates() == ["product://{product_id}/details"]


def test_compliance_comms_server_registers_exactly_its_six_tools(fresh_db):
    main = _reload_server_main("compliance_comms_server.__main__")
    assert main.mcp.list_tool_names() == sorted([
        "get_kyc_status",
        "run_compliance_check",
        "send_customer_communication",
        "get_fraud_flags",
        "write_audit_log",
        "generate_customer_communication",
    ])


def test_compliance_comms_server_registers_its_resources_and_prompt(fresh_db):
    main = _reload_server_main("compliance_comms_server.__main__")
    assert set(main.mcp.list_resource_templates()) == {
        "customer://{customer_id}/profile",
        "template://{template_name}",
    }
    assert main.mcp.list_prompt_names() == ["customer_communication_prompt"]


def test_total_tool_count_across_all_servers_is_fourteen(fresh_db):
    """§3.1: 14 Tools total across the three servers."""
    accounts_main = _reload_server_main("accounts_server.__main__")
    products_main = _reload_server_main("products_server.__main__")
    compliance_main = _reload_server_main("compliance_comms_server.__main__")

    total = (
        len(accounts_main.mcp.list_tool_names())
        + len(products_main.mcp.list_tool_names())
        + len(compliance_main.mcp.list_tool_names())
    )
    assert total == 14


def test_total_resource_count_across_all_servers_is_four(fresh_db):
    """§7: 4 Resources total."""
    accounts_main = _reload_server_main("accounts_server.__main__")
    products_main = _reload_server_main("products_server.__main__")
    compliance_main = _reload_server_main("compliance_comms_server.__main__")

    total = (
        len(accounts_main.mcp.list_resource_templates())
        + len(products_main.mcp.list_resource_templates())
        + len(compliance_main.mcp.list_resource_templates())
    )
    assert total == 4


def test_total_prompt_count_across_all_servers_is_two(fresh_db):
    """§7: 2 Prompts total."""
    accounts_main = _reload_server_main("accounts_server.__main__")
    products_main = _reload_server_main("products_server.__main__")
    compliance_main = _reload_server_main("compliance_comms_server.__main__")

    total = (
        len(accounts_main.mcp.list_prompt_names())
        + len(products_main.mcp.list_prompt_names())
        + len(compliance_main.mcp.list_prompt_names())
    )
    assert total == 2


def test_tool_call_through_mcp_registration_matches_direct_call(fresh_db):
    """Sanity check that calling a tool THROUGH the FastMCP registration
    layer produces the same result as calling the underlying tools.py
    function directly -- i.e. the __main__.py wrapper isn't silently
    dropping or mutating arguments.
    """
    from accounts_server import tools as accounts_tools

    main = _reload_server_main("accounts_server.__main__")
    via_mcp = main.mcp.call_tool("get_account_summary", account_id="ACC-10042", caller_scope="teller")
    direct = accounts_tools.get_account_summary("ACC-10042", "teller")
    assert via_mcp == direct

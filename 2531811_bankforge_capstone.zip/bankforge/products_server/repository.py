"""
products_server/repository.py
================================
The ONLY module in products_server permitted to open a database connection
or issue SQL. Per §3's isolation note, products_server must be
"structurally unable to query customer data" -- this module only ever
touches loan_products and loan_applications. It has no function that
accepts or returns a customers/accounts row, and no import of
accounts_server or compliance_comms_server code. That's what makes the
isolation a property you can verify by reading this one file, rather than
trusting that tools.py "just happens" not to reach further.

Note: submit_loan_application takes a customer_id as an *opaque identifier*
to stamp onto the loan_applications row -- it never looks the customer up,
never joins against a customers table (products_server has no such table
in scope), and the KYC check that gates submission is performed by the
caller (tools.py) using a kyc_status value passed in, not fetched here.
See docs/architecture.md for why the KYC status is passed in rather than
looked up by this server.
"""

from __future__ import annotations

import uuid
from typing import Any, Optional

import database


def fetch_all_products(category: Optional[str] = None) -> list[dict[str, Any]]:
    with database.connection_scope() as conn:
        if category is not None:
            rows = conn.execute(
                "SELECT * FROM loan_products WHERE category = ? ORDER BY product_id",
                (category,),
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT * FROM loan_products ORDER BY product_id"
            ).fetchall()
        return [dict(row) for row in rows]


def fetch_product(product_id: str) -> Optional[dict[str, Any]]:
    with database.connection_scope() as conn:
        row = conn.execute(
            "SELECT * FROM loan_products WHERE product_id = ?", (product_id,)
        ).fetchone()
        return dict(row) if row is not None else None


def insert_loan_application(
    customer_id: str, product_id: str, requested_amount: float
) -> dict[str, Any]:
    application_id = f"APP-{uuid.uuid4().hex[:10].upper()}"
    with database.connection_scope() as conn:
        conn.execute(
            """
            INSERT INTO loan_applications
                (application_id, customer_id, product_id, requested_amount, status)
            VALUES (?, ?, ?, ?, 'submitted')
            """,
            (application_id, customer_id, product_id, requested_amount),
        )
        row = conn.execute(
            "SELECT * FROM loan_applications WHERE application_id = ?",
            (application_id,),
        ).fetchone()
        return dict(row)


def fetch_application(application_id: str) -> Optional[dict[str, Any]]:
    with database.connection_scope() as conn:
        row = conn.execute(
            "SELECT * FROM loan_applications WHERE application_id = ?",
            (application_id,),
        ).fetchone()
        return dict(row) if row is not None else None

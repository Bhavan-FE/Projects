"""
products_server/tools.py
==========================
The five Tools owned by products_server (§3.1):
    list_loan_products(category)
    get_loan_product_details(product_id)
    check_eligibility_criteria(product_id, applicant_risk_rating)
    submit_loan_application(customer_id, product_id, requested_amount, kyc_status)
    get_loan_application_status(application_id)

submit_loan_application is the pivotal write tool called out in §3.1: no
other write in this project (KYC-gated comms, audit logging) can be
demonstrated end-to-end until this one exists, because it's the only way a
loan_applications row gets created at all. It enforces the KYC gate at the
TOOL level (guardrails.enforce_loan_application_kyc_gate), not leaving that
check to whatever AI client happens to call it -- per the explicit
requirement in §3.1's table.

Design note on kyc_status as a parameter: products_server has no
customers table in its data-access scope (see repository.py docstring), so
it cannot look up KYC status itself. The KYC status must be supplied by
the caller -- in practice, an AI client (or the demo script) is expected
to call compliance_comms_server.get_kyc_status(customer_id) first and pass
the result in. This keeps the "products_server cannot query customer
data" isolation guarantee intact while still letting the gate be enforced
here rather than trusted to the client's judgment. See
docs/architecture.md for the full rationale and the tradeoff this implies.
"""

from __future__ import annotations

from typing import Any, Optional

import guardrails
from logging_config import get_logger, trace

from . import repository

logger = get_logger(__name__)


class ProductNotFoundError(Exception):
    def __init__(self, product_id: str):
        self.product_id = product_id
        super().__init__(f"No loan product found with product_id '{product_id}'")


class ApplicationNotFoundError(Exception):
    def __init__(self, application_id: str):
        self.application_id = application_id
        super().__init__(f"No loan application found with application_id '{application_id}'")


class InvalidAmountError(Exception):
    def __init__(self, requested_amount: float, product: dict[str, Any]):
        self.requested_amount = requested_amount
        self.product = product
        super().__init__(
            f"Requested amount {requested_amount} is outside product "
            f"'{product['product_id']}' bounds "
            f"[{product['min_amount']}, {product['max_amount']}]"
        )


# Risk ratings ordered from most to least permissive, used to compare an
# applicant's rating against a product's max_risk_rating.
_RISK_ORDER = {"low": 0, "medium": 1, "high": 2}


@trace(logger, redact=guardrails.redact_for_logging)
def list_loan_products(category: Optional[str] = None) -> list[dict[str, Any]]:
    """Browse the loan product catalogue, optionally filtered by category."""
    return repository.fetch_all_products(category)


@trace(logger, redact=guardrails.redact_for_logging)
def get_loan_product_details(product_id: str) -> dict[str, Any]:
    """Look up a single loan product.

    Raises:
        guardrails.InvalidIdFormatError: product_id is malformed.
        ProductNotFoundError: product_id is well-formed but doesn't exist.
    """
    guardrails.validate_id_format("product_id", product_id)

    product = repository.fetch_product(product_id)
    if product is None:
        raise ProductNotFoundError(product_id)
    return product


@trace(logger, redact=guardrails.redact_for_logging)
def check_eligibility_criteria(product_id: str, applicant_risk_rating: str) -> dict[str, Any]:
    """Check-only: does NOT write anything and does NOT touch customer data
    -- applicant_risk_rating is supplied by the caller, not looked up here.

    Returns a dict: {"eligible": bool, "reason": str, "product_id": ...}

    Raises:
        guardrails.InvalidIdFormatError: product_id is malformed.
        ProductNotFoundError: product_id is well-formed but doesn't exist.
        ValueError: applicant_risk_rating is not one of low/medium/high.
    """
    guardrails.validate_id_format("product_id", product_id)

    if applicant_risk_rating not in _RISK_ORDER:
        raise ValueError(
            f"applicant_risk_rating must be one of {sorted(_RISK_ORDER)}, "
            f"got {applicant_risk_rating!r}"
        )

    product = repository.fetch_product(product_id)
    if product is None:
        raise ProductNotFoundError(product_id)

    eligible = _RISK_ORDER[applicant_risk_rating] <= _RISK_ORDER[product["max_risk_rating"]]
    reason = (
        "Applicant risk rating within product's accepted range"
        if eligible
        else (
            f"Applicant risk rating '{applicant_risk_rating}' exceeds "
            f"product's maximum accepted risk rating "
            f"'{product['max_risk_rating']}'"
        )
    )
    return {"eligible": eligible, "reason": reason, "product_id": product_id}


@trace(logger, redact=guardrails.redact_for_logging)
def submit_loan_application(
    customer_id: str,
    product_id: str,
    requested_amount: float,
    kyc_status: str,
) -> dict[str, Any]:
    """Create a loan application. Enforces the KYC gate at the tool level
    (§3.1, §4): verified KYC is required, or the call is blocked before any
    row is written.

    kyc_status is supplied by the caller (see module docstring) rather than
    looked up here, since products_server has no access to customer data.

    Raises:
        guardrails.InvalidIdFormatError: customer_id or product_id malformed.
        ProductNotFoundError: product_id well-formed but doesn't exist.
        guardrails.KycGateBlockedError: kyc_status is not 'verified'.
        InvalidAmountError: requested_amount outside the product's bounds.
    """
    guardrails.validate_id_format("customer_id", customer_id)
    guardrails.validate_id_format("product_id", product_id)

    # KYC gate enforced here, at the tool level, before any write happens --
    # this is the explicit requirement from §3.1/§4: the gate must not be
    # left to the AI client's discretion.
    guardrails.enforce_loan_application_kyc_gate(customer_id, kyc_status)

    product = repository.fetch_product(product_id)
    if product is None:
        raise ProductNotFoundError(product_id)

    if not (product["min_amount"] <= requested_amount <= product["max_amount"]):
        raise InvalidAmountError(requested_amount, product)

    return repository.insert_loan_application(customer_id, product_id, requested_amount)


@trace(logger, redact=guardrails.redact_for_logging)
def get_loan_application_status(application_id: str) -> dict[str, Any]:
    """Read back a previously submitted loan application's status.

    Raises:
        ApplicationNotFoundError: application_id doesn't exist.
    """
    application = repository.fetch_application(application_id)
    if application is None:
        raise ApplicationNotFoundError(application_id)
    return application

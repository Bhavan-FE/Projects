"""
products_server/__main__.py
==============================
FastMCP application entrypoint for products_server.

Run standalone with:
    python -m products_server

Owns: loan_products, loan_applications. No customer data. See
products_server/repository.py and tools.py docstrings for how isolation
and the KYC gate are structured.
"""

from __future__ import annotations

from typing import Optional

from mcp.server.fastmcp import FastMCP

import resources
from products_server import tools

mcp = FastMCP("products_server")


@mcp.resource("product://{product_id}/details")
def product_details_resource(product_id: str) -> dict:
    """Read-only loan product detail view. See
    resources.product_details_resource for the shared implementation.
    """
    return resources.product_details_resource(product_id)


@mcp.tool()
def list_loan_products(category: Optional[str] = None) -> list:
    """Browse the loan product catalogue, optionally filtered by category
    (personal/home/auto/business).
    """
    return tools.list_loan_products(category)


@mcp.tool()
def get_loan_product_details(product_id: str) -> dict:
    """Look up a single loan product by product_id (PROD-XX-XX)."""
    return tools.get_loan_product_details(product_id)


@mcp.tool()
def check_eligibility_criteria(product_id: str, applicant_risk_rating: str) -> dict:
    """Check-only eligibility: does not write anything, does not touch
    customer data. applicant_risk_rating must be low/medium/high.
    """
    return tools.check_eligibility_criteria(product_id, applicant_risk_rating)


@mcp.tool()
def submit_loan_application(
    customer_id: str, product_id: str, requested_amount: float, kyc_status: str
) -> dict:
    """Submit a loan application. Blocked at the tool level unless
    kyc_status is 'verified'. kyc_status should be obtained by first
    calling compliance_comms_server's get_kyc_status tool.
    """
    return tools.submit_loan_application(customer_id, product_id, requested_amount, kyc_status)


@mcp.tool()
def get_loan_application_status(application_id: str) -> dict:
    """Read back a previously submitted loan application's status."""
    return tools.get_loan_application_status(application_id)


if __name__ == "__main__":
    mcp.run()

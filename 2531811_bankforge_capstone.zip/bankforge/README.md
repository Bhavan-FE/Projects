# BankForge

A three-server MCP deployment for a fictional digital bank (NeoBank India),
built for the Week 5 MCP capstone. See `docs/architecture.md` for the full
design writeup, including an honest account of tradeoffs and open issues.

## A note on this build environment

This project was built in a sandboxed environment with **no network
access**, so the real `mcp` and `pytest` packages could not be installed
here. Two local stand-ins fill that gap so the project could still be
built, run, and tested end-to-end:

- `_mcp_stub/` — a local implementation of `mcp.server.fastmcp.FastMCP`
  matching the real package's public decorator API
  (`@mcp.tool()`, `@mcp.resource()`, `@mcp.prompt()`, `.run()`).
- `_pytest_stub/` — a minimal shim providing `pytest.raises` and
  `pytest.mark.parametrize`, the only two pytest features this suite uses.
- `run_tests_no_pytest.py` — a small pytest-compatible test runner, used
  instead of the `pytest` CLI in this environment.

**Before treating this as submission-ready, follow "Switching to the real
packages" below.** §6 of the assignment spec explicitly requires
re-verifying against the real `mcp` package and running the real `pytest`
before submission — this has not yet been done, because it could not be
done here.

## Prerequisites

- Python 3.11+
- pip, with network access to PyPI (for the real `mcp`/`pytest` packages)

## Setup

```bash
# 1. Create and activate a virtual environment
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt
pip install pytest               # if not already covered above

# 3. Build and seed the local database
python database.py --seed
```

This creates `neobank.db` in the project root, in WAL mode, seeded with:

- **Showcase Scenario data:** Priya Sharma (`CUS-10042`, verified KYC,
  `PROD-PL-01`-eligible)
- **Stress Test fixtures:** an unverified-KYC customer (`CUS-20077`) for
  KYC-gate tests, and a deliberately *absent* well-formed customer ID
  (`CUS-99999`) for the missing-customer stress test
- A large transaction on Priya's account, sized to trip the
  large-transaction reporting flag

Re-running `python database.py --seed` wipes and re-seeds; it's idempotent.

## Running the servers locally

Each server is a standalone process:

```bash
python -m accounts_server
python -m products_server
python -m compliance_comms_server
```

Point your MCP client (a Claude Desktop config entry, or the Anthropic
API's `mcp_servers` parameter) at each running process.

**In this build environment**, running the above commands starts the
servers against the local `_mcp_stub` FastMCP stand-in, which prints a
confirmation of how many tools/resources/prompts registered rather than
opening a live transport (since there's no real MCP client to connect to
here). Example output:

```
[stub] FastMCP server 'accounts_server' would start here (transport=stdio).
Registered 3 tools, 1 resources, 1 prompts.
Install the real 'mcp' package for live startup.
```

Once the real `mcp` package is installed (see below), these same commands
start real, live MCP servers with no code changes needed.

## Running the demo and the test suite

```bash
python run_local_demo.py     # exercises all required demo steps (§8), no live MCP client needed
```

`run_local_demo.py` seeds its own isolated temp database, so it doesn't
touch your `neobank.db`, and can be re-run repeatedly. It walks through,
in order: scoped field visibility, transaction history, product listing +
eligibility, the large-transaction flag, a KYC-blocked transaction, a
KYC-blocked marketing communication, a blocked prompt-injection attempt,
the full Showcase Scenario (Priya Sharma / `CUS-10042` / `PROD-PL-01`),
and all three Stress Tests.

```bash
# with real pytest installed:
pytest tests/ -v

# in this sandboxed build environment, without network access:
python run_tests_no_pytest.py
```

As of this writing, **151/151 tests pass** via the fallback runner.

## Switching to the real `mcp` and `pytest` packages

This is a required step before submission, not an optional cleanup task.

1. In an environment with network access:
   ```bash
   pip install mcp pytest
   ```
2. Remove the local stand-ins from the import path. Concretely: this
   project only adds `_mcp_stub/` and `_pytest_stub/` to `sys.path` inside
   `tests/conftest.py` and `run_tests_no_pytest.py`, and via `PYTHONPATH`
   when running servers directly from the shell. Once the real packages
   are installed, either:
   - delete the `_mcp_stub/` and `_pytest_stub/` directories entirely, or
   - simply stop adding them to `PYTHONPATH` / `sys.path` — Python's
     normal import resolution will then find the real, pip-installed
     `mcp` and `pytest` packages instead.
3. Re-run the full verification:
   ```bash
   pytest tests/ -v
   python -m accounts_server &
   python -m products_server &
   python -m compliance_comms_server &
   ```
   and confirm each server starts and responds to a live MCP client (e.g.
   Claude Desktop), per §6's explicit "this is a submission requirement,
   not optional."
4. Re-run `run_local_demo.py` (it has no dependency on `mcp` at all, since
   it calls each server's `tools.py` functions directly — it should behave
   identically before and after this switch).

No application code (`accounts_server/`, `products_server/`,
`compliance_comms_server/`, `guardrails.py`, `database.py`,
`logging_config.py`, `resources.py`, `prompts.py`) should need to change
as part of this switch. If it does, that's a sign the stub diverged from
the real package's API somewhere — see `docs/architecture.md` §7.1 for the
specific areas of uncertainty to check first (the introspection helper
methods `list_tool_names`, `list_resource_templates`, `list_prompt_names`,
`call_tool`, `read_resource`, `get_prompt` are our own additions for
testability, and may not exist on the real `FastMCP` class — the tests
that use them, `tests/test_mcp_registration.py`, are the ones most likely
to need adjustment).

## Project structure

```
bankforge/
├── database.py                      # schema, seed, WAL init
├── logging_config.py                # @trace(logger) decorator
├── guardrails.py                    # masking, scoping, KYC gates, sanitisation, redaction
├── resources.py                     # shared implementations of all 4 MCP Resources
├── prompts.py                       # shared implementations of both MCP Prompts
│
├── accounts_server/
│   ├── __main__.py                  # FastMCP app + tool/resource/prompt registration
│   ├── repository.py                # ONLY module touching accounts/customers/transactions
│   └── tools.py                     # get_account_summary, get_accounts_for_customer,
│                                     # get_transaction_history
│
├── products_server/
│   ├── __main__.py
│   ├── repository.py                # ONLY module touching loan_products/loan_applications
│   └── tools.py                     # list_loan_products, get_loan_product_details,
│                                     # check_eligibility_criteria, submit_loan_application,
│                                     # get_loan_application_status
│
├── compliance_comms_server/
│   ├── __main__.py
│   ├── repository.py                # ONLY module touching customers/communications_log/
│   │                                 # fraud_flags/audit_log
│   ├── tools.py                     # get_kyc_status, run_compliance_check,
│   │                                 # send_customer_communication, get_fraud_flags,
│   │                                 # write_audit_log, generate_customer_communication
│   └── communication_templates/     # Markdown templates rendered by
│       ├── loan_approved.md         # generate_customer_communication
│       ├── kyc_reminder.md
│       └── marketing_offer.md
│
├── tests/
│   ├── conftest.py                  # fresh_db fixture
│   ├── test_database.py
│   ├── test_guardrails.py
│   ├── test_logging_config.py
│   ├── test_accounts_tools.py
│   ├── test_products_tools.py
│   ├── test_compliance_tools.py
│   ├── test_resources.py
│   ├── test_prompts.py
│   ├── test_mcp_registration.py
│   └── test_server_isolation.py
│
├── _mcp_stub/                       # local FastMCP stand-in (see note above)
├── _pytest_stub/                    # local pytest shim (see note above)
├── run_tests_no_pytest.py           # fallback test runner
├── run_local_demo.py                # §8 demo script
├── requirements.txt
├── README.md
└── docs/
    └── architecture.md              # full design writeup incl. "what did not work"
```

## Known open issues

See `docs/architecture.md` §7 for the full, honest account. Briefly:

1. Real `mcp`/`pytest` verification is still outstanding (network access
   required, not available in this build environment).
2. `submit_loan_application`'s KYC gate trusts the caller's `kyc_status`
   argument rather than independently re-verifying it against
   `compliance_comms_server`, to preserve `products_server`'s data
   isolation. This is a deliberate tradeoff, documented in full.
3. Stress Test 3 ("compliance server offline") is ambiguous in the spec;
   we implemented two plausible readings rather than guessing one.

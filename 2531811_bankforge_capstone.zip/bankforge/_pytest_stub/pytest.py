"""
_pytest_stub/pytest.py
========================
A minimal shim exposing the small subset of pytest's public API this test
suite actually uses: `pytest.raises` (as a context manager) and
`pytest.mark.parametrize` (as a decorator that expands into multiple
underlying test functions our fallback runner can discover).

WHY THIS EXISTS
----------------
This sandbox has no network egress, so the real `pytest` package cannot
be installed here (see README.md). This shim exists solely so the test
suite -- written in ordinary pytest style -- can be executed in this
environment via run_tests_no_pytest.py, satisfying §6's "must be written
AND actually executed" requirement as far as this sandbox allows.

This is NOT a pytest reimplementation. It supports exactly two features:
`pytest.raises(ExpectedException)` and `@pytest.mark.parametrize(...)`.
No fixtures-via-injection beyond what run_tests_no_pytest.py already
special-cases (`fresh_db`), no plugins, no CLI, no collection beyond what
run_tests_no_pytest.py's glob-based discovery does.

TO SWITCH TO THE REAL PACKAGE
-------------------------------
1. In an environment with network access: `pip install pytest`
2. Remove `_pytest_stub` from PYTHONPATH / sys.path
3. Run `pytest tests/ -v` directly -- no code changes needed, since this
   shim's `raises` and `mark.parametrize` match the real API surface the
   tests use.
"""

from __future__ import annotations

import functools
from typing import Any, Type


class _RaisesContext:
    """Context manager mirroring pytest.raises(ExceptionType, match=...)."""

    def __init__(self, expected_exception: Type[BaseException], match: str | None = None):
        self.expected_exception = expected_exception
        self.match = match
        self.exception: BaseException | None = None

    def __enter__(self) -> "_RaisesContext":
        return self

    def __exit__(self, exc_type, exc_value, tb) -> bool:
        if exc_type is None:
            raise AssertionError(
                f"DID NOT RAISE {self.expected_exception!r}"
            )
        if not issubclass(exc_type, self.expected_exception):
            return False  # let the unexpected exception propagate
        if self.match is not None:
            import re
            if not re.search(self.match, str(exc_value)):
                raise AssertionError(
                    f"Pattern {self.match!r} did not match exception "
                    f"message {str(exc_value)!r}"
                )
        self.exception = exc_value
        return True  # suppress the expected exception


def raises(expected_exception: Type[BaseException], match: str | None = None) -> _RaisesContext:
    return _RaisesContext(expected_exception, match=match)


class _MarkDecoratorFactory:
    """Implements pytest.mark.parametrize as an attribute-marking decorator.

    The decorated function gets a `_pytest_stub_parametrize` attribute
    holding (argnames, argvalues) so run_tests_no_pytest.py's discovery
    step can expand it into one call per parameter set. This mirrors just
    enough of real pytest's parametrize mechanics for our own runner to
    replicate the effect; under real pytest, the real parametrize
    mechanism takes over transparently since the decorator name and call
    signature match.
    """

    @staticmethod
    def parametrize(argnames: str, argvalues: list):
        def decorator(func):
            func._pytest_stub_parametrize = (argnames, argvalues)
            return func
        return decorator


mark = _MarkDecoratorFactory()


class _FixtureDecoratorFactory:
    """Minimal stand-in for @pytest.fixture() used in conftest.py.

    Marks the function so our runner recognizes it as fixture-like; the
    runner's actual fresh_db handling is special-cased directly, so this
    decorator mainly exists so `@pytest.fixture()` doesn't raise
    AttributeError when conftest.py is imported by tooling.
    """

    def __call__(self, func=None, **kwargs):
        if func is None:
            def wrapper(f):
                f._is_fixture = True
                return f
            return wrapper
        func._is_fixture = True
        return func


fixture = _FixtureDecoratorFactory()

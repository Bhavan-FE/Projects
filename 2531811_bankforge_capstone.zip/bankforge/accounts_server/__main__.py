"""
accounts_server/__main__.py
=============================
FastMCP application entrypoint for accounts_server.

Run standalone with:
    python -m accounts_server

Owns: accounts, customers (read-only join for scoping fields), transactions.
Never imports anything from products_server or compliance_comms_server.
"""

from __future__ import annotations

from mcp.server.fastmcp import FastMCP

import prompts
import resources
from accounts_server import tools

mcp = FastMCP("accounts_server")


@mcp.resource("account://{account_id}/summary")
def account_summary_resource(account_id: str) -> dict:
    """Read-only account summary view (masked, minimized). See
    resources.account_summary_resource for the shared implementation.
    """
    return resources.account_summary_resource(account_id)


@mcp.prompt()
def transaction_analysis_prompt(customer_name: str, account_type: str, analysis_period: str) -> str:
    """Reusable instructions for analysing a customer's transaction
    history via accounts_server's Tools.
    """
    return prompts.transaction_analysis_prompt(customer_name, account_type, analysis_period)


@mcp.tool()
def get_account_summary(account_id: str, caller_scope: str) -> dict:
    """Look up a single account. Fields are minimized per caller_scope
    (teller/loan_officer/compliance_officer/admin); the account number is
    always masked to its last 4 digits.
    """
    return tools.get_account_summary(account_id, caller_scope)


@mcp.tool()
def get_accounts_for_customer(customer_id: str, caller_scope: str) -> list:
    """Return all accounts for a customer, each minimized the same way as
    get_account_summary.
    """
    return tools.get_accounts_for_customer(customer_id, caller_scope)


@mcp.tool()
def get_transaction_history(account_id: str, limit: int = 10) -> list:
    """Return up to `limit` most-recent transactions for an account, most
    recent first.
    """
    return tools.get_transaction_history(account_id, limit)


if __name__ == "__main__":
    mcp.run()

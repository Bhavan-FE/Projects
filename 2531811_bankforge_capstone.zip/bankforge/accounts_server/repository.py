"""
accounts_server/repository.py
==============================
The ONLY module in accounts_server permitted to open a database connection
or issue SQL. Per §3's isolation note, this module queries exactly the
tables accounts_server owns (accounts, customers, transactions) and
nothing else -- it has no import path to loan_products, loan_applications,
communications_log, fraud_flags, or audit_log, so cross-domain access is a
structural impossibility here, not a convention tools.py happens to follow.

tools.py calls into this module; it never imports database.get_connection
directly.
"""

from __future__ import annotations

from typing import Any, Optional

import database


def fetch_account(account_id: str) -> Optional[dict[str, Any]]:
    """Return the raw account row (joined with its owning customer's
    risk_rating/kyc_status for scoped-field purposes) or None if not found.
    """
    with database.connection_scope() as conn:
        row = conn.execute(
            """
            SELECT
                a.account_id, a.customer_id, a.account_number, a.account_type,
                a.status, a.balance, a.opened_date, a.last_transaction_at,
                c.risk_rating, c.kyc_status
            FROM accounts a
            JOIN customers c ON c.customer_id = a.customer_id
            WHERE a.account_id = ?
            """,
            (account_id,),
        ).fetchone()
        return dict(row) if row is not None else None


def fetch_accounts_for_customer(customer_id: str) -> list[dict[str, Any]]:
    """Return all account rows for a given customer_id (empty list if the
    customer doesn't exist or has no accounts).
    """
    with database.connection_scope() as conn:
        rows = conn.execute(
            """
            SELECT
                a.account_id, a.customer_id, a.account_number, a.account_type,
                a.status, a.balance, a.opened_date, a.last_transaction_at,
                c.risk_rating, c.kyc_status
            FROM accounts a
            JOIN customers c ON c.customer_id = a.customer_id
            WHERE a.customer_id = ?
            ORDER BY a.account_id
            """,
            (customer_id,),
        ).fetchall()
        return [dict(row) for row in rows]


def customer_exists(customer_id: str) -> bool:
    with database.connection_scope() as conn:
        row = conn.execute(
            "SELECT 1 FROM customers WHERE customer_id = ?", (customer_id,)
        ).fetchone()
        return row is not None


def account_exists(account_id: str) -> bool:
    with database.connection_scope() as conn:
        row = conn.execute(
            "SELECT 1 FROM accounts WHERE account_id = ?", (account_id,)
        ).fetchone()
        return row is not None


def fetch_transaction_history(account_id: str, limit: int) -> list[dict[str, Any]]:
    """Return up to `limit` most-recent transactions for account_id,
    most recent first.
    """
    with database.connection_scope() as conn:
        rows = conn.execute(
            """
            SELECT transaction_id, account_id, amount, direction, description, occurred_at
            FROM transactions
            WHERE account_id = ?
            ORDER BY occurred_at DESC
            LIMIT ?
            """,
            (account_id, limit),
        ).fetchall()
        return [dict(row) for row in rows]

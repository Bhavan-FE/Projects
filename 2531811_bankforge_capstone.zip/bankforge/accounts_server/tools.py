"""
accounts_server/tools.py
==========================
The three Tools owned by accounts_server (§3.1):
    get_account_summary(account_id, caller_scope)
    get_accounts_for_customer(customer_id, caller_scope)
    get_transaction_history(account_id, limit)

All three are read-only. All three are traced via @trace(logger,
redact=guardrails.redact_for_logging). Scoped field visibility and account
masking are enforced via guardrails.minimize_account_fields -- never
duplicated here.
"""

from __future__ import annotations

from typing import Any

import guardrails
from logging_config import get_logger, trace

from . import repository

logger = get_logger(__name__)


class AccountNotFoundError(Exception):
    """Raised when a well-formed account_id has no matching row."""

    def __init__(self, account_id: str):
        self.account_id = account_id
        super().__init__(f"No account found with account_id '{account_id}'")


class CustomerNotFoundError(Exception):
    """Raised when a well-formed customer_id has no matching row."""

    def __init__(self, customer_id: str):
        self.customer_id = customer_id
        super().__init__(f"No customer found with customer_id '{customer_id}'")


@trace(logger, redact=guardrails.redact_for_logging)
def get_account_summary(account_id: str, caller_scope: str) -> dict[str, Any]:
    """Look up a single account, with fields minimized per caller_scope
    and the account number masked to its last 4 digits (always).

    Raises:
        guardrails.InvalidIdFormatError: account_id is malformed.
        guardrails.InvalidScopeError: caller_scope is not a recognised role.
        AccountNotFoundError: account_id is well-formed but doesn't exist.
    """
    guardrails.validate_id_format("account_id", account_id)

    record = repository.fetch_account(account_id)
    if record is None:
        raise AccountNotFoundError(account_id)

    return guardrails.minimize_account_fields(record, caller_scope)


@trace(logger, redact=guardrails.redact_for_logging)
def get_accounts_for_customer(customer_id: str, caller_scope: str) -> list[dict[str, Any]]:
    """Return all accounts belonging to customer_id, each minimized the
    same way as get_account_summary.

    Raises:
        guardrails.InvalidIdFormatError: customer_id is malformed.
        guardrails.InvalidScopeError: caller_scope is not a recognised role.
        CustomerNotFoundError: customer_id is well-formed but doesn't exist.
    """
    guardrails.validate_id_format("customer_id", customer_id)

    if not repository.customer_exists(customer_id):
        raise CustomerNotFoundError(customer_id)

    records = repository.fetch_accounts_for_customer(customer_id)
    return [guardrails.minimize_account_fields(r, caller_scope) for r in records]


@trace(logger, redact=guardrails.redact_for_logging)
def get_transaction_history(account_id: str, limit: int = 10) -> list[dict[str, Any]]:
    """Return up to `limit` most-recent transactions for account_id, most
    recent first. Transaction records don't carry an account_number field,
    so no masking is needed here -- account_id itself is not masked (it is
    not the account *number*), matching the account-facing tools above
    which mask account_number, not account_id.

    Raises:
        guardrails.InvalidIdFormatError: account_id is malformed.
        AccountNotFoundError: account_id is well-formed but doesn't exist.
        ValueError: limit is not a positive integer.
    """
    guardrails.validate_id_format("account_id", account_id)

    if not isinstance(limit, int) or limit <= 0:
        raise ValueError(f"limit must be a positive integer, got {limit!r}")

    if not repository.account_exists(account_id):
        raise AccountNotFoundError(account_id)

    return repository.fetch_transaction_history(account_id, limit)

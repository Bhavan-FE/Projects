from datetime import datetime
from pydantic import BaseModel, Field

from app.models.classification import Classification


class CaseReport(BaseModel):
    ticket_id: str

    classification: Classification

    resolution_path: str

    final_response: str | None = None

    escalation_reason: str | None = None

    timestamp: datetime

    agent_trace: list[str] = Field(default_factory=list)


class CaseReportWriteResult(BaseModel):
    success: bool
    ticket_id: str
    error: str | None = None
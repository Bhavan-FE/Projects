from pydantic import BaseModel, Field
from app.models.classification import Classification
from app.models.account import AccountLookupResult
from app.models.policy import PolicyRetrievalResult
from app.models.validation import ValidationResult
from app.models.escalation import EscalationResult

class Ticket(BaseModel):
    ticket_id : str
    customer_id : str
    ticket_text : str

class DraftResponse(BaseModel):
    response : str
    citations : list[str] = Field(default_factory=list)

class SupportState(BaseModel):
    ticket : Ticket

    classification : Classification | None = None
    account_context : AccountLookupResult | None = None
    policy_context : PolicyRetrievalResult | None = None
    draft : DraftResponse | None = None
    validation : ValidationResult | None = None
    escalation : EscalationResult | None = None
    agent_trace : list[str] = Field(default_factory=list)

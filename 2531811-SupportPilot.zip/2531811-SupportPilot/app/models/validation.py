from pydantic import BaseModel, Field

class ValidationResult(BaseModel):
    passed: bool
    factual_accuracy: bool
    policy_compliance: bool
    tone_appropriate: bool
    grounding_passed: bool
    reasons: list[str] = Field(default_factory=list)
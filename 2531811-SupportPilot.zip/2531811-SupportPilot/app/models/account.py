from datetime import date
from typing import Optional
from pydantic import BaseModel, Field

class Customer(BaseModel):
    customer_id : str
    name : str
    email : str
    account_standing : str
    signup_date : date
    prior_ticket_count : int

class Order(BaseModel):
    order_id : str
    customer_id : str
    item : str
    amount : float
    status : str
    order_date : date

class AccountLookupResult(BaseModel):
    customer_found : bool
    customer : Optional[Customer] = None
    orders : list[Order] = Field(default_factory=list)
    error : Optional[str] = None


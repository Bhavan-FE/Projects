import re

from pydantic import BaseModel, field_validator


class CustomerLookupRequest(BaseModel):
    customer_id: str

    @field_validator("customer_id")
    @classmethod
    def validate_customer_id(cls, value: str) -> str:
        if not re.fullmatch(r"CUST\d{4}", value):
            raise ValueError("customer_id must follow the format CUST0000")

        return value


class OrderLookupRequest(BaseModel):
    order_id: str

    @field_validator("order_id")
    @classmethod
    def validate_order_id(cls, value: str) -> str:
        if not re.fullmatch(r"ORD\d{4}", value):
            raise ValueError("order_id must follow the format ORD0000")

        return value
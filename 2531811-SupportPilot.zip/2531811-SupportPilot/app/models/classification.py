from pydantic import BaseModel, Field
from enum import Enum


class IssueType(str, Enum):
    ORDER_STATUS = "order_status"
    REFUND_REQUEST = "refund_request"
    DAMAGED_ITEM = "damaged_item"
    PAYMENT_ISSUE = "payment_issue"
    ACCOUNT_ACCESS = "account_access"
    FRAUD = "fraud"
    OTHER = "other"

class Urgency(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class Sentiment(str, Enum):
    POSITIVE = "positive"
    NEUTRAL = "neutral"
    FRUSTRATED = "frustrated"
    ANGRY = "angry"


class Classification(BaseModel):
    issue_type : IssueType
    urgency : Urgency
    sentiment : Sentiment
    confidence : float = Field(ge=0.0, le=1.0)

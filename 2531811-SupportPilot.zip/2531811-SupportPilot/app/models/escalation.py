from pydantic import BaseModel


class EscalationResult(BaseModel):
    should_escalate: bool
    reason: str
    rule_triggered: str | None = None
from pydantic import BaseModel, Field

class PolicyChunk(BaseModel):
    content : str
    source : str
    section : str
    score : float | None = None

class PolicyRetrievalResult(BaseModel):
    query : str
    chunks : list[PolicyChunk] = Field(default_factory=list)
    found : bool
    error : str | None = None
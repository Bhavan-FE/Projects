from app.db.seed import seed_database
from app.workflow.runner import run_support_ticket


SHOWCASE_TICKET = (
    "Hi, I'm really frustrated — the package I received from "
    "order ORD0042 arrived with the box completely crushed and "
    "the item inside is broken. I want a full refund, not a "
    "replacement. This is the second time something like this "
    "has happened with my orders and I'm starting to wonder "
    "if I should just stop shopping here."
)


def main():

    seed_database()

    result = run_support_ticket(
        ticket_id="TICK0001",
        customer_id="CUST0001",
        ticket_text=SHOWCASE_TICKET,
    )

    print("\n==============================")
    print("SUPPORTPILOT RESULT")
    print("==============================")

    print("\nClassification:")
    print(result.classification)

    print("\nCustomer:")
    print(result.account_context.customer)

    print("\nOrders:")
    print(result.account_context.orders)

    print("\nPolicy:")
    print(result.policy_context)

    print("\nDraft:")
    print(result.draft)

    print("\nValidation:")
    print(result.validation)

    print("\nEscalation:")
    print(result.escalation)

    print("\nAgent Trace:")
    for agent in result.agent_trace:
        print(f"  -> {agent}")


if __name__ == "__main__":
    main()
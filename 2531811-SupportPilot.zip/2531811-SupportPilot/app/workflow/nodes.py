from app.models.state import SupportState

from app.agents.classifier import classify_ticket
from app.tools.customer_tools import get_customer
from app.tools.order_tools import get_orders
from app.tools.policy_retrival import retrieve_policy
from app.agents.drafter import draft_response
from app.agents.validator import validate_response

from app.rules.escalation import evaluate_escalation
from app.tools.case_report_tools import write_case_report


def classifier_node(state: SupportState) -> dict:
    """
    Classify the incoming support ticket.
    """

    classification = classify_ticket(
        state.ticket.ticket_text
    )

    return {
        "classification": classification,
        "agent_trace": state.agent_trace + ["classifier"],
    }


def account_lookup_node(state: SupportState) -> dict:
    """
    Retrieve customer information and customer orders.
    """

    customer_result = get_customer.invoke(
        {
            "customer_id": state.ticket.customer_id
        }
    )

    orders_result = get_orders.invoke(
        {
            "customer_id": state.ticket.customer_id
        }
    )

    # Combine customer + orders into one account context.

    customer_result.orders = orders_result.orders

    if orders_result.error and not customer_result.error:
        customer_result.error = orders_result.error

    return {
        "account_context": customer_result,
        "agent_trace": state.agent_trace + ["account_lookup"],
    }


def knowledge_retrieval_node(state: SupportState) -> dict:
    """
    Retrieve relevant ShopStream policies.
    """

    classification = state.classification

    query = (
        f"Customer issue: {classification.issue_type.value}. "
        f"Ticket: {state.ticket.ticket_text}"
    )

    policy_result = retrieve_policy(query)

    return {
        "policy_context": policy_result,
        "agent_trace": state.agent_trace + ["knowledge_retrieval"],
    }


def drafting_node(state: SupportState) -> dict:
    """
    Generate a grounded customer-facing response.
    """

    draft = draft_response(
        classification=state.classification,
        customer_context=state.account_context,
        retrieved_policy_chunks=state.policy_context.chunks,
    )

    return {
        "draft": draft,
        "agent_trace": state.agent_trace + ["drafting"],
    }


def validation_node(state: SupportState) -> dict:
    """
    Validate the generated response.
    """

    validation = validate_response(
        draft_response=state.draft,
        customer_context=state.account_context,
        retrieved_policy_chunks=state.policy_context.chunks,
        classification=state.classification,
    )

    return {
        "validation": validation,
        "agent_trace": state.agent_trace + ["validation"],
    }


def escalation_node(state: SupportState) -> dict:
    """
    Apply deterministic escalation rules.
    """

    escalation = evaluate_escalation(
        classification=state.classification,
        account_context=state.account_context,
        validation=state.validation,
        ticket_text=state.ticket.ticket_text,
    )

    return {
        "escalation": escalation,
        "agent_trace": state.agent_trace + ["escalation"],
    }


def case_closure_node(state: SupportState) -> dict:
    """
    Persist the final case outcome.
    """

    if state.escalation.should_escalate:
        resolution_path = "escalated"
        escalation_reason = state.escalation.reason
    else:
        resolution_path = "auto_resolved"
        escalation_reason = None

    final_response = None

    if state.draft:
        final_response = state.draft.response

    result = write_case_report.invoke(
        {
            "ticket_id": state.ticket.ticket_id,
            "classification": state.classification,
            "resolution_path": resolution_path,
            "final_response": final_response,
            "escalation_reason": escalation_reason,
            "agent_trace": state.agent_trace + ["case_closure"],
        }
    )

    if not result.success:
        raise RuntimeError(
            f"Failed to close case: {result.error}"
        )

    return {
        "agent_trace": state.agent_trace + ["case_closure"],
    }
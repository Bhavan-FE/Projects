from app.models.state import SupportState, Ticket
from app.workflow.graph import support_graph


def run_support_ticket(
    ticket_id: str,
    customer_id: str,
    ticket_text: str,
) -> SupportState:

    ticket = Ticket(
        ticket_id=ticket_id,
        customer_id=customer_id,
        ticket_text=ticket_text,
    )

    initial_state = SupportState(
        ticket=ticket
    )

    final_state = support_graph.invoke(
        initial_state
    )

    return SupportState.model_validate(final_state)
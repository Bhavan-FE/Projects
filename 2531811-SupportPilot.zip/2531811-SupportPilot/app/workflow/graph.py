from langgraph.graph import StateGraph, START, END

from app.models.state import SupportState

from app.workflow.nodes import (
    classifier_node,
    account_lookup_node,
    knowledge_retrieval_node,
    drafting_node,
    validation_node,
    escalation_node,
    case_closure_node,
)


def build_support_graph():

    workflow = StateGraph(SupportState)

    # ---------------------------------------------------------
    # Nodes
    # ---------------------------------------------------------

    workflow.add_node(
        "classifier",
        classifier_node,
    )

    workflow.add_node(
        "account_lookup",
        account_lookup_node,
    )

    workflow.add_node(
        "knowledge_retrieval",
        knowledge_retrieval_node,
    )

    workflow.add_node(
        "drafting",
        drafting_node,
    )

    workflow.add_node(
        "validation",
        validation_node,
    )

    workflow.add_node(
        "escalation",
        escalation_node,
    )

    workflow.add_node(
        "case_closure",
        case_closure_node,
    )

    # ---------------------------------------------------------
    # Edges
    # ---------------------------------------------------------

    workflow.add_edge(
        START,
        "classifier",
    )

    workflow.add_edge(
        "classifier",
        "account_lookup",
    )

    workflow.add_edge(
        "account_lookup",
        "knowledge_retrieval",
    )

    workflow.add_edge(
        "knowledge_retrieval",
        "drafting",
    )

    workflow.add_edge(
        "drafting",
        "validation",
    )

    workflow.add_edge(
        "validation",
        "escalation",
    )

    workflow.add_edge(
        "escalation",
        "case_closure",
    )

    workflow.add_edge(
        "case_closure",
        END,
    )

    return workflow.compile()


support_graph = build_support_graph()
from dotenv import load_dotenv
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI

from app.models.validation import ValidationResult
from app.prompts.validation import VALIDATION_PROMPT


load_dotenv()


llm = ChatOpenAI(
    model="gpt-4o-mini",
    temperature=0,
)


validation_llm = llm.with_structured_output(
    ValidationResult
)


def validate_response(
    draft_response,
    customer_context,
    retrieved_policy_chunks,
    classification,
) -> ValidationResult:
    """
    Validate a drafted customer response for factual accuracy,
    policy compliance, tone, and grounding.
    """

    if not draft_response:
        return ValidationResult(
            passed=False,
            factual_accuracy=False,
            policy_compliance=False,
            tone_appropriate=False,
            grounding_passed=False,
            reasons=["Draft response is empty."],
        )

    prompt = VALIDATION_PROMPT.format(
        draft_response=draft_response.response,
        customer_context=customer_context.model_dump_json(),
        retrieved_policy_chunks=[
            chunk.model_dump()
            for chunk in retrieved_policy_chunks
        ],
        classification=classification.model_dump_json(),
    )

    result = validation_llm.invoke(prompt)

    return result


@tool
def validate_response_tool(
    draft_response,
    customer_context,
    retrieved_policy_chunks,
    classification,
) -> ValidationResult:
    """
    Validate a drafted ShopStream customer response.

    Checks factual accuracy, policy compliance, tone, and grounding.
    Returns a structured validation result.
    """

    return validate_response(
        draft_response=draft_response,
        customer_context=customer_context,
        retrieved_policy_chunks=retrieved_policy_chunks,
        classification=classification,
    )
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI

from app.models.state import DraftResponse
from app.prompts.drafting import DRAFTING_PROMPT


load_dotenv()


llm = ChatOpenAI(
    model="gpt-4o-mini",
    temperature=0,
)


drafting_llm = llm.with_structured_output(DraftResponse)

def draft_response(
    classification,
    customer_context,
    retrieved_policy_chunks,
) -> DraftResponse:
    """
    Generate a grounded customer-facing support response.

    The response is generated only from classification,
    customer context, and retrieved policy information.
    """

    prompt = DRAFTING_PROMPT.format(
        classification=classification.model_dump_json(),
        customer_context=customer_context.model_dump_json(),
        retrieved_policy_chunks=[
            chunk.model_dump()
            for chunk in retrieved_policy_chunks
        ],
    )

    result = drafting_llm.invoke(prompt)

    if not result.citations:
        result.citations = list({
            chunk.source
            for chunk in retrieved_policy_chunks
        })

    return result
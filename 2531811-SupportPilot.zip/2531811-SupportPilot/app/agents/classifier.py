import os

from dotenv import load_dotenv
from langchain_openai import ChatOpenAI

from app.models.classification import Classification
from app.prompts.classification import CLASSIFICATION_PROMPT


load_dotenv()


llm = ChatOpenAI(
    model="gpt-4o-mini",
    temperature=0,
)


classifier_llm = llm.with_structured_output(Classification)


def classify_ticket(ticket_text: str) -> Classification:
    """
    Classify a support ticket into issue type, urgency, sentiment,
    and confidence using the LLM.
    """

    if not ticket_text or not ticket_text.strip():
        raise ValueError("ticket_text cannot be empty")

    prompt = CLASSIFICATION_PROMPT.format(
        ticket_text=ticket_text
    )

    result = classifier_llm.invoke(prompt)

    return result
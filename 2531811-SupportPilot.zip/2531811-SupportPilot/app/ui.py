import gradio as gr

from app.db.seed import seed_database
from app.workflow.runner import run_support_ticket


def process_ticket(ticket_id, customer_id, ticket_text):

    if not ticket_id.strip():
        return "Ticket ID is required.", "", "", "", "", ""

    if not customer_id.strip():
        return "Customer ID is required.", "", "", "", "", ""

    if not ticket_text.strip():
        return "Ticket text is required.", "", "", "", "", ""

    try:
        result = run_support_ticket(
            ticket_id=ticket_id.strip(),
            customer_id=customer_id.strip(),
            ticket_text=ticket_text.strip(),
        )

        classification = result.classification

        classification_text = (
            f"Issue Type: {classification.issue_type.value}\n"
            f"Urgency: {classification.urgency.value}\n"
            f"Sentiment: {classification.sentiment.value}\n"
            f"Confidence: {classification.confidence:.2f}"
        )

        customer_text = "Customer not found."

        if result.account_context:
            if result.account_context.customer:
                customer = result.account_context.customer

                customer_text = (
                    f"Customer ID: {customer.customer_id}\n"
                    f"Name: {customer.name}\n"
                    f"Account Standing: {customer.account_standing}\n"
                    f"Prior Tickets: {customer.prior_ticket_count}"
                )

            if result.account_context.orders:
                customer_text += "\n\nOrders:\n"

                for order in result.account_context.orders:
                    customer_text += (
                        f"- {order.order_id} | "
                        f"{order.item} | "
                        f"₹{order.amount:,.2f} | "
                        f"{order.status}\n"
                    )

        policy_text = "No policy context retrieved."

        if result.policy_context and result.policy_context.chunks:

            policy_text = ""

            for chunk in result.policy_context.chunks:
                policy_text += (
                    f"Source: {chunk.source}\n"
                    f"Section: {chunk.section}\n"
                    f"Score: {chunk.score:.4f}\n\n"
                    f"{chunk.content}\n"
                    f"{'-' * 60}\n"
                )

        draft_text = ""

        if result.draft:
            draft_text = result.draft.response

            if result.draft.citations:
                draft_text += (
                    "\n\nCitations:\n"
                    + "\n".join(
                        f"- {citation}"
                        for citation in result.draft.citations
                    )
                )

        validation_text = "Validation unavailable."

        if result.validation:
            validation_text = (
                f"Passed: {result.validation.passed}\n"
                f"Factual Accuracy: "
                f"{result.validation.factual_accuracy}\n"
                f"Policy Compliance: "
                f"{result.validation.policy_compliance}\n"
                f"Tone Appropriate: "
                f"{result.validation.tone_appropriate}\n"
                f"Grounding Passed: "
                f"{result.validation.grounding_passed}\n\n"
                f"Reasons:\n"
                + "\n".join(
                    f"- {reason}"
                    for reason in result.validation.reasons
                )
            )

        escalation_text = "Escalation unavailable."

        if result.escalation:

            decision = (
                "ESCALATED"
                if result.escalation.should_escalate
                else "AUTO-RESOLVED"
            )

            escalation_text = (
                f"Decision: {decision}\n"
                f"Reason: {result.escalation.reason}\n"
                f"Rule: {result.escalation.rule_triggered or 'None'}"
            )

        trace_text = "\n".join(
            f"{index + 1}. {agent}"
            for index, agent in enumerate(result.agent_trace)
        )

        return (
            classification_text,
            customer_text,
            policy_text,
            draft_text,
            validation_text,
            escalation_text + "\n\nAgent Trace:\n" + trace_text,
        )

    except Exception as exc:

        return (
            f"Workflow failed: {str(exc)}",
            "",
            "",
            "",
            "",
            "",
        )


def clear_fields():

    return (
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
    )


seed_database()


with gr.Blocks(
    title="SupportPilot"
) as demo:

    gr.Markdown(
        """
        # SupportPilot

        ### ShopStream India Multi-Agent Customer Support

        Submit a support ticket and let the workflow classify,
        retrieve account and policy information, draft a response,
        validate it, and apply deterministic escalation rules.
        """
    )

    with gr.Row():

        with gr.Column(scale=1):

            gr.Markdown("### Ticket")

            ticket_id = gr.Textbox(
                label="Ticket ID",
                placeholder="TICK0001",
                value="TICK0001",
            )

            customer_id = gr.Textbox(
                label="Customer ID",
                placeholder="CUST0001",
                value="CUST0001",
            )

            ticket_text = gr.Textbox(
                label="Customer Message",
                placeholder="Enter the customer support ticket...",
                lines=8,
                value=(
                    "Hi, I'm really frustrated — the package I "
                    "received from order ORD0042 arrived with the "
                    "box completely crushed and the item inside "
                    "is broken. I want a full refund, not a "
                    "replacement. This is the second time something "
                    "like this has happened with my orders and I'm "
                    "starting to wonder if I should just stop "
                    "shopping here."
                ),
            )

            with gr.Row():

                submit_button = gr.Button(
                    "Process Ticket",
                    variant="primary",
                )

                clear_button = gr.Button(
                    "Clear"
                )

        with gr.Column(scale=1):

            gr.Markdown("### Classification")

            classification_output = gr.Textbox(
                label="Classification",
                lines=5,
            )

            gr.Markdown("### Account Context")

            customer_output = gr.Textbox(
                label="Customer & Orders",
                lines=8,
            )

    gr.Markdown("### Policy Retrieval")

    policy_output = gr.Textbox(
        label="Retrieved Policy Chunks",
        lines=12,
    )

    gr.Markdown("### Drafted Response")

    draft_output = gr.Textbox(
        label="Customer-Facing Response",
        lines=10,
    )

    gr.Markdown("### Validation")

    validation_output = gr.Textbox(
        label="Validation Result",
        lines=8,
    )

    gr.Markdown("### Final Decision")

    escalation_output = gr.Textbox(
        label="Escalation / Resolution",
        lines=10,
    )

    submit_button.click(
        fn=process_ticket,
        inputs=[
            ticket_id,
            customer_id,
            ticket_text,
        ],
        outputs=[
            classification_output,
            customer_output,
            policy_output,
            draft_output,
            validation_output,
            escalation_output,
        ],
    )

    clear_button.click(
        fn=clear_fields,
        inputs=[],
        outputs=[
            ticket_id,
            customer_id,
            ticket_text,
            classification_output,
            customer_output,
            policy_output,
            draft_output,
            validation_output,
            escalation_output,
        ],
    )


if __name__ == "__main__":
    demo.launch()
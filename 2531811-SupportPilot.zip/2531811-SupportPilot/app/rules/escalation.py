from app.models.classification import Classification
from app.models.account import AccountLookupResult
from app.models.validation import ValidationResult
from app.models.escalation import EscalationResult


# Business thresholds
HIGH_VALUE_THRESHOLD = 50000.0
CONFIDENCE_THRESHOLD = 0.75


def evaluate_escalation(
    classification: Classification,
    account_context: AccountLookupResult,
    validation: ValidationResult,
    ticket_text: str,
) -> EscalationResult:
    """
    Deterministically decide whether a support case must be escalated.

    No LLM is used here. Escalation decisions are based only on
    predefined business rules and structured pipeline results.
    """

    # ---------------------------------------------------------
    # Rule 1: Validation failure
    # ---------------------------------------------------------
    if not validation.passed:
        return EscalationResult(
            should_escalate=True,
            reason="The drafted response failed validation.",
            rule_triggered="validation_failure",
        )

    # ---------------------------------------------------------
    # Rule 2: Unknown customer
    # ---------------------------------------------------------
    if not account_context.customer_found:
        return EscalationResult(
            should_escalate=True,
            reason="Customer could not be verified in the support database.",
            rule_triggered="unknown_customer",
        )

    # ---------------------------------------------------------
    # Rule 3: Low classification confidence
    # ---------------------------------------------------------
    if classification.confidence < CONFIDENCE_THRESHOLD:
        return EscalationResult(
            should_escalate=True,
            reason=(
                f"Classification confidence "
                f"({classification.confidence:.2f}) is below the "
                f"required threshold ({CONFIDENCE_THRESHOLD:.2f})."
            ),
            rule_triggered="low_confidence",
        )

    # ---------------------------------------------------------
    # Rule 4: Fraud
    # ---------------------------------------------------------
    if classification.issue_type.value == "fraud":
        return EscalationResult(
            should_escalate=True,
            reason="Suspected fraud requires investigation.",
            rule_triggered="fraud",
        )

    # ---------------------------------------------------------
    # Rule 5: Unrecognized / suspicious payment
    # ---------------------------------------------------------
    normalized_text = ticket_text.lower()

    payment_escalation_terms = [
        "unrecognized payment",
        "unauthorized payment",
        "don't recognize this payment",
        "do not recognize this payment",
        "duplicate transaction",
        "duplicate charge",
        "suspicious transaction",
        "unknown transaction",
    ]

    if (
        classification.issue_type.value == "payment_issue"
        and any(term in normalized_text for term in payment_escalation_terms)
    ):
        return EscalationResult(
            should_escalate=True,
            reason="Unrecognized or suspicious payment requires investigation.",
            rule_triggered="suspicious_payment",
        )

    # ---------------------------------------------------------
    # Rule 6: Explicit manager request
    # ---------------------------------------------------------
    manager_terms = [
        "speak to a manager",
        "talk to a manager",
        "manager",
        "supervisor",
        "human agent",
    ]

    if any(term in normalized_text for term in manager_terms):
        return EscalationResult(
            should_escalate=True,
            reason="The customer explicitly requested human escalation.",
            rule_triggered="manager_request",
        )

    # ---------------------------------------------------------
    # Rule 7: Legal request
    # ---------------------------------------------------------
    legal_terms = [
        "legal action",
        "take legal action",
        "lawyer",
        "attorney",
        "legal department",
        "court",
        "lawsuit",
    ]

    if any(term in normalized_text for term in legal_terms):
        return EscalationResult(
            should_escalate=True,
            reason="The ticket contains an explicit legal request or threat.",
            rule_triggered="legal_request",
        )

    # ---------------------------------------------------------
    # Rule 8: High-value order
    # ---------------------------------------------------------
    for order in account_context.orders:
        if order.amount > HIGH_VALUE_THRESHOLD:
            return EscalationResult(
                should_escalate=True,
                reason=(
                    f"Order {order.order_id} has a value of "
                    f"{order.amount:.2f}, which exceeds the "
                    f"high-value threshold of "
                    f"{HIGH_VALUE_THRESHOLD:.2f}."
                ),
                rule_triggered="high_value_order",
            )

    # ---------------------------------------------------------
    # No escalation rule triggered
    # ---------------------------------------------------------
    return EscalationResult(
        should_escalate=False,
        reason="No escalation rule was triggered.",
        rule_triggered=None,
    )
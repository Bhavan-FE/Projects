from app.tools.policy_retrival import create_policy_vector_store


if __name__ == "__main__":
    create_policy_vector_store()
    print("Policy vector store created successfully.")
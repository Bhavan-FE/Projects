from app.db.database import get_connection, initialize_database

CUSTOMERS = [
    (
        "CUST0001",
        "Arun Kumar",
        "arun@example.com",
        "good",
        "2024-03-15",
        2,
    ),
    (
        "CUST0002",
        "Priya Sharma",
        "priya@example.com",
        "vip",
        "2023-07-21",
        5,
    ),
    (
        "CUST0003",
        "Rahul Menon",
        "rahul@example.com",
        "flagged",
        "2025-01-10",
        8,
    ),
    (
        "CUST0004",
        "Sneha Iyer",
        "sneha@example.com",
        "good",
        "2024-11-02",
        1,
    ),
]


ORDERS = [
    (
        "ORD0042",
        "CUST0001",
        "Sony WH-1000XM5 Headphones",
        24999.00,
        "delivered",
        "2026-09-15",
    ),
    (
        "ORD0043",
        "CUST0001",
        "Laptop Backpack",
        2499.00,
        "delivered",
        "2026-09-10",
    ),
    (
        "ORD0044",
        "CUST0002",
        "Samsung Galaxy S26",
        79999.00,
        "delivered",
        "2026-09-12",
    ),
    (
        "ORD0045",
        "CUST0003",
        "Apple Watch",
        45999.00,
        "returned",
        "2026-09-05",
    ),
    (
        "ORD0046",
        "CUST0004",
        "Mechanical Keyboard",
        8999.00,
        "in_transit",
        "2026-09-18",
    ),
]


TICKETS = [
    (
        "TICK0001",
        "CUST0001",
        "2026-09-22T09:30:00",
        "My package arrived damaged and I want a refund for order ORD0042.",
    ),
    (
        "TICK0002",
        "CUST0002",
        "2026-09-22T10:00:00",
        "Where is my order ORD0044?",
    ),
    (
        "TICK0003",
        "CUST0003",
        "2026-09-22T10:15:00",
        "I don't recognize a payment on my account. Please help.",
    ),
]

def seed_database():
    """ Initialize the database and insert ShopStream seed data."""

    initialize_database()
    connection = get_connection()
    cursor = connection.cursor()

    cursor.executemany(
        """
        INSERT OR IGNORE INTO customers
        (
            customer_id,
            name,
            email,
            account_standing,
            signup_date,
            prior_ticket_count
        )
        VALUES (?, ?, ?, ?, ?, ?)
        """,
        CUSTOMERS
    )
    cursor.executemany(
        """
        INSERT OR IGNORE INTO orders
        (
            order_id,
            customer_id,
            item,
            amount,
            status,
            order_date
        )
        VALUES (?, ?, ?, ?, ?, ?)
        """,
        ORDERS,
    )

    cursor.executemany(
        """
        INSERT OR IGNORE INTO tickets
        (
            ticket_id,
            customer_id,
            created_at,
            ticket_body
        )
        VALUES (?, ?, ?, ?)
        """,
        TICKETS,
    )

    connection.commit()
    connection.close()
    print("ShopStream database seeded successfully")

if __name__ == "__main__":
    seed_database()
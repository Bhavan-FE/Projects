from pathlib import Path

from langchain_chroma import Chroma
from langchain_core.documents import Document
from langchain_core.tools import tool
from langchain_openai import OpenAIEmbeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter
from dotenv import load_dotenv

load_dotenv()

from app.models.policy import (
    PolicyChunk,
    PolicyRetrievalResult,
)


BASE_DIR = Path(__file__).resolve().parents[2]

POLICY_DIR = BASE_DIR / "data" / "policies"

CHROMA_DIR = BASE_DIR / "data" / "chroma"

EMBEDDING_MODEL = "text-embedding-3-small"


def get_embeddings():
    """
    Create the OpenAI embedding model used for policy retrieval.
    """
    return OpenAIEmbeddings(
        model=EMBEDDING_MODEL
    )


def load_policy_documents():
    """
    Load Markdown policy files and split them into retrieval chunks.
    """

    documents = []

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=700,
        chunk_overlap=100,
    )

    for policy_file in POLICY_DIR.glob("*.md"):

        content = policy_file.read_text(
            encoding="utf-8"
        )

        chunks = splitter.split_text(content)

        for index, chunk in enumerate(chunks):

            documents.append(
                Document(
                    page_content=chunk,
                    metadata={
                        "source": policy_file.name,
                        "chunk_id": index,
                    },
                )
            )

    return documents


def create_policy_vector_store():
    """
    Create the Chroma vector store containing policy chunks.
    """

    documents = load_policy_documents()

    vector_store = Chroma.from_documents(
        documents=documents,
        embedding=get_embeddings(),
        persist_directory=str(CHROMA_DIR),
        collection_name="shopstream_policies",
    )

    return vector_store


def retrieve_policy(
    query: str,
    k: int = 4,
) -> PolicyRetrievalResult:
    """
    Retrieve the most relevant policy chunks for a support query.

    Returns policy content together with source metadata and similarity
    scores. Retrieval failures are returned as structured errors.
    """

    if not query or not query.strip():
        return PolicyRetrievalResult(
            query=query,
            chunks=[],
            found=False,
            error="Policy query cannot be empty.",
        )

    try:

        vector_store = create_policy_vector_store()

        results = vector_store.similarity_search_with_score(
            query,
            k=k,
        )

        chunks = []

        for document, score in results:

            chunks.append(
                PolicyChunk(
                    content=document.page_content,
                    source=document.metadata.get(
                        "source",
                        "unknown",
                    ),
                    section=str(
                        document.metadata.get(
                            "chunk_id",
                            "unknown",
                        )
                    ),
                    score=float(score),
                )
            )

        return PolicyRetrievalResult(
            query=query,
            chunks=chunks,
            found=len(chunks) > 0,
            error=None,
        )

    except Exception as exc:

        return PolicyRetrievalResult(
            query=query,
            chunks=[],
            found=False,
            error=f"Policy retrieval failed: {str(exc)}",
        )


@tool
def retrieve_policy_tool(query: str) -> PolicyRetrievalResult:
    """
    Retrieve relevant ShopStream policy chunks for a customer support case.

    Returns policy content and source information that downstream drafting
    and validation components can use for grounding.
    """

    return retrieve_policy(query)
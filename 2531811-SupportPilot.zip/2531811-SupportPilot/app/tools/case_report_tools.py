import json
import re
from datetime import datetime, timezone

from langchain_core.tools import tool

from app.db.database import get_connection
from app.models.case_report import CaseReportWriteResult
from app.models.classification import Classification


@tool
def write_case_report(
    ticket_id: str,
    classification: Classification,
    resolution_path: str,
    final_response: str | None,
    escalation_reason: str | None,
    agent_trace: list[str],
) -> CaseReportWriteResult:
    """
    Write the final support case outcome into the case_reports table.

    This tool records the case outcome for traceability and auditing.
    It does not make escalation or resolution decisions.
    """

    # ---------------------------------------------------------
    # 1. Validate ticket ID
    # ---------------------------------------------------------

    if not re.fullmatch(r"TICK\d{4}", ticket_id):
        return CaseReportWriteResult(
            success=False,
            ticket_id=ticket_id,
            error="Invalid ticket ID. Expected format TICK0000.",
        )

    # ---------------------------------------------------------
    # 2. Validate resolution path
    # ---------------------------------------------------------

    allowed_paths = {
        "auto_resolved",
        "escalated",
    }

    if resolution_path not in allowed_paths:
        return CaseReportWriteResult(
            success=False,
            ticket_id=ticket_id,
            error=(
                "Invalid resolution path. "
                "Expected 'auto_resolved' or 'escalated'."
            ),
        )

    # ---------------------------------------------------------
    # 3. Validate classification
    # ---------------------------------------------------------

    if classification.confidence < 0 or classification.confidence > 1:
        return CaseReportWriteResult(
            success=False,
            ticket_id=ticket_id,
            error="Classification confidence must be between 0 and 1.",
        )

    # ---------------------------------------------------------
    # 4. Write report
    # ---------------------------------------------------------

    connection = get_connection()

    try:
        cursor = connection.cursor()

        timestamp = datetime.now(timezone.utc).isoformat()

        cursor.execute(
            """
            INSERT INTO case_reports (
                ticket_id,
                issue_type,
                urgency,
                sentiment,
                confidence,
                resolution_path,
                final_response,
                escalation_reason,
                timestamp,
                agent_trace
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                ticket_id,
                classification.issue_type.value,
                classification.urgency.value,
                classification.sentiment.value,
                classification.confidence,
                resolution_path,
                final_response,
                escalation_reason,
                timestamp,
                json.dumps(agent_trace),
            ),
        )

        connection.commit()

        return CaseReportWriteResult(
            success=True,
            ticket_id=ticket_id,
            error=None,
        )

    except Exception as exc:

        connection.rollback()

        return CaseReportWriteResult(
            success=False,
            ticket_id=ticket_id,
            error=f"Failed to write case report: {str(exc)}",
        )

    finally:
        connection.close()
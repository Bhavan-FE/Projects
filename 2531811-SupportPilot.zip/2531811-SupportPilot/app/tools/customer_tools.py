from pydantic import ValidationError
from langchain_core.tools import tool

from app.db.database import get_connection
from app.models.account import AccountLookupResult, Customer
from app.models.identifiers import CustomerLookupRequest


@tool
def get_customer(customer_id: str) -> AccountLookupResult:
    """
    Retrieve customer account information from the ShopStream support database.

    The customer_id must follow the format CUST0000.
    Returns structured customer information or a structured error.
    """

    try:
        request = CustomerLookupRequest.model_validate(
            {"customer_id": customer_id}
        )

    except ValidationError as exc:
        return AccountLookupResult(
            customer_found=False,
            error=f"Invalid customer ID: {exc.errors()[0]['msg']}",
        )

    connection = get_connection()

    try:
        cursor = connection.cursor()

        cursor.execute(
            """
            SELECT
                customer_id,
                name,
                email,
                account_standing,
                signup_date,
                prior_ticket_count
            FROM customers
            WHERE customer_id = ?
            """,
            (request.customer_id,),
        )

        row = cursor.fetchone()

        # print("DEBUG request.customer_id:", repr(request.customer_id))
        # print("DEBUG row:", row)

        if row is None:
            return AccountLookupResult(
                customer_found=False,
                error=f"Customer {request.customer_id} was not found.",
            )

        customer = Customer(
            customer_id=row["customer_id"],
            name=row["name"],
            email=row["email"],
            account_standing=row["account_standing"],
            signup_date=row["signup_date"],
            prior_ticket_count=row["prior_ticket_count"],
        )

        # print("DEBUG customer:", customer)

        return AccountLookupResult(
            customer_found=True,
            customer=customer,
            orders=[],
            error=None,
        )

    except Exception as exc:
        # print("DEBUG DATABASE ERROR:", repr(exc))

        return AccountLookupResult(
            customer_found=False,
            error=f"Database error while retrieving customer: {str(exc)}",
        )

    finally:
        connection.close()
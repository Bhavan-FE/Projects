# from pydantic import ValidationError
from langchain_core.tools import tool
from app.db.database import get_connection
from app.models.account import AccountLookupResult, Order
# from app.models.identifiers import OrderLookupRequest

@tool
def get_orders(customer_id : str) -> AccountLookupResult:
    """
     Retrieve all orders belonging to a ShopStream customer.

    The customer_id must follow the format CUST0000.
    Returns structured order information or a structured error.

    """

    try:
        if not customer_id.startswith("CUST"):
            raise ValueError("customer_id must follow the format : CUST0000")
        if len(customer_id) != 8 or not customer_id[4:].isdigit():
            raise ValueError("customer_id must follow the format : CUST0000")
    except ValueError as ve:
        return AccountLookupResult(
            customer_found=False,
            error = f"Invalid customer ID : {str(ve)}",
        )
    connection = get_connection()

    try:
        cursor = connection.cursor()
        cursor.execute(
            """
             SELECT customer_id
            FROM customers
            WHERE customer_id = ?

            """,
            (customer_id,),
        )
        customer = cursor.fetchone()

        if customer is None:
            return AccountLookupResult(
                customer_found=False,
                error=f"Customer {customer_id} was not found.",
            )
        cursor.execute(
            """
             SELECT
                order_id,
                customer_id,
                item,
                amount,
                status,
                order_date
            FROM orders
            WHERE customer_id = ?
            ORDER BY order_date DESC

            """,
            (customer_id,),
        )
        rows = cursor.fetchall()

        orders = [
            Order(
                order_id=row["order_id"],
                customer_id=row['customer_id'],
                item=row['item'],
                amount=row['amount'],
                status=row['status'],
                order_date=row['order_date'],
            )
            for row in rows
        ]

        return AccountLookupResult(
            customer_found=True,
            customer=None,
            orders=orders,
            error=None,
        )
    except Exception as e:
        return AccountLookupResult(
            customer_found=False,
            error=f"Database error while retriving orders: {str(e)}",
        )
    finally:
        connection.close()
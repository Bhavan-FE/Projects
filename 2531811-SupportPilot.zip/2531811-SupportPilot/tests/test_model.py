import pytest
from pydantic import ValidationError

from app.models.classification import Classification


def test_valid_classification():

    result = Classification(
        issue_type="refund_request",
        urgency="medium",
        sentiment="frustrated",
        confidence=0.92,
    )

    assert result.issue_type == "refund_request"
    assert result.confidence == 0.92


def test_invalid_confidence():

    with pytest.raises(ValidationError):

        Classification(
            issue_type="refund_request",
            urgency="medium",
            sentiment="frustrated",
            confidence=1.5,
        )


def test_invalid_urgency():

    with pytest.raises(ValidationError):

        Classification(
            issue_type="refund_request",
            urgency="extreme",
            sentiment="frustrated",
            confidence=0.92,
        )
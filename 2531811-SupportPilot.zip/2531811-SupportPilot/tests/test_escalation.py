from app.models.classification import Classification
from app.models.account import (
    AccountLookupResult,
    Customer,
    Order,
)
from app.models.validation import ValidationResult

from app.rules.escalation import (
    evaluate_escalation,
    HIGH_VALUE_THRESHOLD,
)


def create_customer_context(amount=24999.0):
    return AccountLookupResult(
        customer_found=True,
        customer=Customer(
            customer_id="CUST0001",
            name="Arun Kumar",
            email="arun@example.com",
            account_standing="good",
            signup_date="2024-03-15",
            prior_ticket_count=2,
        ),
        orders=[
            Order(
                order_id="ORD0042",
                customer_id="CUST0001",
                item="Sony WH-1000XM5 Headphones",
                amount=amount,
                status="delivered",
                order_date="2026-09-15",
            )
        ],
    )


def create_valid_validation():
    return ValidationResult(
        passed=True,
        factual_accuracy=True,
        policy_compliance=True,
        tone_appropriate=True,
        grounding_passed=True,
        reasons=[],
    )


def create_classification(
    issue_type="damaged_item",
    confidence=0.95,
):
    return Classification(
        issue_type=issue_type,
        urgency="medium",
        sentiment="frustrated",
        confidence=confidence,
    )


def test_normal_case_does_not_escalate():

    result = evaluate_escalation(
        classification=create_classification(),
        account_context=create_customer_context(),
        validation=create_valid_validation(),
        ticket_text="My package arrived damaged and I need help.",
    )

    assert result.should_escalate is False
    assert result.rule_triggered is None


def test_low_confidence_escalates():

    result = evaluate_escalation(
        classification=create_classification(confidence=0.50),
        account_context=create_customer_context(),
        validation=create_valid_validation(),
        ticket_text="I have an unusual issue with my order.",
    )

    assert result.should_escalate is True
    assert result.rule_triggered == "low_confidence"


def test_fraud_escalates():

    result = evaluate_escalation(
        classification=create_classification(issue_type="fraud"),
        account_context=create_customer_context(),
        validation=create_valid_validation(),
        ticket_text="I think someone used my account fraudulently.",
    )

    assert result.should_escalate is True
    assert result.rule_triggered == "fraud"


def test_unrecognized_payment_escalates():

    result = evaluate_escalation(
        classification=create_classification(
            issue_type="payment_issue"
        ),
        account_context=create_customer_context(),
        validation=create_valid_validation(),
        ticket_text="I don't recognize this payment on my account.",
    )

    assert result.should_escalate is True
    assert result.rule_triggered == "suspicious_payment"


def test_manager_request_escalates():

    result = evaluate_escalation(
        classification=create_classification(),
        account_context=create_customer_context(),
        validation=create_valid_validation(),
        ticket_text="I want to speak to a manager immediately.",
    )

    assert result.should_escalate is True
    assert result.rule_triggered == "manager_request"


def test_legal_request_escalates():

    result = evaluate_escalation(
        classification=create_classification(),
        account_context=create_customer_context(),
        validation=create_valid_validation(),
        ticket_text="If this isn't resolved, I will take legal action.",
    )

    assert result.should_escalate is True
    assert result.rule_triggered == "legal_request"


def test_high_value_order_escalates():

    high_value_amount = HIGH_VALUE_THRESHOLD + 1

    result = evaluate_escalation(
        classification=create_classification(),
        account_context=create_customer_context(
            amount=high_value_amount
        ),
        validation=create_valid_validation(),
        ticket_text="My order arrived damaged.",
    )

    assert result.should_escalate is True
    assert result.rule_triggered == "high_value_order"


def test_validation_failure_escalates():

    failed_validation = ValidationResult(
        passed=False,
        factual_accuracy=False,
        policy_compliance=True,
        tone_appropriate=True,
        grounding_passed=False,
        reasons=["Unsupported refund claim."],
    )

    result = evaluate_escalation(
        classification=create_classification(),
        account_context=create_customer_context(),
        validation=failed_validation,
        ticket_text="My package arrived damaged.",
    )

    assert result.should_escalate is True
    assert result.rule_triggered == "validation_failure"


def test_unknown_customer_escalates():

    unknown_customer = AccountLookupResult(
        customer_found=False,
        customer=None,
        orders=[],
        error="Customer not found.",
    )

    result = evaluate_escalation(
        classification=create_classification(),
        account_context=unknown_customer,
        validation=create_valid_validation(),
        ticket_text="I need help with my order.",
    )

    assert result.should_escalate is True
    assert result.rule_triggered == "unknown_customer"
    
from app.agents.drafter import draft_response
from app.models.classification import Classification
from app.models.account import (
    AccountLookupResult,
    Customer,
    Order,
)
from app.models.policy import PolicyChunk


def test_drafting_showcase_case():

    classification = Classification(
        issue_type="damaged_item",
        urgency="medium",
        sentiment="frustrated",
        confidence=0.96,
    )

    customer_context = AccountLookupResult(
        customer_found=True,
        customer=Customer(
            customer_id="CUST0001",
            name="Arun Kumar",
            email="arun@example.com",
            account_standing="good",
            signup_date="2024-03-15",
            prior_ticket_count=2,
        ),
        orders=[
            Order(
                order_id="ORD0042",
                customer_id="CUST0001",
                item="Sony WH-1000XM5 Headphones",
                amount=24999.00,
                status="delivered",
                order_date="2026-09-15",
            )
        ],
    )

    policy_chunks = [
        PolicyChunk(
            content=(
                "Customers who receive products damaged during shipping "
                "can report the issue. Depending on the case, the customer "
                "may be eligible for a replacement or refund."
            ),
            source="shipping_damage_policy.md",
            section="0",
            score=0.15,
        ),
        PolicyChunk(
            content=(
                "For an approved full refund, the refund amount corresponds "
                "to the eligible order amount."
            ),
            source="refund_policy.md",
            section="0",
            score=0.18,
        ),
    ]

    result = draft_response(
        classification,
        customer_context,
        policy_chunks,
    )

    print("\nDRAFT:")
    print(result.response)

    print("\nCITATIONS:")
    print(result.citations)

    assert result.response
    assert len(result.citations) > 0
def test_drafting_does_not_invent_refund_timeline():

    classification = Classification(
        issue_type="refund_request",
        urgency="medium",
        sentiment="neutral",
        confidence=0.95,
    )

    customer_context = AccountLookupResult(
        customer_found=True,
        customer=None,
        orders=[],
    )

    policy_chunks = [
        PolicyChunk(
            content=(
                "Eligible customers may request a refund. "
                "The applicable refund amount corresponds to the "
                "eligible order amount."
            ),
            source="refund_policy.md",
            section="0",
            score=0.10,
        )
    ]

    result = draft_response(
        classification,
        customer_context,
        policy_chunks,
    )

    print("\nGROUNDING TEST:")
    print(result.response)

    assert result.response
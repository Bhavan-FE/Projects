from app.workflow.graph import support_graph


def test_support_graph_builds():

    assert support_graph is not None
from app.db.seed import seed_database
from app.tools.customer_tools import get_customer
from app.tools.order_tools import get_orders


def test_get_customer():
    seed_database()

    result = get_customer.invoke({
        "customer_id": "CUST0001"
    })

    print("\nCUSTOMER RESULT:")
    print(result)

    assert result.customer_found is True
    assert result.customer.customer_id == "CUST0001"
    assert result.customer.name == "Arun Kumar"


def test_get_customer_unknown():
    seed_database()

    result = get_customer.invoke({
        "customer_id": "CUST9999"
    })

    assert result.customer_found is False
    assert result.error is not None


def test_get_customer_invalid_id():
    seed_database()

    result = get_customer.invoke({
        "customer_id": "INVALID"
    })

    assert result.customer_found is False
    assert result.error is not None


def test_get_orders():
    seed_database()

    result = get_orders.invoke({
        "customer_id": "CUST0001"
    })

    assert result.customer_found is True
    assert len(result.orders) == 2

    order_ids = [order.order_id for order in result.orders]

    assert "ORD0042" in order_ids
    assert "ORD0043" in order_ids


def test_get_orders_unknown_customer():
    seed_database()

    result = get_orders.invoke({
        "customer_id": "CUST9999"
    })

    assert result.customer_found is False
    assert result.error is not None


def test_get_orders_invalid_customer_id():
    seed_database()

    result = get_orders.invoke({
        "customer_id": "ABC"
    })

    assert result.customer_found is False
    assert result.error is not None
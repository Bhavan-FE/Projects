from app.agents.classifier import classify_ticket


def test_damage_ticket_classification():

    ticket = """
    My package arrived completely damaged and the item inside is broken.
    I want a full refund.
    """

    result = classify_ticket(ticket)

    print("\nCLASSIFICATION:", result)

    assert result.issue_type.value in {
        "damaged_item",
        "refund_request",
    }

    assert result.urgency.value in {
        "low",
        "medium",
        "high",
    }

    assert result.sentiment.value in {
        "positive",
        "neutral",
        "frustrated",
        "angry",
    }

    assert 0.0 <= result.confidence <= 1.0
from app.agents.validator import validate_response

from app.models.classification import Classification
from app.models.account import (
    AccountLookupResult,
    Customer,
    Order,
)
from app.models.policy import PolicyChunk
from app.models.state import DraftResponse


def test_validation_passes_for_grounded_response():

    classification = Classification(
        issue_type="damaged_item",
        urgency="medium",
        sentiment="frustrated",
        confidence=0.96,
    )

    customer_context = AccountLookupResult(
        customer_found=True,
        customer=Customer(
            customer_id="CUST0001",
            name="Arun Kumar",
            email="arun@example.com",
            account_standing="good",
            signup_date="2024-03-15",
            prior_ticket_count=2,
        ),
        orders=[
            Order(
                order_id="ORD0042",
                customer_id="CUST0001",
                item="Sony WH-1000XM5 Headphones",
                amount=24999.00,
                status="delivered",
                order_date="2026-09-15",
            )
        ],
    )

    policy_chunks = [
        PolicyChunk(
            content=(
                "Customers who receive products damaged during shipping "
                "can report the issue. Depending on the case, the customer "
                "may be eligible for a replacement or refund."
            ),
            source="shipping_damage_policy.md",
            section="0",
            score=0.15,
        ),
        PolicyChunk(
            content=(
                "For an approved full refund, the refund amount corresponds "
                "to the eligible order amount."
            ),
            source="refund_policy.md",
            section="0",
            score=0.18,
        ),
    ]

    draft = DraftResponse(
    response=(
        "I'm sorry that your order arrived damaged. "
        "Your order ORD0042 for Sony WH-1000XM5 Headphones "
        "is listed as delivered, with an order amount of ₹24,999. "
        "Depending on the case and verification, you may be "
        "eligible for a refund or replacement. "
        "I cannot confirm that a refund has been approved at this stage. "
        "If a full refund is approved after verification, "
        "the refund amount would be ₹24,999, matching the eligible "
        "order amount."
    ),
    citations=[
        "shipping_damage_policy.md",
        "refund_policy.md",
    ],
    )
    result = validate_response(
        draft_response=draft,
        customer_context=customer_context,
        retrieved_policy_chunks=policy_chunks,
        classification=classification,
    )

    print("\nVALIDATION RESULT:")
    print(result)

    assert result.passed is True
    assert result.factual_accuracy is True
    assert result.policy_compliance is True
    assert result.tone_appropriate is True
    assert result.grounding_passed is True


def test_validation_detects_unsupported_timeline():

    classification = Classification(
        issue_type="refund_request",
        urgency="medium",
        sentiment="neutral",
        confidence=0.95,
    )

    customer_context = AccountLookupResult(
        customer_found=True,
        customer=None,
        orders=[],
    )

    policy_chunks = [
        PolicyChunk(
            content=(
                "Support representatives must not promise a specific "
                "refund processing timeline unless that timeline is "
                "explicitly available in the applicable order or "
                "support system."
            ),
            source="refund_policy.md",
            section="Refund Processing",
            score=0.10,
        )
    ]

    draft = DraftResponse(
        response=(
            "Your refund has been approved and you will receive "
            "the money within 2 business days."
        ),
        citations=[
            "refund_policy.md",
        ],
    )

    result = validate_response(
        draft_response=draft,
        customer_context=customer_context,
        retrieved_policy_chunks=policy_chunks,
        classification=classification,
    )

    print("\nTIMELINE VALIDATION:")
    print(result)

    assert result.passed is False
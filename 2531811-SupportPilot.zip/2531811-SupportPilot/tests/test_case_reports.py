import json

from app.db.database import get_connection, initialize_database
from app.db.seed import seed_database
from app.models.classification import (
    Classification,
    IssueType,
    Sentiment,
    Urgency,
)
from app.tools.case_report_tools import write_case_report


def create_classification():
    return Classification(
        issue_type=IssueType.DAMAGED_ITEM,
        urgency=Urgency.MEDIUM,
        sentiment=Sentiment.FRUSTRATED,
        confidence=0.94,
    )


def test_write_case_report():

    seed_database()

    classification = create_classification()

    result = write_case_report.invoke(
        {
            "ticket_id": "TICK0001",
            "classification": classification,
            "resolution_path": "escalated",
            "final_response": (
                "I'm sorry that your order arrived damaged. "
                "Your case requires further review."
            ),
            "escalation_reason": "High-value order requires escalation.",
            "agent_trace": [
                "classifier",
                "account_lookup",
                "knowledge_retrieval",
                "drafting",
                "validation",
                "escalation",
                "case_closure",
            ],
        }
    )

    assert result.success is True
    assert result.ticket_id == "TICK0001"

    connection = get_connection()

    cursor = connection.cursor()

    cursor.execute(
        """
        SELECT *
        FROM case_reports
        WHERE ticket_id = ?
        ORDER BY id DESC
        LIMIT 1
        """,
        ("TICK0001",),
    )

    row = cursor.fetchone()

    connection.close()

    assert row is not None

    assert row["issue_type"] == "damaged_item"

    assert row["urgency"] == "medium"

    assert row["sentiment"] == "frustrated"

    assert row["confidence"] == 0.94

    assert row["resolution_path"] == "escalated"

    assert row["escalation_reason"] == (
        "High-value order requires escalation."
    )

    trace = json.loads(row["agent_trace"])

    assert trace[0] == "classifier"

    assert trace[-1] == "case_closure"


def test_invalid_ticket_id():

    initialize_database()

    classification = create_classification()

    result = write_case_report.invoke(
        {
            "ticket_id": "INVALID",
            "classification": classification,
            "resolution_path": "escalated",
            "final_response": "Test response",
            "escalation_reason": "Test reason",
            "agent_trace": ["case_closure"],
        }
    )

    assert result.success is False

    assert result.error is not None


def test_invalid_resolution_path():

    initialize_database()

    classification = create_classification()

    result = write_case_report.invoke(
        {
            "ticket_id": "TICK0002",
            "classification": classification,
            "resolution_path": "something_random",
            "final_response": "Test response",
            "escalation_reason": None,
            "agent_trace": ["case_closure"],
        }
    )

    assert result.success is False

    assert result.error is not None
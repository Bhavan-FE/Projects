from app.db.database import get_connection, initialize_database
from app.db.seed import seed_database


def test_customer_exists():

    seed_database()

    connection = get_connection()

    cursor = connection.cursor()

    cursor.execute(
        """
        SELECT *
        FROM customers
        WHERE customer_id = ?
        """,
        ("CUST0001",),
    )

    customer = cursor.fetchone()

    connection.close()

    assert customer is not None
    assert customer["name"] == "Arun Kumar"


def test_showcase_order_exists():

    seed_database()

    connection = get_connection()

    cursor = connection.cursor()

    cursor.execute(
        """
        SELECT *
        FROM orders
        WHERE order_id = ?
        """,
        ("ORD0042",),
    )

    order = cursor.fetchone()

    connection.close()

    assert order is not None
    assert order["customer_id"] == "CUST0001"
    assert order["amount"] == 24999.00
    assert order["status"] == "delivered"


def test_unknown_customer():

    seed_database()

    connection = get_connection()

    cursor = connection.cursor()

    cursor.execute(
        """
        SELECT *
        FROM customers
        WHERE customer_id = ?
        """,
        ("CUST9999",),
    )

    customer = cursor.fetchone()

    connection.close()

    assert customer is None
# Refund Policy

## Refund Eligibility

Customers may request a refund for eligible purchases when the product was damaged, defective, incorrectly delivered, or otherwise qualifies under the applicable return conditions.

## Damaged Products

If a delivered product is damaged, the customer should provide the order information and describe the damage. The support team should verify the order before confirming the applicable resolution.

## Refund Amount

For an approved full refund, the refund amount corresponds to the eligible order amount.

## Refund Processing

Support representatives must not promise a specific refund processing timeline unless that timeline is explicitly available in the applicable order or support system.

## Customer Communication

Responses should explain the applicable policy without guaranteeing approval before the required verification has been completed.
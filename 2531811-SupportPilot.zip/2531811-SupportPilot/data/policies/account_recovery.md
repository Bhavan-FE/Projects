# Account Recovery

## Account Access

Customers who cannot access their account should use the supported account recovery process.

## Identity Verification

Additional verification may be required before account access can be restored.

## Security

Support must not disclose sensitive account information without appropriate verification.
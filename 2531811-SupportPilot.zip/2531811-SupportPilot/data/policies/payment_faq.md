# Payment FAQ

## Unrecognized Payment

Customers who report an unrecognized or unauthorized payment should not be assured that the transaction is legitimate.

Such cases require investigation and may require escalation.

## Payment Information

Support responses must not expose sensitive payment information.

## Duplicate Transactions

Reports of duplicate or suspicious transactions should be reviewed before providing a final resolution.
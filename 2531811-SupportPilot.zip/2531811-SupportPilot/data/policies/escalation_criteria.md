# Internal Escalation Criteria

## Fraud

Suspected fraud, unauthorized transactions, or unrecognized payments must be escalated for investigation.

## Manager Requests

Explicit requests to speak with a manager must be escalated.

## Legal Requests

Legal threats, legal requests, or requests involving legal action must be escalated.

## High-Value Orders

Orders above the configured high-value threshold require escalation.

## Low Confidence

Tickets with classification confidence below the configured threshold require escalation.

## Validation Failure

A response that fails factual accuracy, policy compliance, tone, or grounding validation must not be automatically resolved.

## Unknown Customer

If the customer cannot be found in the support database, the case should be escalated rather than automatically resolved.
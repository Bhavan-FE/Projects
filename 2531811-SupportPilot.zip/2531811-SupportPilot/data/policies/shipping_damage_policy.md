# Shipping Damage Policy

## Damaged Delivery

Customers who receive products damaged during shipping can report the issue to ShopStream support.

## Verification

Support should verify the relevant order and confirm that the reported product corresponds to the order.

## Resolution

Depending on the case and applicable policy, the customer may be eligible for a replacement or refund.

## Repeated Damage

Repeated reports of damaged deliveries should receive additional review, particularly when the customer has reported multiple similar incidents.

## Communication

Support should acknowledge the customer's concern and avoid promising a specific resolution until the required verification is complete.
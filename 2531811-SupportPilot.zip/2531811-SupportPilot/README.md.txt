SupportPilot
============

How to Run the Application
--------------------------

1. Extract the Project

Extract the project files and open a terminal in the project's root folder.


2. Create a Virtual Environment

Run:

python -m venv venv

Activate the virtual environment.

Windows Command Prompt:

venv\Scripts\activate

Windows PowerShell:

.\venv\Scripts\Activate.ps1

macOS or Linux:

source venv/bin/activate


3. Install the Dependencies

Run the following command from the project's root folder:

pip install -r requirements.txt


4. Configure the API Key

Create a file named ".env" in the project's root folder.

Add your API key to the .env file:

OPENAI_API_KEY="<your-api-key-here>"

Replace <your-api-key-here> with your actual API key.

Important:
Do not share your API key or commit the .env file to Git.


5. Launch the Application

Run:

python -m app.ui

After the application starts, open the local URL displayed in the terminal.

The URL is usually:

http://127.0.0.1:7860
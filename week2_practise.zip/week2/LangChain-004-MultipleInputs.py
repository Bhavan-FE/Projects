from langchain_core.prompts import PromptTemplate
from langchain_openai import ChatOpenAI
from dotenv import load_dotenv
import os
 
load_dotenv()
 
assert os.environ.get("OPENAI_API_KEY"), "OPENAI_API_KEY not found"
 
llm = ChatOpenAI(
    model="gpt-4o-mini",
    temperature=0
)
 
prompt_template = PromptTemplate.from_template(
    "Tell me a {adjective} joke about {content}."
)
 
prompt_1 = prompt_template.format(
    adjective="funny",
    content="chickens"
)
 
prompt_2 = prompt_template.format(
    adjective="dark",
    content="football"
)
 
batched_output = llm.batch([prompt_1, prompt_2])
 
for response in batched_output:
    print(response.content)
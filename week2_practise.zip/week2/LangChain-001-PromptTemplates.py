from typing import TypedDict
from langgraph.graph import StateGraph, END
from langchain_anthropic import ChatAnthropic
from langchain_core.prompts import ChatPromptTemplate
 
from langchain_core.prompts import PromptTemplate
import os
from dotenv import load_dotenv
import anthropic
 
finalized_prompt = "Tell me  {adjective} headline about {content}."
prompt_template = PromptTemplate.from_template(finalized_prompt)
 
#Now we have prompt and its template we can simply make the prompt dynamic
prompt_1 = prompt_template.format(adjective="rare", content="Cricket")
prompt_2 = prompt_template.format(adjective="common", content="Football")
 
chat_template = ChatPromptTemplate.from_messages(
    [
        ("system", "You are a helpful AI bot. Your name is {name}."),
        ("human", "Hello, how are you doing?"),
        ("ai", "I'm doing well, thanks!"),
        ("human", "{user_input}"),
    ]
)
 
messages = chat_template.format_messages(name="Bob", user_input="What is your name?")
print(messages)
from typing import TypedDict, List
from langchain_anthropic import ChatAnthropic
 
# ----------------------------------------------------------
# LLM
# ----------------------------------------------------------
import os
import sys
from dotenv import load_dotenv
import anthropic
sys.stdout.reconfigure(encoding="utf-8")
#load_dotenv(dotenv_path=os.path.join('..', '.env'))
load_dotenv()
assert os.environ.get('ANTHROPIC_API_KEY'), (
    'ANTHROPIC_API_KEY not found. Add it to the project-root .env file.'
)
 
# The client reads ANTHROPIC_API_KEY from the environment automatically.
client = anthropic.Anthropic()
MODEL = 'claude-haiku-4-5'
 
llm = ChatAnthropic(
    model=MODEL
)
 
judge_llm = ChatAnthropic(
    model=MODEL
)
 
# ----------------------------------------------------------
# Mock Tools
# ----------------------------------------------------------
 
def search_tool(query: str):
    return f"Search results for: {query}"
 
 
def calculator_tool(expression: str):
    return str(eval(expression))
 
 
# ----------------------------------------------------------
# Trace State
# ----------------------------------------------------------
 
class AgentState(TypedDict):
    question: str
    answer: str
    trace: List[str]
 
 
# ----------------------------------------------------------
# Planning Step
# ----------------------------------------------------------
 
def planning_step(state: AgentState):
 
    prompt = f"""
You are an intelligent planning agent.
 
Question:
{state['question']}
 
Create a short execution plan.
"""
 
    plan = llm.invoke(prompt).content
 
    state["trace"].append(
        f"PLAN:\n{plan}"
    )
 
    return state
 
 
# ----------------------------------------------------------
# Tool Selection Step
# ----------------------------------------------------------
 
def tool_selection_step(state: AgentState):
 
    prompt = f"""
Question:
{state['question']}
 
Choose one tool:
 
1. SEARCH
2. CALCULATOR
 
Return only tool name.
"""
 
    tool = llm.invoke(prompt).content.strip().upper()
 
    state["trace"].append(
        f"TOOL_SELECTED: {tool}"
    )
 
    if "CALCULATOR" in tool:
 
        result = calculator_tool("245*12")
 
        state["trace"].append(
            f"TOOL_OUTPUT: {result}"
        )
 
        state["answer"] = result
 
    else:
 
        result = search_tool(
            state["question"]
        )
 
        state["trace"].append(
            f"TOOL_OUTPUT: {result}"
        )
 
        state["answer"] = result
 
    return state
 
 
# ----------------------------------------------------------
# Trace Evaluation Step
# ----------------------------------------------------------
 
def evaluate_trace(state: AgentState):
 
    trace_text = "\n\n".join(
        state["trace"]
    )
 
    evaluation_prompt = f"""
You are an Agent Evaluator.
 
Evaluate the following execution trace.
 
TRACE:
{trace_text}
 
Provide scores out of 10.
 
Criteria:
 
1. Planning Quality
2. Tool Selection Quality
3. Reasoning Consistency
4. Overall Execution
 
Explain briefly.
"""
 
    evaluation = judge_llm.invoke(
        evaluation_prompt
    ).content
 
    return evaluation
 
 
# ----------------------------------------------------------
# Agent Runner
# ----------------------------------------------------------
 
def run_agent(question):
 
    state = {
        "question": question,
        "answer": "",
        "trace": []
    }
 
    state = planning_step(state)
    state = tool_selection_step(state)
 
    evaluation = evaluate_trace(state)
 
    print("\n")
    print("=" * 80)
    print("FINAL ANSWER")
    print("=" * 80)
    print(state["answer"])
 
    print("\n")
    print("=" * 80)
    print("TRACE")
    print("=" * 80)
 
    for item in state["trace"]:
        print(item)
        print()
 
    print("\n")
    print("=" * 80)
    print("TRACE EVALUATION")
    print("=" * 80)
    print(evaluation)
 
 
# ----------------------------------------------------------
# Example
# ----------------------------------------------------------
 
run_agent(
    "What is the population of India?"
)
run_agent(
    "compute 22/7 * 22/7  "
)
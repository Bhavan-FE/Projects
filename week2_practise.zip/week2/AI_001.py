from typing import TypedDict
from langgraph.graph import StateGraph, END
from langchain_anthropic import ChatAnthropic
from langchain_core.prompts import ChatPromptTemplate
#sys.stdout.reconfigure(encoding="utf-8")
# -------------------------------------------------------------------
# LLM
# -------------------------------------------------------------------
import os
from dotenv import load_dotenv
import anthropic
 
#load_dotenv(dotenv_path=os.path.join('..', '.env'))
load_dotenv()
assert os.environ.get('ANTHROPIC_API_KEY'), (
    'ANTHROPIC_API_KEY not found. Add it to the project-root .env file.'
)
 
# The client reads ANTHROPIC_API_KEY from the environment automatically.
client = anthropic.Anthropic()
 
MODEL = 'claude-haiku-4-5'   # supports temperature / top_k / top_p (Opus 4.8 / 4.7 do not)
 
llm = ChatAnthropic(
    model=MODEL
 
)
 
# -------------------------------------------------------------------
# State
# -------------------------------------------------------------------
class SocialMediaState(TypedDict):
    topic: str
    linkedin_post: str
    x_post: str
    facebook_post: str
    instagram_post: str
 
 
# -------------------------------------------------------------------
# LinkedIn Post Generator
# -------------------------------------------------------------------
def generate_linkedin_post(state: SocialMediaState):
    prompt = ChatPromptTemplate.from_template("""
You are an expert LinkedIn content strategist.
 
Create a professional LinkedIn post based on:
 
Topic:
{topic}
 
Requirements:
- Professional tone
- 150 to 250 words
- Include business value
- Include a call to action
- Use a few relevant hashtags
""")
 
    response = llm.invoke(
        prompt.format_messages(topic=state["topic"])
    )
 
    return {"linkedin_post": response.content}
 
 
# -------------------------------------------------------------------
# X (Twitter) Post Generator
# -------------------------------------------------------------------
def generate_x_post(state: SocialMediaState):
    prompt = ChatPromptTemplate.from_template("""
You are an expert social media creator.
 
Create an X (Twitter) post.
 
Topic:
{topic}
 
Requirements:
- Maximum 280 characters
- Attention-grabbing
- Include relevant hashtags
- Encourage engagement
""")
 
    response = llm.invoke(
        prompt.format_messages(topic=state["topic"])
    )
 
    return {"x_post": response.content}
 
 
# -------------------------------------------------------------------
# Facebook Post Generator
# -------------------------------------------------------------------
def generate_facebook_post(state: SocialMediaState):
    prompt = ChatPromptTemplate.from_template("""
You are a Facebook marketing specialist.
 
Create a Facebook post about:
 
Topic:
{topic}
 
Requirements:
- Friendly conversational tone
- 100 to 200 words
- Encourage comments and shares
- Use emojis where appropriate
""")
 
    response = llm.invoke(
        prompt.format_messages(topic=state["topic"])
    )
 
    return {"facebook_post": response.content}
 
 
# -------------------------------------------------------------------
# Instagram Post Generator
# -------------------------------------------------------------------
def generate_instagram_post(state: SocialMediaState):
    prompt = ChatPromptTemplate.from_template("""
You are an Instagram content expert.
 
Create an Instagram caption about:
 
Topic:
{topic}
 
Requirements:
- Visually engaging style
- Include emojis
- 100 to 150 words
- End with relevant hashtags
- Encourage interaction
""")
 
    response = llm.invoke(
        prompt.format_messages(topic=state["topic"])
    )
 
    return {"instagram_post": response.content}
 
 
# -------------------------------------------------------------------
# LangGraph Definition
# -------------------------------------------------------------------
graph = StateGraph(SocialMediaState)
 
graph.add_node("linkedin", generate_linkedin_post)
graph.add_node("x", generate_x_post)
graph.add_node("facebook", generate_facebook_post)
graph.add_node("instagram", generate_instagram_post)
 
graph.set_entry_point("linkedin")
 
graph.add_edge("linkedin", "x")
graph.add_edge("x", "facebook")
graph.add_edge("facebook", "instagram")
graph.add_edge("instagram", END)
 
app = graph.compile()
 
# -------------------------------------------------------------------
# Run
# -------------------------------------------------------------------
result = app.invoke(
    {
        "topic": """
        will AI replace software engineers in the next 5 years?
        """
    }
)
 
print("\n" + "="*80)
print("LINKEDIN POST")
print("="*80)
print(result["linkedin_post"])
 
print("\n" + "="*80)
print("X POST")
print("="*80)
print(result["x_post"])
 
print("\n" + "="*80)
print("FACEBOOK POST")
print("="*80)
print(result["facebook_post"])
 
 
print("\n" + "="*80)
print("Instagram POST")
print("="*80)
print(result["instagram_post"])
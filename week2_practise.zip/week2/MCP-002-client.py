import asyncio
import json
from mcp import ClientSession
from mcp.client.sse import sse_client
 
 
async def main():
 
    async with sse_client(
        "http://localhost:8000/sse"
    ) as (read_stream, write_stream):
 
        async with ClientSession(
            read_stream,
            write_stream
        ) as session:
 
            await session.initialize()
 
            result = await session.call_tool(
                "show_records",
                {
                    "table_name": "movies",
                    "limit": 5
                }
            )
 
            data = json.loads(result.content[0].text)
 
            print("\nRESULT")
            print(json.dumps(data, indent=4))
 
 
asyncio.run(main())
from pathlib import Path
 
from typing import List, Literal
 
import hashlib
 
import os
 
import re
 
from dotenv import load_dotenv
 
from pydantic import BaseModel, Field
 
import lancedb
 
from langchain_community.document_loaders import TextLoader
 
from langchain_community.vectorstores import LanceDB
 
from langchain_openai import (
 
    ChatOpenAI,
 
    OpenAIEmbeddings
 
)
 
from langchain_core.prompts import (
 
    ChatPromptTemplate
 
)
 
from langchain_core.documents import (
 
    Document
 
)
 
 
# ---------------------------------------------------------
 
# Structured Output Models
 
# ---------------------------------------------------------
 
class Proposition(BaseModel):
 
    proposition: str = Field(
 
        description=(
 
            "One atomic, factual, concise, self-contained "
 
            "proposition derived only from the supplied content."
 
        )
 
    )
 
    concept: Literal[
 
        "movie_information",
 
        "multiple_roles",
 
        "fake_identity",
 
        "both"
 
    ] = Field(
 
        description=(
 
            "The primary concept described by the proposition."
 
        )
 
    )
 
    short_description: str = Field(
 
        description=(
 
            "A concise explanation of the proposition."
 
        )
 
    )
 
 
class PropositionCollection(BaseModel):
 
    movie_name: str = Field(
 
        description=(
 
            "Movie name exactly as found in the supplied content. "
 
            "Return Unknown when it is unavailable."
 
        )
 
    )
 
    propositions: List[Proposition] = Field(
 
        description=(
 
            "Atomic, factual, self-contained propositions "
 
            "derived only from the supplied movie content."
 
        )
 
    )
 
 
class PropositionValidation(BaseModel):
 
    is_supported: bool = Field(
 
        description=(
 
            "True only when the proposition is directly supported "
 
            "by the supplied source content."
 
        )
 
    )
 
    is_atomic: bool = Field(
 
        description=(
 
            "True when the proposition communicates one primary fact."
 
        )
 
    )
 
    is_self_contained: bool = Field(
 
        description=(
 
            "True when the proposition can be understood without "
 
            "reading the original movie section."
 
        )
 
    )
 
    is_relevant: bool = Field(
 
        description=(
 
            "True when the proposition contains meaningful information "
 
            "about the movie, roles, characters, disguises, aliases, "
 
            "impersonations, or identities."
 
        )
 
    )
 
    corrected_proposition: str = Field(
 
        description=(
 
            "A corrected grounded proposition. Return an empty string "
 
            "if the original proposition cannot be corrected using "
 
            "only the supplied source content."
 
        )
 
    )
 
    reason: str = Field(
 
        description=(
 
            "A short explanation of the validation decision."
 
        )
 
    )
 
 
# ---------------------------------------------------------
 
# 1. Load Environment Variables
 
# ---------------------------------------------------------
 
load_dotenv()
 
if not os.getenv("OPENAI_API_KEY"):
 
    raise EnvironmentError(
 
        "OPENAI_API_KEY not found in .env file"
 
    )
 
 
# ---------------------------------------------------------
 
# 2. Configuration
 
# ---------------------------------------------------------
 
FILE_PATH = Path("Movies.txt")
 
CHAT_MODEL = "gpt-4o-mini"
 
EMBEDDING_MODEL = (
 
    "text-embedding-3-small"
 
)
 
TOP_K = 8
 
LANCEDB_FOLDER = (
 
    "./movies_proposition_lancedb"
 
)
 
LANCEDB_TABLE = (
 
    "movie_propositions"
 
)
 
VALIDATE_PROPOSITIONS = True
 
STORE_PARENT_CONTENT_IN_EMBEDDED_TEXT = True
 
 
# ---------------------------------------------------------
 
# 3. Validate Input File
 
# ---------------------------------------------------------
 
if not FILE_PATH.exists():
 
    raise FileNotFoundError(
 
        f"Movies file not found: "
 
        f"{FILE_PATH.resolve()}"
 
    )
 
 
# ---------------------------------------------------------
 
# 4. Load Movie File
 
# ---------------------------------------------------------
 
loader = TextLoader(
 
    file_path=str(FILE_PATH),
 
    encoding="utf-8"
 
)
 
documents = loader.load()
 
if not documents:
 
    raise ValueError(
 
        "Movies.txt was loaded, but no document was returned."
 
    )
 
raw_content = (
 
    documents[0].page_content
 
)
 
if not raw_content.strip():
 
    raise ValueError(
 
        "Movies.txt is empty."
 
    )
 
print("\n")
 
print("=" * 80)
 
print("DOCUMENT LOAD VERIFICATION")
 
print("=" * 80)
 
print(
 
    f"Documents Loaded : "
 
    f"{len(documents)}"
 
)
 
print(
 
    f"Characters Loaded : "
 
    f"{len(raw_content)}"
 
)
 
print("\nPreview\n")
 
print(
 
    raw_content[:1000]
 
)
 
 
# ---------------------------------------------------------
 
# 5. Normalize Line Endings
 
# ---------------------------------------------------------
 
normalized_content = (
 
    raw_content
 
    .replace(
 
        "\r\n",
 
        "\n"
 
    )
 
    .replace(
 
        "\r",
 
        "\n"
 
    )
 
)
 
 
# ---------------------------------------------------------
 
# 6. Initial Split Based On Empty Lines
 
# ---------------------------------------------------------
 
# This initial split creates parent movie sections.
 
# These parent sections are not the final proposition chunks.
 
parent_sections = [
 
    section.strip()
 
    for section in re.split(
 
        r"\n\s*\n",
 
        normalized_content
 
    )
 
    if section.strip()
 
]
 
if not parent_sections:
 
    raise ValueError(
 
        "No non-empty movie sections were found."
 
    )
 
parent_docs = [
 
    Document(
 
        page_content=section,
 
        metadata={
 
            "parent_section_number": index,
 
            "source": str(FILE_PATH)
 
        }
 
    )
 
    for index, section in enumerate(
 
        parent_sections,
 
        start=1
 
    )
 
]
 
print("\n")
 
print("=" * 80)
 
print("PARENT SECTION VERIFICATION")
 
print("=" * 80)
 
print(
 
    f"Parent Sections Created : "
 
    f"{len(parent_docs)}"
 
)
 
for index, parent_doc in enumerate(
 
    parent_docs[:5],
 
    start=1
 
):
 
    print("\n")
 
    print("-" * 80)
 
    print(
 
        f"Parent Section {index}"
 
    )
 
    print("-" * 80)
 
    print(
 
        parent_doc.page_content[:500]
 
    )
 
 
# ---------------------------------------------------------
 
# 7. Create Proposition Generation LLM
 
# ---------------------------------------------------------
 
generation_llm = ChatOpenAI(
 
    model=CHAT_MODEL,
 
    temperature=0
 
)
 
structured_generation_llm = (
 
    generation_llm.with_structured_output(
 
        PropositionCollection
 
    )
 
)
 
 
# ---------------------------------------------------------
 
# 8. Proposition Generation Prompt
 
# ---------------------------------------------------------
 
generation_system_prompt = """
 
You perform proposition chunking for a movie RAG system.
 
Convert the supplied movie content into atomic, factual,
 
self-contained propositions.
 
A valid proposition must:
 
1. Express one primary fact.
 
2. Be understandable without reading the source section.
 
3. Use the movie name and complete character names wherever
 
   they are explicitly available.
 
4. Replace ambiguous pronouns such as he, she, it, they,
 
   this movie, and the actor with explicit entities.
 
5. Preserve important qualifiers.
 
6. Be concise.
 
7. Be directly supported by the supplied content.
 
8. Avoid outside knowledge.
 
9. Avoid assumptions.
 
10. Avoid inventing movie names, characters, roles, aliases,
 
    disguises, relationships, or plot details.
 
Pay particular attention to:
 
1. Multiple roles:
 
   The actor plays two or more genuinely distinct roles
 
   or characters.
 
2. Fake identity:
 
   One actual character uses a disguise, alias, assumed
 
   identity, impersonation, or false identity.
 
3. Both:
 
   The source explicitly describes multiple distinct roles
 
   and also a fake identity, disguise, alias, or impersonation.
 
Important classification rules:
 
1. Use "multiple_roles" when a proposition explicitly describes
 
   multiple distinct characters or roles.
 
2. Use "fake_identity" when a proposition explicitly describes
 
   one person adopting a disguise, alias, impersonation, or
 
   assumed identity.
 
3. Use "both" only when one atomic proposition must explicitly
 
   communicate that both concepts occur in the movie.
 
4. Use "movie_information" for other useful movie facts.
 
5. Multiple names do not automatically indicate multiple roles.
 
6. A title, nickname, or informal name does not automatically
 
   indicate a fake identity.
 
7. Do not generate a proposition saying that a concept is absent
 
   unless the source explicitly states its absence.
 
8. If the content provides no meaningful fact, return an empty
 
   proposition list.
 
Example:
 
Source:
 
Movie: Example Movie
 
The actor plays Raja and Kumar as separate characters.
 
Raja disguises himself as an inspector.
 
Possible propositions:
 
1. In Example Movie, the actor plays the distinct characters
 
   Raja and Kumar.
 
2. In Example Movie, Raja disguises himself as an inspector.
 
3. Example Movie contains both multiple distinct roles and
 
   the use of a fake identity.
 
Each proposition will be independently embedded and retrieved.
 
Therefore, every proposition must carry enough context to stand alone.
 
"""
 
generation_prompt = (
 
    ChatPromptTemplate.from_messages(
 
        [
 
            (
 
                "system",
 
                generation_system_prompt
 
            ),
 
            (
 
                "human",
 
                """
 
Generate grounded propositions from the following movie content.
 
Movie Content:
 
{movie_content}
 
"""
 
            )
 
        ]
 
    )
 
)
 
generation_chain = (
 
    generation_prompt
 
    | structured_generation_llm
 
)
 
 
# ---------------------------------------------------------
 
# 9. Create Proposition Validation LLM
 
# ---------------------------------------------------------
 
validation_llm = ChatOpenAI(
 
    model=CHAT_MODEL,
 
    temperature=0
 
)
 
structured_validation_llm = (
 
    validation_llm.with_structured_output(
 
        PropositionValidation
 
    )
 
)
 
 
# ---------------------------------------------------------
 
# 10. Proposition Validation Prompt
 
# ---------------------------------------------------------
 
validation_system_prompt = """
 
You validate propositions created for a RAG system.
 
Evaluate the supplied proposition against its source content.
 
A proposition is acceptable only when it is:
 
1. Directly supported by the source.
 
2. Atomic.
 
3. Self-contained.
 
4. Meaningful for movie retrieval.
 
5. Free from outside knowledge.
 
6. Free from invented names, roles, identities, or plot details.
 
Rules:
 
1. Use only the provided source content.
 
2. Reject unsupported propositions.
 
3. Reject propositions that depend on missing context.
 
4. Reject meaningless or overly vague statements.
 
5. If a proposition can be corrected using only the source,
 
   provide the corrected proposition.
 
6. If it cannot be corrected, return an empty corrected proposition.
 
7. Do not add new information while correcting it.
 
"""
 
validation_prompt = (
 
    ChatPromptTemplate.from_messages(
 
        [
 
            (
 
                "system",
 
                validation_system_prompt
 
            ),
 
            (
 
                "human",
 
                """
 
Source Content:
 
{source_content}
 
Proposition:
 
{proposition}
 
"""
 
            )
 
        ]
 
    )
 
)
 
validation_chain = (
 
    validation_prompt
 
    | structured_validation_llm
 
)
 
 
# ---------------------------------------------------------
 
# 11. Helper: Normalize Text For Duplicate Detection
 
# ---------------------------------------------------------
 
def normalize_for_comparison(
 
    text: str
 
) -> str:
 
    normalized_text = text.lower().strip()
 
    normalized_text = re.sub(
 
        r"\s+",
 
        " ",
 
        normalized_text
 
    )
 
    normalized_text = re.sub(
 
        r"[^\w\s]",
 
        "",
 
        normalized_text
 
    )
 
    return normalized_text
 
 
# ---------------------------------------------------------
 
# 12. Helper: Create Stable Proposition ID
 
# ---------------------------------------------------------
 
def create_proposition_id(
 
    parent_section_number: int,
 
    proposition_number: int,
 
    proposition_text: str
 
) -> str:
 
    value = (
 
        f"{parent_section_number}|"
 
        f"{proposition_number}|"
 
        f"{proposition_text}"
 
    )
 
    digest = hashlib.sha256(
 
        value.encode("utf-8")
 
    ).hexdigest()
 
    return digest[:16]
 
 
# ---------------------------------------------------------
 
# 13. Helper: Validate One Proposition
 
# ---------------------------------------------------------
 
def validate_proposition(
 
    source_content: str,
 
    proposition_text: str
 
) -> tuple[bool, str, str]:
 
    if not VALIDATE_PROPOSITIONS:
 
        return (
 
            True,
 
            proposition_text.strip(),
 
            "LLM validation disabled."
 
        )
 
    try:
 
        validation = validation_chain.invoke(
 
            {
 
                "source_content": source_content,
 
                "proposition": proposition_text
 
            }
 
        )
 
        corrected_text = (
 
            validation.corrected_proposition.strip()
 
        )
 
        all_checks_passed = (
 
            validation.is_supported
 
            and validation.is_atomic
 
            and validation.is_self_contained
 
            and validation.is_relevant
 
        )
 
        if all_checks_passed:
 
            final_text = (
 
                corrected_text
 
                if corrected_text
 
                else proposition_text.strip()
 
            )
 
            return (
 
                True,
 
                final_text,
 
                validation.reason
 
            )
 
        if (
 
            validation.is_supported
 
            and corrected_text
 
        ):
 
            return (
 
                True,
 
                corrected_text,
 
                validation.reason
 
            )
 
        return (
 
            False,
 
            "",
 
            validation.reason
 
        )
 
    except Exception as error:
 
        return (
 
            False,
 
            "",
 
            f"Validation error: {error}"
 
        )
 
 
# ---------------------------------------------------------
 
# 14. Generate Proposition Chunks
 
# ---------------------------------------------------------
 
proposition_docs = []
 
seen_propositions = set()
 
generation_failures = 0
 
validation_rejections = 0
 
duplicate_rejections = 0
 
print("\n")
 
print("=" * 80)
 
print("PROPOSITION GENERATION")
 
print("=" * 80)
 
for parent_index, parent_doc in enumerate(
 
    parent_docs,
 
    start=1
 
):
 
    source_content = (
 
        parent_doc.page_content
 
    )
 
    try:
 
        generated_collection = (
 
            generation_chain.invoke(
 
                {
 
                    "movie_content": source_content
 
                }
 
            )
 
        )
 
    except Exception as error:
 
        generation_failures += 1
 
        print("\n")
 
        print("-" * 80)
 
        print(
 
            f"Proposition generation failed for "
 
            f"Parent Section {parent_index}"
 
        )
 
        print(
 
            f"Reason: {error}"
 
        )
 
        continue
 
    movie_name = (
 
        generated_collection.movie_name.strip()
 
        or "Unknown"
 
    )
 
    print("\n")
 
    print("-" * 80)
 
    print(
 
        f"Parent Section : {parent_index}"
 
    )
 
    print(
 
        f"Movie Name     : {movie_name}"
 
    )
 
    print(
 
        f"Raw Propositions Generated : "
 
        f"{len(generated_collection.propositions)}"
 
    )
 
    accepted_for_parent = 0
 
    for proposition_index, item in enumerate(
 
        generated_collection.propositions,
 
        start=1
 
    ):
 
        raw_proposition = (
 
            item.proposition.strip()
 
        )
 
        if not raw_proposition:
 
            validation_rejections += 1
 
            continue
 
        (
 
            accepted,
 
            final_proposition,
 
            validation_reason
 
        ) = validate_proposition(
 
            source_content=source_content,
 
            proposition_text=raw_proposition
 
        )
 
        if not accepted:
 
            validation_rejections += 1
 
            print("\n")
 
            print(
 
                f"Rejected Proposition "
 
                f"{proposition_index}:"
 
            )
 
            print(
 
                raw_proposition
 
            )
 
            print(
 
                f"Reason: {validation_reason}"
 
            )
 
            continue
 
        normalized_proposition = (
 
            normalize_for_comparison(
 
                final_proposition
 
            )
 
        )
 
        if not normalized_proposition:
 
            validation_rejections += 1
 
            continue
 
        duplicate_key = (
 
            parent_index,
 
            normalized_proposition
 
        )
 
        if duplicate_key in seen_propositions:
 
            duplicate_rejections += 1
 
            continue
 
        seen_propositions.add(
 
            duplicate_key
 
        )
 
        accepted_for_parent += 1
 
        proposition_id = create_proposition_id(
 
            parent_section_number=parent_index,
 
            proposition_number=accepted_for_parent,
 
            proposition_text=final_proposition
 
        )
 
        short_description = (
 
            item.short_description.strip()
 
        )
 
        if not short_description:
 
            short_description = (
 
                final_proposition
 
            )
 
        if STORE_PARENT_CONTENT_IN_EMBEDDED_TEXT:
 
            embedded_content = f"""
 
Proposition:
 
{final_proposition}
 
Concept:
 
{item.concept}
 
Short Description:
 
{short_description}
 
Movie:
 
{movie_name}
 
Supporting Movie Content:
 
{source_content}
 
""".strip()
 
        else:
 
            embedded_content = f"""
 
Proposition:
 
{final_proposition}
 
Concept:
 
{item.concept}
 
Short Description:
 
{short_description}
 
Movie:
 
{movie_name}
 
""".strip()
 
        proposition_doc = Document(
 
            page_content=embedded_content,
 
            metadata={
 
                "proposition_id": proposition_id,
 
                "proposition_text": final_proposition,
 
                "proposition_number": accepted_for_parent,
 
                "parent_section_number": parent_index,
 
                "movie_name": movie_name,
 
                "concept": item.concept,
 
                "short_description": short_description,
 
                "source": str(FILE_PATH),
 
                "chunking_strategy": (
 
                    "proposition_chunking"
 
                ),
 
                "validation_status": (
 
                    "accepted"
 
                ),
 
                "validation_reason": (
 
                    validation_reason
 
                ),
 
                "parent_content": (
 
                    source_content
 
                )
 
            }
 
        )
 
        proposition_docs.append(
 
            proposition_doc
 
        )
 
        print("\n")
 
        print(
 
            f"Accepted Proposition "
 
            f"{accepted_for_parent}:"
 
        )
 
        print(
 
            final_proposition
 
        )
 
        print(
 
            f"Concept: {item.concept}"
 
        )
 
        print(
 
            f"Description: "
 
            f"{short_description}"
 
        )
 
    print(
 
        f"\nAccepted For Parent Section "
 
        f"{parent_index}: {accepted_for_parent}"
 
    )
 
 
# ---------------------------------------------------------
 
# 15. Validate Proposition Generation Result
 
# ---------------------------------------------------------
 
if not proposition_docs:
 
    raise ValueError(
 
        "No valid propositions were generated. "
 
        "Check the source content and LLM output."
 
    )
 
 
# ---------------------------------------------------------
 
# 16. Proposition Summary
 
# ---------------------------------------------------------
 
movie_information_count = sum(
 
    1
 
    for doc in proposition_docs
 
    if doc.metadata.get("concept")
 
    == "movie_information"
 
)
 
multiple_roles_count = sum(
 
    1
 
    for doc in proposition_docs
 
    if doc.metadata.get("concept")
 
    == "multiple_roles"
 
)
 
fake_identity_count = sum(
 
    1
 
    for doc in proposition_docs
 
    if doc.metadata.get("concept")
 
    == "fake_identity"
 
)
 
both_count = sum(
 
    1
 
    for doc in proposition_docs
 
    if doc.metadata.get("concept")
 
    == "both"
 
)
 
print("\n")
 
print("=" * 80)
 
print("PROPOSITION CHUNKING SUMMARY")
 
print("=" * 80)
 
print(
 
    f"Parent Sections             : "
 
    f"{len(parent_docs)}"
 
)
 
print(
 
    f"Accepted Propositions       : "
 
    f"{len(proposition_docs)}"
 
)
 
print(
 
    f"Movie Information           : "
 
    f"{movie_information_count}"
 
)
 
print(
 
    f"Multiple Roles              : "
 
    f"{multiple_roles_count}"
 
)
 
print(
 
    f"Fake Identity               : "
 
    f"{fake_identity_count}"
 
)
 
print(
 
    f"Both Concepts               : "
 
    f"{both_count}"
 
)
 
print(
 
    f"Generation Failures         : "
 
    f"{generation_failures}"
 
)
 
print(
 
    f"Validation Rejections       : "
 
    f"{validation_rejections}"
 
)
 
print(
 
    f"Duplicate Rejections        : "
 
    f"{duplicate_rejections}"
 
)
 
 
# ---------------------------------------------------------
 
# 17. Display Proposition Samples
 
# ---------------------------------------------------------
 
print("\n")
 
print("=" * 80)
 
print("PROPOSITION CHUNK SAMPLES")
 
print("=" * 80)
 
for index, doc in enumerate(
 
    proposition_docs[:10],
 
    start=1
 
):
 
    print("\n")
 
    print("-" * 80)
 
    print(
 
        f"Proposition Chunk {index}"
 
    )
 
    print("-" * 80)
 
    print(
 
        f"Movie       : "
 
        f"{doc.metadata.get('movie_name')}"
 
    )
 
    print(
 
        f"Concept     : "
 
        f"{doc.metadata.get('concept')}"
 
    )
 
    print(
 
        f"Proposition : "
 
        f"{doc.metadata.get('proposition_text')}"
 
    )
 
    print(
 
        f"Description : "
 
        f"{doc.metadata.get('short_description')}"
 
    )
 
    print(
 
        f"Parent      : "
 
        f"{doc.metadata.get('parent_section_number')}"
 
    )
 
 
# ---------------------------------------------------------
 
# 18. Create Embeddings
 
# ---------------------------------------------------------
 
embeddings = OpenAIEmbeddings(
 
    model=EMBEDDING_MODEL
 
)
 
 
# ---------------------------------------------------------
 
# 19. Connect To LanceDB
 
# ---------------------------------------------------------
 
db = lancedb.connect(
 
    LANCEDB_FOLDER
 
)
 
 
# ---------------------------------------------------------
 
# 20. Store Proposition Chunks In LanceDB
 
# ---------------------------------------------------------
 
# Every proposition is stored as a separate LanceDB row.
 
#
 
# The proposition text, concept, short description, movie name,
 
# and optional supporting parent content are embedded together.
 
#
 
# The original parent content is also retained in metadata.
 
vector_store = LanceDB.from_documents(
 
    documents=proposition_docs,
 
    embedding=embeddings,
 
    connection=db,
 
    table_name=LANCEDB_TABLE,
 
    mode="overwrite"
 
)
 
 
# ---------------------------------------------------------
 
# 21. LanceDB Verification
 
# ---------------------------------------------------------
 
table = db.open_table(
 
    LANCEDB_TABLE
 
)
 
stored_row_count = (
 
    table.count_rows()
 
)
 
print("\n")
 
print("=" * 80)
 
print("LANCEDB VERIFICATION")
 
print("=" * 80)
 
print(
 
    f"Proposition Documents : "
 
    f"{len(proposition_docs)}"
 
)
 
print(
 
    f"LanceDB Rows          : "
 
    f"{stored_row_count}"
 
)
 
if stored_row_count == len(
 
    proposition_docs
 
):
 
    print(
 
        "Verification Successful: every proposition "
 
        "was stored as a separate LanceDB row."
 
    )
 
else:
 
    print(
 
        "Warning: LanceDB row count does not match "
 
        "the proposition document count."
 
    )
 
 
# ---------------------------------------------------------
 
# 22. Display Stored LanceDB Records
 
# ---------------------------------------------------------
 
print("\n")
 
print("=" * 80)
 
print("LANCEDB STORED PROPOSITION SAMPLE")
 
print("=" * 80)
 
""" stored_records = (
 
    table
 
    .to_pandas()
 
    .head(10)
 
)
 """
""" display_columns = [
 
    column
 
    for column in [
 
        "proposition_id",
 
        "movie_name",
 
        "concept",
 
        "proposition_text",
 
        "short_description",
 
        "parent_section_number",
 
        "text"
 
    ]
 
    if column in stored_records.columns
 
]
 
if display_columns:
 
    print(
 
        stored_records[
 
            display_columns
 
        ].to_string(
 
            index=False
 
        )
 
    )
 
else:
 
    print(
 
        stored_records.to_string(
 
            index=False
 
        )
 
    )
 
 
 """# ---------------------------------------------------------
 
# 23. Create Proposition Retriever
 
# ---------------------------------------------------------
 
retriever = vector_store.as_retriever(
 
    search_type="similarity",
 
    search_kwargs={
 
        "k": TOP_K
 
    }
 
)
 
 
# ---------------------------------------------------------
 
# 24. Create Answer Generation LLM
 
# ---------------------------------------------------------
 
answer_llm = ChatOpenAI(
 
    model=CHAT_MODEL,
 
    temperature=0
 
)
 
 
# ---------------------------------------------------------
 
# 25. Create Proposition RAG Prompt
 
# ---------------------------------------------------------
 
answer_system_prompt = """
 
You answer questions about Rajinikanth movies using retrieved
 
proposition chunks.
 
Each retrieved record may include:
 
1. One atomic proposition.
 
2. A concept classification.
 
3. A short description.
 
4. A movie name.
 
5. Supporting parent movie content.
 
Instructions:
 
1. Use only the retrieved context.
 
2. Do not use outside movie knowledge.
 
3. Do not invent movie names, characters, roles, disguises,
 
   identities, aliases, or plot details.
 
4. Treat the proposition as the primary retrieval fact.
 
5. Use supporting movie content only to clarify the proposition.
 
6. Clearly distinguish multiple roles from fake identities.
 
7. Multiple roles means genuinely distinct characters or roles.
 
8. Fake identity means one character uses a disguise, alias,
 
   impersonation, or assumed identity.
 
9. A movie categorized as both contains both concepts.
 
10. Remove duplicate facts from the final response.
 
11. Group related propositions by movie.
 
12. Provide a short explanation for each matching movie.
 
13. If the retrieved context does not contain the answer, say:
 
    I don't know based on the available movie data.
 
Retrieved Proposition Context:
 
{context}
 
"""
 
answer_prompt = (
 
    ChatPromptTemplate.from_messages(
 
        [
 
            (
 
                "system",
 
                answer_system_prompt
 
            ),
 
            (
 
                "human",
 
                "{question}"
 
            )
 
        ]
 
    )
 
)
 
 
# ---------------------------------------------------------
 
# 26. Build Retrieved Context
 
# ---------------------------------------------------------
 
def build_retrieved_context(
 
    retrieved_docs: List[Document]
 
) -> str:
 
    context_items = []
 
    seen_ids = set()
 
    for doc in retrieved_docs:
 
        proposition_id = (
 
            doc.metadata.get(
 
                "proposition_id",
 
                ""
 
            )
 
        )
 
        if (
 
            proposition_id
 
            and proposition_id in seen_ids
 
        ):
 
            continue
 
        if proposition_id:
 
            seen_ids.add(
 
                proposition_id
 
            )
 
        context_item = f"""
 
Movie:
 
{doc.metadata.get("movie_name", "Unknown")}
 
Concept:
 
{doc.metadata.get("concept", "movie_information")}
 
Proposition:
 
{doc.metadata.get("proposition_text", doc.page_content)}
 
Short Description:
 
{doc.metadata.get("short_description", "")}
 
Supporting Parent Content:
 
{doc.metadata.get("parent_content", "")}
 
""".strip()
 
        context_items.append(
 
            context_item
 
        )
 
    return "\n\n".join(
 
        context_items
 
    )
 
 
# ---------------------------------------------------------
 
# 27. Ask Question
 
# ---------------------------------------------------------
 
def ask_question(
 
    question: str
 
) -> str:
 
    retrieved_docs = retriever.invoke(
 
        question
 
    )
 
    print("\n")
 
    print("=" * 80)
 
    print("RETRIEVED PROPOSITION CHUNKS")
 
    print("=" * 80)
 
    if not retrieved_docs:
 
        print(
 
            "No propositions were retrieved."
 
        )
 
        return (
 
            "I don't know based on the "
 
            "available movie data."
 
        )
 
    for index, doc in enumerate(
 
        retrieved_docs,
 
        start=1
 
    ):
 
        print("\n")
 
        print("-" * 80)
 
        print(
 
            f"Retrieved Proposition {index}"
 
        )
 
        print("-" * 80)
 
        print(
 
            f"Movie       : "
 
            f"{doc.metadata.get('movie_name')}"
 
        )
 
        print(
 
            f"Concept     : "
 
            f"{doc.metadata.get('concept')}"
 
        )
 
        print(
 
            f"Proposition : "
 
            f"{doc.metadata.get('proposition_text')}"
 
        )
 
        print(
 
            f"Description : "
 
            f"{doc.metadata.get('short_description')}"
 
        )
 
        print(
 
            f"Parent      : "
 
            f"{doc.metadata.get('parent_section_number')}"
 
        )
 
    context = build_retrieved_context(
 
        retrieved_docs
 
    )
 
    prompt_value = answer_prompt.invoke(
 
        {
 
            "question": question,
 
            "context": context
 
        }
 
    )
 
    response = answer_llm.invoke(
 
        prompt_value
 
    )
 
    return response.content
 
 
# ---------------------------------------------------------
 
# 28. Retrieval Tests
 
# ---------------------------------------------------------
 
test_questions = [
 
    (
 
        "Movies where Rajini played "
 
        "multiple characters?"
 
    ),
 
    (
 
        "Movies where Rajini played "
 
        "one role but faked other "
 
        "identities?"
 
    )
 
]
 
for question in test_questions:
 
    print("\n")
 
    print("=" * 80)
 
    print("QUESTION")
 
    print("=" * 80)
 
    print(question)
 
    answer = ask_question(
 
        question
 
    )
 
    print("\n")
 
    print("=" * 80)
 
    print("ANSWER")
 
    print("=" * 80)
 
    print(answer)
 
 
# ---------------------------------------------------------
 
# 29. Interactive Mode
 
# ---------------------------------------------------------
 
print("\n")
 
print("=" * 80)
 
print("PROPOSITION CHUNKING INTERACTIVE MODE")
 
print("=" * 80)
 
print(
 
    "Each LanceDB row represents one validated, "
 
    "self-contained proposition."
 
)
 
while True:
 
    question = input(
 
        "\nAsk Question (exit to quit): "
 
    ).strip()
 
    if question.lower() == "exit":
 
        break
 
    if not question:
 
        continue
 
    answer = ask_question(
 
        question
 
    )
 
    print("\nAnswer:\n")
 
    print(answer)
 
 
print("\nProgram Finished")
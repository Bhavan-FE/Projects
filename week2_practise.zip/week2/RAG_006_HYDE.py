from pathlib import Path
 
from typing import List, Tuple
 
import hashlib
 
import os
 
import re
 
from dotenv import load_dotenv
 
import lancedb
 
from langchain_community.document_loaders import TextLoader
 
from langchain_community.vectorstores import LanceDB
 
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
 
from langchain_core.documents import Document
 
from langchain_core.prompts import ChatPromptTemplate
 
 
# ---------------------------------------------------------
 
# 1. Load Environment Variables
 
# ---------------------------------------------------------
 
load_dotenv()
 
if not os.getenv("OPENAI_API_KEY"):
 
    raise EnvironmentError(
 
        "OPENAI_API_KEY not found in .env file"
 
    )
 
 
# ---------------------------------------------------------
 
# 2. Configuration
 
# ---------------------------------------------------------
 
FILE_PATH = Path("Movies.txt")
 
CHAT_MODEL = "gpt-4o-mini"
 
EMBEDDING_MODEL = "text-embedding-3-small"
 
TOP_K = 5
 
LANCEDB_FOLDER = "./movies_hyde_lancedb"
 
LANCEDB_TABLE = "movies_empty_line_chunks"
 
# Set to True to display direct-query retrieval beside HyDE retrieval.
 
RUN_BASELINE_COMPARISON = True
 
# Set to True to run the sample questions before interactive mode.
 
RUN_TEST_QUESTIONS = True
 
 
# ---------------------------------------------------------
 
# 3. Validate Input File
 
# ---------------------------------------------------------
 
if not FILE_PATH.exists():
 
    raise FileNotFoundError(
 
        f"Movies file not found: {FILE_PATH.resolve()}"
 
    )
 
 
# ---------------------------------------------------------
 
# 4. Load Movie File
 
# ---------------------------------------------------------
 
loader = TextLoader(
 
    file_path=str(FILE_PATH),
 
    encoding="utf-8"
 
)
 
documents = loader.load()
 
if not documents:
 
    raise ValueError(
 
        "Movies.txt was loaded, but no document was returned."
 
    )
 
raw_content = documents[0].page_content
 
if not raw_content.strip():
 
    raise ValueError("Movies.txt is empty.")
 
print("\n")
 
print("=" * 80)
 
print("DOCUMENT LOAD VERIFICATION")
 
print("=" * 80)
 
print(f"Documents Loaded  : {len(documents)}")
 
print(f"Characters Loaded : {len(raw_content)}")
 
print("\nPreview\n")
 
print(raw_content[:1000])
 
 
# ---------------------------------------------------------
 
# 5. Normalize Line Endings
 
# ---------------------------------------------------------
 
normalized_content = (
 
    raw_content
 
    .replace("\r\n", "\n")
 
    .replace("\r", "\n")
 
)
 
 
# ---------------------------------------------------------
 
# 6. Split Only On Empty-Line Separators
 
# ---------------------------------------------------------
 
# No chunk size.
 
# No chunk overlap.
 
# No recursive splitter.
 
# No proposition chunking.
 
# No LLM enrichment during ingestion.
 
#
 
# One or more empty lines separate the sections.
 
sections = [
 
    section.strip()
 
    for section in re.split(r"\n\s*\n", normalized_content)
 
    if section.strip()
 
]
 
if not sections:
 
    raise ValueError(
 
        "No non-empty movie sections were found."
 
    )
 
 
def create_section_id(
 
    section_number: int,
 
    section_content: str
 
) -> str:
 
    value = f"{section_number}|{section_content}"
 
    return hashlib.sha256(
 
        value.encode("utf-8")
 
    ).hexdigest()[:16]
 
 
raw_docs = []
 
for section_number, section in enumerate(
 
    sections,
 
    start=1
 
):
 
    raw_docs.append(
 
        Document(
 
            page_content=section,
 
            metadata={
 
                "section_id": create_section_id(
 
                    section_number,
 
                    section
 
                ),
 
                "section_number": section_number,
 
                "source": str(FILE_PATH),
 
                "chunking_strategy": "empty_line_separator",
 
                "content_enrichment": "none"
 
            }
 
        )
 
    )
 
print("\n")
 
print("=" * 80)
 
print("EMPTY-LINE CHUNK VERIFICATION")
 
print("=" * 80)
 
print(f"Sections Created : {len(raw_docs)}")
 
for index, doc in enumerate(raw_docs[:5], start=1):
 
    print("\n")
 
    print("-" * 80)
 
    print(f"Section {index}")
 
    print("-" * 80)
 
    print(doc.page_content[:500])
 
    print("\nMetadata")
 
    print(doc.metadata)
 
 
# ---------------------------------------------------------
 
# 7. Create Embeddings
 
# ---------------------------------------------------------
 
embeddings = OpenAIEmbeddings(
 
    model=EMBEDDING_MODEL
 
)
 
 
# ---------------------------------------------------------
 
# 8. Connect To LanceDB
 
# ---------------------------------------------------------
 
db = lancedb.connect(
 
    LANCEDB_FOLDER
 
)
 
 
# ---------------------------------------------------------
 
# 9. Store Only Raw Empty-Line Sections
 
# ---------------------------------------------------------
 
# The vector database contains only source text.
 
# The hypothetical document is never stored in LanceDB.
 
vector_store = LanceDB.from_documents(
 
    documents=raw_docs,
 
    embedding=embeddings,
 
    connection=db,
 
    table_name=LANCEDB_TABLE,
 
    mode="overwrite"
 
)
 
 
# ---------------------------------------------------------
 
# 10. LanceDB Verification
 
# ---------------------------------------------------------
 
table = db.open_table(
 
    LANCEDB_TABLE
 
)
 
stored_row_count = table.count_rows()
 
print("\n")
 
print("=" * 80)
 
print("LANCEDB VERIFICATION")
 
print("=" * 80)
 
print(f"Raw Sections  : {len(raw_docs)}")
 
print(f"LanceDB Rows  : {stored_row_count}")
 
if stored_row_count == len(raw_docs):
 
    print(
 
        "Verification successful. Every raw section was stored."
 
    )
 
else:
 
    print(
 
        "Warning: LanceDB row count does not match section count."
 
    )
 
 
# ---------------------------------------------------------
 
# 11. Create LLMs
 
# ---------------------------------------------------------
 
# hyde_llm generates only the hypothetical retrieval document.
 
# answer_llm generates the final answer using real retrieved sections.
 
hyde_llm = ChatOpenAI(
 
    model=CHAT_MODEL,
 
    temperature=0
 
)
 
answer_llm = ChatOpenAI(
 
    model=CHAT_MODEL,
 
    temperature=0
 
)
 
 
# ---------------------------------------------------------
 
# 12. HyDE Prompt
 
# ---------------------------------------------------------
 
# The hypothetical passage is used only as a retrieval representation.
 
# It is not treated as a factual answer and is not stored.
 
hyde_system_prompt = """
 
You generate a hypothetical document for retrieval from a
 
Rajinikanth movie knowledge base.
 
The hypothetical document should resemble the type of passage that
 
could answer the user's question and should use retrieval-friendly
 
language.
 
Instructions:
 
1. Preserve the user's information need.
 
2. Write one concise hypothetical passage.
 
3. Include useful terminology related to the question.
 
4. For multiple roles, useful terms may include distinct characters,
 
   dual roles, triple roles, several roles, or multiple characters.
 
5. For fake identity, useful terms may include assumed identity,
 
   disguise, alias, impersonation, false identity, or pretending to
 
   be another person.
 
6. Do not mention specific movie names unless they are present in the
 
   user's question.
 
7. Do not claim that the hypothetical passage is verified.
 
8. Do not provide citations.
 
9. Return only the hypothetical passage.
 
The generated passage will be embedded and used only to retrieve real
 
source sections. The final answer will be based only on those real
 
retrieved sections.
 
"""
 
hyde_prompt = ChatPromptTemplate.from_messages(
 
    [
 
        ("system", hyde_system_prompt),
 
        ("human", "User Question:\n\n{question}")
 
    ]
 
)
 
 
# ---------------------------------------------------------
 
# 13. Final Grounded Answer Prompt
 
# ---------------------------------------------------------
 
answer_system_prompt = """
 
You answer questions about Rajinikanth movies using only the retrieved
 
raw movie sections.
 
HyDE was used only to retrieve the sections. The hypothetical document
 
is not a source of truth and is not included in the context below.
 
Instructions:
 
1. Use only the retrieved raw movie content.
 
2. Do not use outside movie knowledge.
 
3. Do not invent movie names, character names, roles, identities,
 
   aliases, disguises, impersonations, or plot details.
 
4. Multiple roles means genuinely distinct characters or roles played
 
   by the actor.
 
5. Fake identity means one actual character uses a disguise, alias,
 
   impersonation, or assumed identity.
 
6. A movie contains both concepts only when the retrieved source
 
   explicitly supports both.
 
7. Include only movies that answer the user's question.
 
8. Group matching information by movie when possible.
 
9. Give a short description using only retrieved facts.
 
10. Remove duplicates and keep the answer concise.
 
11. If the retrieved content does not contain the answer, say:
 
    I don't know based on the available movie data.
 
Retrieved Raw Movie Sections:
 
{context}
 
"""
 
answer_prompt = ChatPromptTemplate.from_messages(
 
    [
 
        ("system", answer_system_prompt),
 
        ("human", "{question}")
 
    ]
 
)
 
 
# ---------------------------------------------------------
 
# 14. Generate Hypothetical Document
 
# ---------------------------------------------------------
 
def generate_hypothetical_document(
 
    question: str
 
) -> str:
 
    prompt_value = hyde_prompt.invoke(
 
        {"question": question}
 
    )
 
    response = hyde_llm.invoke(
 
        prompt_value
 
    )
 
    hypothetical_document = response.content.strip()
 
    if not hypothetical_document:
 
        raise ValueError(
 
            "HyDE did not generate a hypothetical document."
 
        )
 
    return hypothetical_document
 
 
# ---------------------------------------------------------
 
# 15. Retrieve Using HyDE Vector
 
# ---------------------------------------------------------
 
def retrieve_with_hyde(
 
    question: str
 
) -> Tuple[str, List[Document]]:
 
    hypothetical_document = generate_hypothetical_document(
 
        question
 
    )
 
    # Embed the generated hypothetical passage, not the raw question.
 
    hypothetical_vector = embeddings.embed_query(
 
        hypothetical_document
 
    )
 
    retrieved_docs = vector_store.similarity_search_by_vector(
 
        embedding=hypothetical_vector,
 
        k=TOP_K
 
    )
 
    return hypothetical_document, retrieved_docs
 
 
# ---------------------------------------------------------
 
# 16. Optional Direct-Query Baseline Retrieval
 
# ---------------------------------------------------------
 
def retrieve_baseline(
 
    question: str
 
) -> List[Document]:
 
    return vector_store.similarity_search(
 
        query=question,
 
        k=TOP_K
 
    )
 
 
# ---------------------------------------------------------
 
# 17. Stable Key For Comparison
 
# ---------------------------------------------------------
 
def get_document_key(
 
    doc: Document
 
) -> str:
 
    section_id = doc.metadata.get(
 
        "section_id"
 
    )
 
    if section_id:
 
        return str(section_id)
 
    return hashlib.sha256(
 
        doc.page_content.encode("utf-8")
 
    ).hexdigest()[:16]
 
 
# ---------------------------------------------------------
 
# 18. Print Retrieval Results
 
# ---------------------------------------------------------
 
def print_documents(
 
    title: str,
 
    retrieved_docs: List[Document]
 
) -> None:
 
    print("\n")
 
    print("=" * 80)
 
    print(title)
 
    print("=" * 80)
 
    if not retrieved_docs:
 
        print("No documents were retrieved.")
 
        return
 
    for rank, doc in enumerate(
 
        retrieved_docs,
 
        start=1
 
    ):
 
        print("\n")
 
        print("-" * 80)
 
        print(f"Rank           : {rank}")
 
        print(
 
            f"Section Number : "
 
            f"{doc.metadata.get('section_number')}"
 
        )
 
        print(
 
            f"Section ID     : "
 
            f"{doc.metadata.get('section_id')}"
 
        )
 
        print("-" * 80)
 
        print(doc.page_content[:1000])
 
 
# ---------------------------------------------------------
 
# 19. Compare Baseline And HyDE Retrieval
 
# ---------------------------------------------------------
 
def compare_retrieval(
 
    baseline_docs: List[Document],
 
    hyde_docs: List[Document]
 
) -> None:
 
    baseline_keys = [
 
        get_document_key(doc)
 
        for doc in baseline_docs
 
    ]
 
    hyde_keys = [
 
        get_document_key(doc)
 
        for doc in hyde_docs
 
    ]
 
    baseline_set = set(baseline_keys)
 
    hyde_set = set(hyde_keys)
 
    common_keys = baseline_set.intersection(
 
        hyde_set
 
    )
 
    hyde_only_keys = [
 
        key
 
        for key in hyde_keys
 
        if key not in baseline_set
 
    ]
 
    baseline_only_keys = [
 
        key
 
        for key in baseline_keys
 
        if key not in hyde_set
 
    ]
 
    print("\n")
 
    print("=" * 80)
 
    print("BASELINE VERSUS HYDE COMPARISON")
 
    print("=" * 80)
 
    print(f"Baseline Retrieved : {len(baseline_docs)}")
 
    print(f"HyDE Retrieved     : {len(hyde_docs)}")
 
    print(f"Common Results     : {len(common_keys)}")
 
    print(f"HyDE-Only Results  : {len(hyde_only_keys)}")
 
    print(f"Baseline-Only      : {len(baseline_only_keys)}")
 
    print(f"\nBaseline IDs       : {baseline_keys}")
 
    print(f"HyDE IDs           : {hyde_keys}")
 
    print(f"HyDE-Only IDs      : {hyde_only_keys}")
 
    print(f"Baseline-Only IDs  : {baseline_only_keys}")
 
 
# ---------------------------------------------------------
 
# 20. Build Grounded Context
 
# ---------------------------------------------------------
 
def build_context(
 
    retrieved_docs: List[Document]
 
) -> str:
 
    context_items = []
 
    seen_ids = set()
 
    for doc in retrieved_docs:
 
        section_id = str(
 
            doc.metadata.get("section_id", "")
 
        )
 
        if section_id and section_id in seen_ids:
 
            continue
 
        if section_id:
 
            seen_ids.add(section_id)
 
        context_items.append(
 
            f"""
 
Section Number:
 
{doc.metadata.get('section_number')}
 
Section ID:
 
{doc.metadata.get('section_id')}
 
Raw Movie Content:
 
{doc.page_content}
 
""".strip()
 
        )
 
    return "\n\n".join(context_items)
 
 
# ---------------------------------------------------------
 
# 21. Generate Final Answer From Real Retrieved Content
 
# ---------------------------------------------------------
 
def generate_grounded_answer(
 
    question: str,
 
    retrieved_docs: List[Document]
 
) -> str:
 
    if not retrieved_docs:
 
        return (
 
            "I don't know based on the available movie data."
 
        )
 
    prompt_value = answer_prompt.invoke(
 
        {
 
            "question": question,
 
            "context": build_context(retrieved_docs)
 
        }
 
    )
 
    response = answer_llm.invoke(
 
        prompt_value
 
    )
 
    return response.content
 
 
# ---------------------------------------------------------
 
# 22. Complete HyDE RAG Function
 
# ---------------------------------------------------------
 
def ask_question(
 
    question: str
 
) -> str:
 
    baseline_docs = []
 
    if RUN_BASELINE_COMPARISON:
 
        baseline_docs = retrieve_baseline(
 
            question
 
        )
 
        print_documents(
 
            "BASELINE DIRECT-QUERY RETRIEVAL",
 
            baseline_docs
 
        )
 
    hypothetical_document, hyde_docs = retrieve_with_hyde(
 
        question
 
    )
 
    print("\n")
 
    print("=" * 80)
 
    print("HYDE HYPOTHETICAL DOCUMENT")
 
    print("=" * 80)
 
    print(hypothetical_document)
 
    print_documents(
 
        "HYDE RETRIEVAL RESULTS",
 
        hyde_docs
 
    )
 
    if RUN_BASELINE_COMPARISON:
 
        compare_retrieval(
 
            baseline_docs=baseline_docs,
 
            hyde_docs=hyde_docs
 
        )
 
    return generate_grounded_answer(
 
        question=question,
 
        retrieved_docs=hyde_docs
 
    )
 
 
# ---------------------------------------------------------
 
# 23. Test Questions
 
# ---------------------------------------------------------
 
test_questions = [
 
    "Which movies show Rajini playing multiple distinct roles?",
 
    (
 
        "Which movies show Rajini using a fake identity, disguise, "
 
        "alias, or impersonation?"
 
    ),
 
    "Which movies contain both multiple roles and fake identities?",
 
    (
 
        "Movies where Rajini played one role but pretended to be "
 
        "another person?"
 
    )
 
]
 
 
# ---------------------------------------------------------
 
# 24. Run Test Questions
 
# ---------------------------------------------------------
 
if RUN_TEST_QUESTIONS:
 
    for question in test_questions:
 
        print("\n")
 
        print("#" * 80)
 
        print("TEST QUESTION")
 
        print("#" * 80)
 
        print(question)
 
        try:
 
            answer = ask_question(
 
                question
 
            )
 
            print("\n")
 
            print("=" * 80)
 
            print("FINAL GROUNDED ANSWER")
 
            print("=" * 80)
 
            print(answer)
 
        except Exception as error:
 
            print("\n")
 
            print("=" * 80)
 
            print("QUESTION PROCESSING ERROR")
 
            print("=" * 80)
 
            print(f"Question: {question}")
 
            print(f"Reason: {error}")
 
 
# ---------------------------------------------------------
 
# 25. Interactive Mode
 
# ---------------------------------------------------------
 
print("\n")
 
print("=" * 80)
 
print("EMPTY-LINE CHUNKING WITH HYDE RAG")
 
print("=" * 80)
 
print(
 
    "LanceDB contains only raw empty-line-separated sections."
 
)
 
print(
 
    "The hypothetical document is generated only at query time."
 
)
 
print(
 
    "The hypothetical document is embedded for retrieval but is "
 
    "never stored in LanceDB or used as answer evidence."
 
)
 
print(
 
    f"Baseline Comparison : {RUN_BASELINE_COMPARISON}"
 
)
 
while True:
 
    question = input(
 
        "\nAsk Question (exit to quit): "
 
    ).strip()
 
    if question.lower() == "exit":
 
        break
 
    if not question:
 
        continue
 
    try:
 
        answer = ask_question(
 
            question
 
        )
 
        print("\n")
 
        print("=" * 80)
 
        print("FINAL GROUNDED ANSWER")
 
        print("=" * 80)
 
        print(answer)
 
    except Exception as error:
 
        print("\n")
 
        print("=" * 80)
 
        print("ERROR")
 
        print("=" * 80)
 
        print("Unable to process the question.")
 
        print(f"Reason: {error}")
 
 
print("\n")
 
print("=" * 80)
 
print("PROGRAM FINISHED")
 
print("=" * 80)
 
from pathlib import Path
 
from typing import Literal
 
import os
 
from dotenv import load_dotenv
 
from pydantic import BaseModel, Field
 
import lancedb
 
from langchain_community.document_loaders import TextLoader
 
from langchain_community.vectorstores import LanceDB
 
from langchain_openai import (
 
    ChatOpenAI,
 
    OpenAIEmbeddings
 
)
 
from langchain_core.prompts import (
 
    ChatPromptTemplate
 
)
 
from langchain_core.documents import (
 
    Document
 
)
 
 
# ---------------------------------------------------------
 
# LLM Structured Output Model
 
# ---------------------------------------------------------
 
class MovieConceptAnalysis(BaseModel):
 
    category: Literal[
 
        "multiple_roles",
 
        "fake_identity",
 
        "both",
 
        "neither"
 
    ] = Field(
 
        description=(
 
            "Classify the movie as multiple_roles, "
 
            "fake_identity, both, or neither."
 
        )
 
    )
 
    has_multiple_roles: bool = Field(
 
        description=(
 
            "True only when the supplied content explicitly "
 
            "says that the actor played multiple distinct roles "
 
            "or characters."
 
        )
 
    )
 
    has_fake_identity: bool = Field(
 
        description=(
 
            "True only when the supplied content explicitly "
 
            "says that a character used a disguise, impersonation, "
 
            "alias, assumed identity, or fake identity."
 
        )
 
    )
 
    short_description: str = Field(
 
        description=(
 
            "A short description grounded only in the supplied "
 
            "movie content. Mention the relevant roles or fake "
 
            "identities when they are explicitly available."
 
        )
 
    )
 
 
# ---------------------------------------------------------
 
# 1. Load Environment Variables
 
# ---------------------------------------------------------
 
load_dotenv()
 
if not os.getenv("OPENAI_API_KEY"):
 
    raise EnvironmentError(
 
        "OPENAI_API_KEY not found in .env file"
 
    )
 
 
# ---------------------------------------------------------
 
# 2. Configuration
 
# ---------------------------------------------------------
 
FILE_PATH = Path("Movies.txt")
 
CHAT_MODEL = "gpt-4o-mini"
 
EMBEDDING_MODEL = (
 
    "text-embedding-3-small"
 
)
 
TOP_K = 5
 
LANCEDB_FOLDER = (
 
    "./movies_Context_chunking_lancedb"
 
)
 
LANCEDB_TABLE = "movies_context_chunking"
 
 
# ---------------------------------------------------------
 
# 3. Validate File
 
# ---------------------------------------------------------
 
if not FILE_PATH.exists():
 
    raise FileNotFoundError(
 
        f"Movies file not found : "
 
        f"{FILE_PATH.resolve()}"
 
    )
 
 
# ---------------------------------------------------------
 
# 4. Load Movie File
 
# ---------------------------------------------------------
 
loader = TextLoader(
 
    file_path=str(FILE_PATH),
 
    encoding="utf-8"
 
)
 
documents = loader.load()
 
if not documents:
 
    raise ValueError(
 
        "Movies.txt was loaded, but no content was found."
 
    )
 
raw_content = documents[0].page_content
 
if not raw_content.strip():
 
    raise ValueError(
 
        "Movies.txt is empty."
 
    )
 
print("\n")
 
print("=" * 80)
 
print("DOCUMENT LOAD VERIFICATION")
 
print("=" * 80)
 
print(
 
    f"Documents Loaded : "
 
    f"{len(documents)}"
 
)
 
print(
 
    f"Characters Loaded : "
 
    f"{len(raw_content)}"
 
)
 
print("\nPreview\n")
 
print(
 
    raw_content[:1000]
 
)
 
 
# ---------------------------------------------------------
 
# 5. Split Content Based On Empty Line Separators
 
# ---------------------------------------------------------
 
# Handles Windows line endings and Unix line endings uniformly.
 
normalized_content = raw_content.replace(
 
    "\r\n",
 
    "\n"
 
).replace(
 
    "\r",
 
    "\n"
 
)
 
sections = [
 
    section.strip()
 
    for section in normalized_content.split("\n\n")
 
    if section.strip()
 
]
 
if not sections:
 
    raise ValueError(
 
        "No non-empty movie sections were found."
 
    )
 
source_docs = [
 
    Document(
 
        page_content=section,
 
        metadata={
 
            "section_number": index,
 
            "source": str(FILE_PATH)
 
        }
 
    )
 
    for index, section in enumerate(
 
        sections,
 
        start=1
 
    )
 
]
 
print("\n")
 
print("=" * 80)
 
print("EMPTY-LINE SPLITTING VERIFICATION")
 
print("=" * 80)
 
print(
 
    f"Sections Created : "
 
    f"{len(source_docs)}"
 
)
 
for i in range(
 
    min(5, len(source_docs))
 
):
 
    print("\n")
 
    print("-" * 60)
 
    print(
 
        f"Section {i + 1}"
 
    )
 
    print("-" * 60)
 
    print(
 
        source_docs[i].page_content[:300]
 
    )
 
 
# ---------------------------------------------------------
 
# 6. Create LLM For Movie Concept Analysis
 
# ---------------------------------------------------------
 
analysis_llm = ChatOpenAI(
 
    model=CHAT_MODEL,
 
    temperature=0
 
)
 
structured_analysis_llm = (
 
    analysis_llm.with_structured_output(
 
        MovieConceptAnalysis
 
    )
 
)
 
 
# ---------------------------------------------------------
 
# 7. Create Movie Analysis Prompt
 
# ---------------------------------------------------------
 
analysis_system_prompt = """
 
You analyze movie information supplied by the user.
 
Your task is to identify whether the supplied content explicitly
 
describes any of the following concepts:
 
1. Multiple roles:
 
   The actor plays two or more genuinely distinct characters or roles.
 
2. Fake identity:
 
   A character remains one actual person but uses a disguise,
 
   impersonation, alias, assumed identity, or fake identity.
 
3. Both:
 
   The movie explicitly contains multiple distinct roles and also
 
   contains fake identities, disguises, aliases, or impersonations.
 
4. Neither:
 
   The supplied content does not explicitly establish either concept.
 
Important rules:
 
1. Use only the supplied movie content.
 
2. Do not use prior knowledge about the movie.
 
3. Do not invent character names, roles, identities, or plot details.
 
4. Multiple names do not automatically mean multiple roles.
 
5. A nickname alone does not automatically mean a fake identity.
 
6. If the source content is ambiguous, classify conservatively.
 
7. The Boolean values and category must agree:
 
   - multiple_roles means has_multiple_roles is true and
 
     has_fake_identity is false.
 
   - fake_identity means has_multiple_roles is false and
 
     has_fake_identity is true.
 
   - both means both Boolean values are true.
 
   - neither means both Boolean values are false.
 
8. Keep the short description concise.
 
9. When neither concept is supported, state that the supplied content
 
   does not clearly indicate multiple roles or a fake identity.
 
"""
 
analysis_prompt = (
 
    ChatPromptTemplate.from_messages(
 
        [
 
            (
 
                "system",
 
                analysis_system_prompt
 
            ),
 
            (
 
                "human",
 
                """
 
Analyze the following movie content:
 
{movie_content}
 
"""
 
            )
 
        ]
 
    )
 
)
 
analysis_chain = (
 
    analysis_prompt
 
    | structured_analysis_llm
 
)
 
 
# ---------------------------------------------------------
 
# 8. Helper Function To Normalize LLM Classification
 
# ---------------------------------------------------------
 
def normalize_analysis(
 
    analysis: MovieConceptAnalysis
 
) -> MovieConceptAnalysis:
 
    if (
 
        analysis.has_multiple_roles
 
        and analysis.has_fake_identity
 
    ):
 
        correct_category = "both"
 
    elif analysis.has_multiple_roles:
 
        correct_category = "multiple_roles"
 
    elif analysis.has_fake_identity:
 
        correct_category = "fake_identity"
 
    else:
 
        correct_category = "neither"
 
    if analysis.category != correct_category:
 
        analysis.category = correct_category
 
    analysis.short_description = (
 
        analysis.short_description.strip()
 
    )
 
    if not analysis.short_description:
 
        analysis.short_description = (
 
            "The supplied content does not provide "
 
            "a concept description."
 
        )
 
    return analysis
 
 
# ---------------------------------------------------------
 
# 9. Analyze And Enrich Every Movie Section
 
# ---------------------------------------------------------
 
docs = []
 
print("\n")
 
print("=" * 80)
 
print("LLM CONCEPT ANALYSIS")
 
print("=" * 80)
 
for index, source_doc in enumerate(
 
    source_docs,
 
    start=1
 
):
 
    try:
 
        analysis = analysis_chain.invoke(
 
            {
 
                "movie_content": (
 
                    source_doc.page_content
 
                )
 
            }
 
        )
 
        analysis = normalize_analysis(
 
            analysis
 
        )
 
    except Exception as error:
 
        print("\n")
 
        print(
 
            f"Analysis failed for Section {index}."
 
        )
 
        print(
 
            f"Reason: {error}"
 
        )
 
        analysis = MovieConceptAnalysis(
 
            category="neither",
 
            has_multiple_roles=False,
 
            has_fake_identity=False,
 
            short_description=(
 
                "Automated concept analysis was unavailable. "
 
                "Refer to the original movie content."
 
            )
 
        )
 
    enriched_content = f"""
 
Original Movie Content:
 
{source_doc.page_content}
 
LLM Concept Analysis:
 
Category: {analysis.category}
 
Multiple Roles: {analysis.has_multiple_roles}
 
Fake Identity: {analysis.has_fake_identity}
 
Short Description: {analysis.short_description}
 
""".strip()
 
    enriched_doc = Document(
 
        page_content=enriched_content,
 
        metadata={
 
            "section_number": index,
 
            "source": str(FILE_PATH),
 
            "analysis_category": (
 
                analysis.category
 
            ),
 
            "has_multiple_roles": (
 
                analysis.has_multiple_roles
 
            ),
 
            "has_fake_identity": (
 
                analysis.has_fake_identity
 
            ),
 
            "short_description": (
 
                analysis.short_description
 
            )
 
        }
 
    )
 
    docs.append(
 
        enriched_doc
 
    )
 
    print("\n")
 
    print("-" * 80)
 
    print(
 
        f"Section {index}"
 
    )
 
    print("-" * 80)
 
    print(
 
        f"Category           : "
 
        f"{analysis.category}"
 
    )
 
    print(
 
        f"Multiple Roles     : "
 
        f"{analysis.has_multiple_roles}"
 
    )
 
    print(
 
        f"Fake Identity      : "
 
        f"{analysis.has_fake_identity}"
 
    )
 
    print(
 
        f"Short Description  : "
 
        f"{analysis.short_description}"
 
    )
 
 
# ---------------------------------------------------------
 
# 10. Concept Analysis Summary
 
# ---------------------------------------------------------
 
multiple_roles_count = sum(
 
    1
 
    for doc in docs
 
    if doc.metadata.get(
 
        "analysis_category"
 
    ) == "multiple_roles"
 
)
 
fake_identity_count = sum(
 
    1
 
    for doc in docs
 
    if doc.metadata.get(
 
        "analysis_category"
 
    ) == "fake_identity"
 
)
 
both_count = sum(
 
    1
 
    for doc in docs
 
    if doc.metadata.get(
 
        "analysis_category"
 
    ) == "both"
 
)
 
neither_count = sum(
 
    1
 
    for doc in docs
 
    if doc.metadata.get(
 
        "analysis_category"
 
    ) == "neither"
 
)
 
print("\n")
 
print("=" * 80)
 
print("CONCEPT ANALYSIS SUMMARY")
 
print("=" * 80)
 
print(
 
    f"Multiple Roles Only : "
 
    f"{multiple_roles_count}"
 
)
 
print(
 
    f"Fake Identity Only  : "
 
    f"{fake_identity_count}"
 
)
 
print(
 
    f"Both Concepts       : "
 
    f"{both_count}"
 
)
 
print(
 
    f"Neither Concept     : "
 
    f"{neither_count}"
 
)
 
print(
 
    f"Total Sections      : "
 
    f"{len(docs)}"
 
)
 
 
# ---------------------------------------------------------
 
# 11. Display Enriched Document Samples
 
# ---------------------------------------------------------
 
print("\n")
 
print("=" * 80)
 
print("ENRICHED DOCUMENT VERIFICATION")
 
print("=" * 80)
 
for i in range(
 
    min(5, len(docs))
 
):
 
    print("\n")
 
    print("-" * 80)
 
    print(
 
        f"Enriched Section {i + 1}"
 
    )
 
    print("-" * 80)
 
    print(
 
        docs[i].page_content
 
    )
 
    print("\nMetadata:")
 
    print(
 
        docs[i].metadata
 
    )
 
 
# ---------------------------------------------------------
 
# 12. Create Embeddings
 
# ---------------------------------------------------------
 
embeddings = OpenAIEmbeddings(
 
    model=EMBEDDING_MODEL
 
)
 
 
# ---------------------------------------------------------
 
# 13. Connect To LanceDB
 
# ---------------------------------------------------------
 
db = lancedb.connect(
 
    LANCEDB_FOLDER
 
)
 
 
# ---------------------------------------------------------
 
# 14. Create Vector Store With Enriched Content
 
# ---------------------------------------------------------
 
# The embedded text contains:
 
# 1. Original movie content
 
# 2. LLM-generated category
 
# 3. Multiple-role indicator
 
# 4. Fake-identity indicator
 
# 5. LLM-generated short description
 
#
 
# mode="overwrite" recreates the table during each execution.
 
vector_store = LanceDB.from_documents(
 
    documents=docs,
 
    embedding=embeddings,
 
    connection=db,
 
    table_name=LANCEDB_TABLE,
 
    mode="overwrite"
 
)
 
 
# ---------------------------------------------------------
 
# 15. LanceDB Verification
 
# ---------------------------------------------------------
 
table = db.open_table(
 
    LANCEDB_TABLE
 
)
 
print("\n")
 
print("=" * 80)
 
print("LANCEDB VERIFICATION")
 
print("=" * 80)
 
print(
 
    f"Enriched Sections Stored : "
 
    f"{len(docs)}"
 
)
 
print(
 
    f"LanceDB Rows             : "
 
    f"{table.count_rows()}"
 
)
 
if table.count_rows() != len(docs):
 
    print(
 
        "Warning: LanceDB row count does not match "
 
        "the number of enriched sections."
 
    )
 
else:
 
    print(
 
        "Verification Successful: every enriched "
 
        "section was stored in LanceDB."
 
    )
 
 
# ---------------------------------------------------------
 
# 16. Display Stored LanceDB Records
 
# ---------------------------------------------------------
 
print("\n")
 
print("=" * 80)
 
print("LANCEDB STORED DATA SAMPLE")
 
print("=" * 80)
 
""" stored_records = (
 
    table
 
    .to_pandas()
 
    .head(5)
 
) """
 
""" display_columns = [
 
    column
 
    for column in [
 
        "text",
 
        "section_number",
 
        "analysis_category",
 
        "has_multiple_roles",
 
        "has_fake_identity",
 
        "short_description"
 
    ]
 
    if column in stored_records.columns
 
]
 """
""" if display_columns:
 
    print(
 
        stored_records[
 
            display_columns
 
        ].to_string(
 
            index=False
 
        )
 
    )
 
else:
 
    print(
 
        stored_records.to_string(
 
            index=False
 
        )
 
    )
 """
 
# ---------------------------------------------------------
 
# 17. Create Retriever
 
# ---------------------------------------------------------
 
retriever = vector_store.as_retriever(
 
    search_type="similarity",
 
    search_kwargs={
 
        "k": TOP_K
 
    }
 
)
 
 
# ---------------------------------------------------------
 
# 18. Create Answer Generation LLM
 
# ---------------------------------------------------------
 
llm = ChatOpenAI(
 
    model=CHAT_MODEL,
 
    temperature=0
 
)
 
 
# ---------------------------------------------------------
 
# 19. Create RAG Answer Prompt
 
# ---------------------------------------------------------
 
system_prompt = """
 
You are an assistant that answers questions about
 
Rajinikanth movies.
 
The retrieved context may contain:
 
1. Original movie content.
 
2. An LLM-generated concept category.
 
3. A multiple-roles indicator.
 
4. A fake-identity indicator.
 
5. A short LLM-generated description.
 
Use only the supplied retrieved context.
 
Instructions:
 
1. Do not use outside knowledge.
 
2. Do not invent movie names, roles, identities, or plot details.
 
3. Clearly distinguish multiple roles from fake identities.
 
4. Multiple roles means genuinely distinct characters or roles.
 
5. Fake identity means one actual character uses a disguise,
 
   alias, impersonation, or assumed identity.
 
6. A movie categorized as both contains both concepts.
 
7. Return movie names clearly when they are available.
 
8. Include a concise explanation for each matching movie.
 
9. If information is unavailable, say:
 
   I don't know based on the available movie data.
 
Retrieved Context:
 
{context}
 
"""
 
prompt = ChatPromptTemplate.from_messages(
 
    [
 
        (
 
            "system",
 
            system_prompt
 
        ),
 
        (
 
            "human",
 
            "{question}"
 
        )
 
    ]
 
)
 
 
# ---------------------------------------------------------
 
# 20. Ask Question
 
# ---------------------------------------------------------
 
def ask_question(
 
    question: str
 
) -> str:
 
    retrieved_docs = retriever.invoke(
 
        question
 
    )
 
    print("\n")
 
    print("=" * 80)
 
    print("RETRIEVED ENRICHED SECTIONS")
 
    print("=" * 80)
 
    if not retrieved_docs:
 
        print(
 
            "No sections were retrieved."
 
        )
 
        return (
 
            "I don't know based on the "
 
            "available movie data."
 
        )
 
    for index, doc in enumerate(
 
        retrieved_docs,
 
        start=1
 
    ):
 
        print("\n")
 
        print(
 
            f"Retrieved Section {index}"
 
        )
 
        print("-" * 80)
 
        print(
 
            doc.page_content[:600]
 
        )
 
        print("\nRetrieved Metadata:")
 
        print(
 
            doc.metadata
 
        )
 
    context = "\n\n".join(
 
        doc.page_content
 
        for doc in retrieved_docs
 
    )
 
    prompt_value = prompt.invoke(
 
        {
 
            "question": question,
 
            "context": context
 
        }
 
    )
 
    response = llm.invoke(
 
        prompt_value
 
    )
 
    return response.content
 
 
# ---------------------------------------------------------
 
# 21. Retrieval Tests
 
# ---------------------------------------------------------
 
test_questions = [
    (
        "Movies where Rajini played "
        "multiple characters?"
    ),
    (
        "Movies where Rajini played "
        "one role but faked other "
        "identities?"
    )
]
 
 
for question in test_questions:
 
    print("\n")
 
    print("=" * 80)
 
    print("QUESTION")
 
    print("=" * 80)
 
    print(question)
 
    answer = ask_question(
 
        question
 
    )
 
    print("\n")
 
    print("=" * 80)
 
    print("ANSWER")
 
    print("=" * 80)
 
    print(answer)
 
 
# ---------------------------------------------------------
 
# 22. Interactive Mode
 
# ---------------------------------------------------------
 
print("\n")
 
print("=" * 80)
 
print("INTERACTIVE MODE")
 
print("=" * 80)
 
print(
 
    "The vector database contains the original movie "
 
    "content together with LLM-generated concept analysis."
 
)
 
while True:
 
    question = input(
 
        "\nAsk Question (exit to quit): "
 
    ).strip()
 
    if question.lower() == "exit":
 
        break
 
    if not question:
 
        continue
 
    answer = ask_question(
 
        question
 
    )
 
    print("\nAnswer:\n")
 
    print(answer)
 
 
print("\nProgram Finished")
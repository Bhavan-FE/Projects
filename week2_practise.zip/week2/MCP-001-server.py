from fastmcp import FastMCP
import lancedb
import pandas as pd
 
# ------------------------------------------------------------------
# Configuration
# ------------------------------------------------------------------
 
LANCEDB_PATH = "./movies_lancedb"
 
db = lancedb.connect(LANCEDB_PATH)
 
mcp = FastMCP("LanceDB Explorer")
 
# ------------------------------------------------------------------
# Tool 1 : List Tables
# ------------------------------------------------------------------
 
@mcp.tool()
def list_tables():
 
    return db.table_names()
 
 
# ------------------------------------------------------------------
# Tool 2 : Show Records
# ------------------------------------------------------------------
 
@mcp.tool()
def show_records(
table_name: str,
limit: int = 20
):
 
    table = db.open_table(table_name)
 
    df = table.to_pandas().head(limit)
 
    return {
    "row_count": len(df),
    "columns": list(df.columns),
    "records": df.to_dict(orient="records")
    }
 
 
# ------------------------------------------------------------------
# Tool 3 : Search Records
# ------------------------------------------------------------------
 
@mcp.tool()
def search_records(
table_name: str,
query: str,
limit: int = 10
):
 
    table = db.open_table(table_name)
 
    results = (
    table
    .search(query)
    .limit(limit)
    .to_pandas()
    )
 
    return {
    "rows": len(results),
    "records": results.to_dict(
    orient="records"
    )
    }
 
 
# ------------------------------------------------------------------
# Tool 4 : Get Schema
# ------------------------------------------------------------------
 
@mcp.tool()
def get_schema(
table_name: str
):
 
    table = db.open_table(table_name)
 
    return str(table.schema)
 
 
if __name__ == "__main__":
    #mcp.run()
    #mcp.run(
    #transport="streamable-http",
    #host="0.0.0.0",
    #port=8000
    #)
    mcp.run(
    transport="sse",
    host="0.0.0.0",
    port=8000
    )
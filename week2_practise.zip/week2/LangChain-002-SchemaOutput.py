from pydantic import BaseModel, Field
from langchain_core.output_parsers import PydanticOutputParser
from langchain_core.prompts import PromptTemplate
from langchain_openai import ChatOpenAI
import os
from dotenv import load_dotenv
 
 
#load_dotenv(dotenv_path=os.path.join('..', '.env'))
load_dotenv()
assert os.environ.get('OPENAI_API_KEY'), (
    'OPENAI_API_KEY not found. Add it to the project-root .env file.'
)
 
# Step 1: Define output schema
class CountryInfo(BaseModel):
    capital: str = Field(
        description="Capital city of the country"
    )
    population: str = Field(
        description="Population of the country"
    )
 
 
# Step 2: Create parser
parser = PydanticOutputParser(
    pydantic_object=CountryInfo
)
 
# Step 3: Get formatting instructions
format_instructions = parser.get_format_instructions()
 
# Step 4: Create prompt
prompt = PromptTemplate(
    template="""
Answer the question.
 
{format_instructions}
 
Country: {country}
""",
    input_variables=["country"],
    partial_variables={
        "format_instructions": format_instructions
    }
)
 
# Step 5: Create LLM
llm = ChatOpenAI(
    model="gpt-4o-mini"
)
 
# Step 6: Chain
chain = prompt | llm | parser
 
# Step 7: Invoke
result = chain.invoke(
    {"country": "India"}
)
 
print(result)
print(type(result))
print(result.capital)
print(result.population)
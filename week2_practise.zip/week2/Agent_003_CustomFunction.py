import os
import requests
from bs4 import BeautifulSoup
 
from langchain_openai import ChatOpenAI
from langchain.tools import tool
from langchain.agents import create_tool_calling_agent
from langchain.agents import AgentExecutor
from langchain_core.prompts import ChatPromptTemplate
 
# ------------------------------------------------------------
# OpenAI Key Setup
# ------------------------------------------------------------
 
import os
from dotenv import load_dotenv
import anthropic
 
#load_dotenv(dotenv_path=os.path.join('..', '.env'))
load_dotenv()
assert os.environ.get('OPENAI_API_KEY'), (
    'OPENAI_API_KEY not found. Add it to the project-root .env file.'
)
 
# ------------------------------------------------------------
# Custom Tool
# ------------------------------------------------------------
 
@tool
def element_scraper(
    url: str = "https://ticketnew.com/movies/chennai"
) -> str:
    """
    Scrapes movie links from TicketNew Chennai website.
    """
 
    headers = {
        "User-Agent":
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
    }
 
    try:
        response = requests.get(
            url,
            headers=headers,
            timeout=10
        )
 
        response.raise_for_status()
 
        soup = BeautifulSoup(
            response.text,
            "html.parser"
        )
 
        movie_links = []
 
        for link in soup.find_all("a", href=True):
 
            href = link["href"]
 
            if "-movie-detail-" in href:
 
                full_url = (
                    href if href.startswith("http")
                    else f"https://ticketnew.com{href}"
                )
 
                movie_links.append(full_url)
 
        movie_links = list(set(movie_links))
 
        return "\n".join(movie_links)
 
    except Exception as e:
        return f"Error : {str(e)}"
 
# ------------------------------------------------------------
# LLM
# ------------------------------------------------------------
 
llm = ChatOpenAI(
    model="gpt-4o"
)
 
# ------------------------------------------------------------
# Prompt
# ------------------------------------------------------------
 
prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            """
You are a Local Cinema Analyst.
 
Responsibilities:
 
1. Find current movies running in Chennai.
2. Use available tools to discover movie URLs.
3. Identify theater name and theater address.
4. Estimate distance from:
 
   Cognizant SIPCOT IT Park
   Siruseri, Chennai.
 
Output Format:
 
- Movie Name
- Theater Name
- Theater Address
- Estimated Distance from Siruseri
"""
        ),
        ("human", "{input}"),
        ("placeholder", "{agent_scratchpad}")
    ]
)
 
# ------------------------------------------------------------
# Agent
# ------------------------------------------------------------
 
tools = [element_scraper]
 
agent = create_tool_calling_agent(
    llm=llm,
    tools=tools,
    prompt=prompt
)
 
agent_executor = AgentExecutor(
    agent=agent,
    tools=tools,
    verbose=True
)
 
# ------------------------------------------------------------
# Execute
# ------------------------------------------------------------
 
response = agent_executor.invoke(
    {
        "input":
        """
Find all Tamil movies currently available
in Chennai theaters near Cognizant Siruseri.
List movie name, theater name,
address and estimated distance.
        """
    }
)
 
print(response["output"])
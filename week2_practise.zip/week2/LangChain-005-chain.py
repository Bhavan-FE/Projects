from langchain_core.prompts import PromptTemplate
from langchain_openai import ChatOpenAI
import os
from dotenv import load_dotenv
load_dotenv()
 
llm = ChatOpenAI(
    model="gpt-4o-mini",
    temperature=0,
    api_key=os.environ.get("OPENAI_API_KEY")
)
 
prompt = PromptTemplate.from_template(
    "Tell me a {adjective} joke about {content}."
)
 
# Chain 1 using |
chain1 = prompt | llm
 
response1 = chain1.invoke({
    "adjective": "funny",
    "content": "chicken"
})
 
print("Chain 1 Output:")
print(response1.content)
 
 
# Chain 2 using .pipe()
chain2 = prompt.pipe(llm)
 
response2 = chain2.invoke({
    "adjective": "dark",
    "content": "football"
})
 
print("\nChain 2 Output:")
print(response2.content)
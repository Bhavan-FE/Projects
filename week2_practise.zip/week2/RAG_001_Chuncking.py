from pathlib import Path
import os
from dotenv import load_dotenv
import lancedb
from langchain_community.document_loaders import TextLoader
from langchain_community.vectorstores import LanceDB
from langchain_text_splitters import (RecursiveCharacterTextSplitter)
from langchain_openai import (ChatOpenAI,OpenAIEmbeddings)
from langchain_core.prompts import (ChatPromptTemplate)
# ---------------------------------------------------------
# 1. Load Environment Variables
# ---------------------------------------------------------
load_dotenv()
if not os.getenv("OPENAI_API_KEY"):
    raise EnvironmentError(
        "OPENAI_API_KEY not found in .env file")
# ---------------------------------------------------------
# 2. Configuration
# ---------------------------------------------------------
FILE_PATH = Path("Movies.txt")
CHAT_MODEL = "gpt-4o-mini"
EMBEDDING_MODEL = "text-embedding-3-small"
CHUNK_SIZE = 2500
CHUNK_OVERLAP = 250
TOP_K = 5
LANCEDB_FOLDER = "./movies_lancedb"
LANCEDB_TABLE = "movies"
# ---------------------------------------------------------
# 3. Validate File
# ---------------------------------------------------------
if not FILE_PATH.exists():
    raise FileNotFoundError(
        f"Movies file not found : "
        f"{FILE_PATH.resolve()}"
    )
# ---------------------------------------------------------
# 4. Load Movie File
# ---------------------------------------------------------
loader = TextLoader(
    file_path=str(FILE_PATH),
    encoding="utf-8"
)
documents = loader.load()
print("\n")
print("=" * 80)
print("DOCUMENT LOAD VERIFICATION")
print("=" * 80)
print(f"Documents Loaded : {len(documents)}")
print(f"Characters Loaded : "f"{len(documents[0].page_content)}")
print("\nPreview\n")
print(documents[0].page_content[:300])
# ---------------------------------------------------------
# 5. Chunk Documents
# ---------------------------------------------------------
text_splitter = RecursiveCharacterTextSplitter(chunk_size=CHUNK_SIZE,chunk_overlap=CHUNK_OVERLAP)
docs = text_splitter.split_documents(documents)
print("\n")
print("=" * 80)
print("CHUNK VERIFICATION")
print("=" * 80)
print(f"Chunks Created : {len(docs)}")
for i in range(min(5, len(docs))):
    print("\n")
    print("-" * 60)
    print(f"Chunk {i+1}")
    print("-" * 60)
    print(docs[i].page_content[:300])
# ---------------------------------------------------------
# 6. Create Embeddings
# ---------------------------------------------------------
embeddings = OpenAIEmbeddings(model=EMBEDDING_MODEL)
# ---------------------------------------------------------
# 7. Connect LanceDB
# ---------------------------------------------------------
db = lancedb.connect(LANCEDB_FOLDER)
# ---------------------------------------------------------
# 8. Create Vector Store
# ---------------------------------------------------------
vector_store = LanceDB.from_documents(
    documents=docs,
    embedding=embeddings,
    connection=db,
    table_name=LANCEDB_TABLE,
    mode="overwrite"
)
# ---------------------------------------------------------
# 9. Verification
# ---------------------------------------------------------
table = db.open_table(
    LANCEDB_TABLE
)
print("\n")
print("=" * 80)
print("LANCEDB VERIFICATION")
print("=" * 80)
print(f"Chunks Created : {len(docs)}")
print(f"LanceDB Rows   : "
    f"{table.count_rows()}")
# ---------------------------------------------------------
# 10. Retriever
# ---------------------------------------------------------
retriever = vector_store.as_retriever(
    search_type="similarity",
    search_kwargs={
        "k": TOP_K
    }
)
# ---------------------------------------------------------
# 11. LLM
# ---------------------------------------------------------
llm = ChatOpenAI(
    model=CHAT_MODEL,
    temperature=0
)
# ---------------------------------------------------------
# 12. Prompt
# ---------------------------------------------------------
system_prompt = """
You are an assistant that answers
questions about Rajinikanth movies.
Use only the supplied context.
Instructions:
1. Use only retrieved context.
2. Do not invent facts.
3. If information is unavailable say:
   I don't know based on the available movie data.
4. Return movie names clearly.
5. Keep answers concise.
Retrieved Context:
{context}
"""
prompt = ChatPromptTemplate.from_messages(
    [
        ("system", system_prompt),
        ("human", "{question}")
    ]
)
# ---------------------------------------------------------
# 13. Ask Question
# ---------------------------------------------------------
def ask_question(
    question: str
) -> str:
    retrieved_docs = retriever.invoke(
        question
    )
    print("\n")
    print("=" * 80)
    print("RETRIEVED CHUNKS")
    print("=" * 80)
    for index, doc in enumerate(
        retrieved_docs,
        start=1
    ):
        print("\n")
        print(
            f"Chunk {index}"
        )
        print("-" * 60)
        print(
            doc.page_content[:250]
        )
    context = "\n\n".join(
        doc.page_content
        for doc in retrieved_docs
    )
    prompt_value = prompt.invoke(
        {
            "question": question,
            "context": context
        }
    )
    response = llm.invoke(
        prompt_value
    )
    return response.content
# ---------------------------------------------------------
# 14. Retrieval Test
# ---------------------------------------------------------
test_questions = [
    (
        "Movies where Rajini played "
        "multiple characters?"
    ),
    (
        "Movies where Rajini played "
        "one role but faked other "
        "identities?"
    )
]
 
for question in test_questions:
    print("\n")
    print("=" * 80)
    print("QUESTION")
    print("=" * 80)
    print(question)
    answer = ask_question(
        question
    )
    print("\n")
    print("=" * 80)
    print("ANSWER")
    print("=" * 80)
    print(answer)
# ---------------------------------------------------------
# 15. Interactive Mode
# ---------------------------------------------------------
print("\n")
print("=" * 80)
print("INTERACTIVE MODE")
print("=" * 80)
while True:
    question = input(
        "\nAsk Question (exit to quit): "
    ).strip()
    if question.lower() == "exit":
        break
    if not question:
        continue
    answer = ask_question(
        question
    )
    print("\nAnswer:\n")
    print(answer)
print("\nProgram Finished")
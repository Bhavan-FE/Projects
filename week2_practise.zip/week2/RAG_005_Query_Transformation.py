from pathlib import Path
 
from typing import List
 
from collections import defaultdict
 
import hashlib
 
import os
 
import re
 
from dotenv import load_dotenv
 
from pydantic import BaseModel, Field
 
import lancedb
 
from langchain_community.document_loaders import TextLoader
 
from langchain_community.vectorstores import LanceDB
 
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
 
from langchain_core.prompts import ChatPromptTemplate
 
from langchain_core.documents import Document
 
 
# ---------------------------------------------------------
 
# Structured output models
 
# ---------------------------------------------------------
 
class RewrittenQuery(BaseModel):
 
    rewritten_query: str = Field(
 
        description="One retrieval-friendly rewrite of the original question."
 
    )
 
 
class StepBackQuery(BaseModel):
 
    step_back_query: str = Field(
 
        description="One broader conceptual retrieval question."
 
    )
 
 
class SubQueryCollection(BaseModel):
 
    sub_queries: List[str] = Field(
 
        description="Focused and independently searchable sub-queries."
 
    )
 
 
class ExpandedQueryCollection(BaseModel):
 
    expanded_queries: List[str] = Field(
 
        description="Alternative search queries preserving the original intent."
 
    )
 
 
# ---------------------------------------------------------
 
# 1. Load environment variables
 
# ---------------------------------------------------------
 
load_dotenv()
 
if not os.getenv("OPENAI_API_KEY"):
 
    raise EnvironmentError("OPENAI_API_KEY not found in .env file")
 
 
# ---------------------------------------------------------
 
# 2. Configuration
 
# ---------------------------------------------------------
 
FILE_PATH = Path("Movies.txt")
 
CHAT_MODEL = "gpt-4o-mini"
 
EMBEDDING_MODEL = "text-embedding-3-small"
 
LANCEDB_FOLDER = "./movies_query_transformation_lancedb"
 
LANCEDB_TABLE = "movies_raw_sections"
 
RESULTS_PER_QUERY = 5
 
FINAL_TOP_K = 8
 
QUERY_EXPANSION_COUNT = 4
 
RRF_K = 60
 
ENABLE_ORIGINAL_QUERY = True
 
ENABLE_QUERY_REWRITE = True
 
ENABLE_STEP_BACK = True
 
ENABLE_SUB_QUERY_DECOMPOSITION = True
 
ENABLE_QUERY_EXPANSION = True
 
RUN_BASELINE_COMPARISON = True
 
RUN_TEST_QUESTIONS = True
 
 
# ---------------------------------------------------------
 
# 3. Validate input file
 
# ---------------------------------------------------------
 
if not FILE_PATH.exists():
 
    raise FileNotFoundError(
 
        f"Movies file not found: {FILE_PATH.resolve()}"
 
    )
 
 
# ---------------------------------------------------------
 
# 4. Load movie file
 
# ---------------------------------------------------------
 
loader = TextLoader(
 
    file_path=str(FILE_PATH),
 
    encoding="utf-8"
 
)
 
documents = loader.load()
 
if not documents:
 
    raise ValueError("Movies.txt was loaded, but no document was returned.")
 
raw_content = documents[0].page_content
 
if not raw_content.strip():
 
    raise ValueError("Movies.txt is empty.")
 
print("\n")
 
print("=" * 80)
 
print("DOCUMENT LOAD VERIFICATION")
 
print("=" * 80)
 
print(f"Documents Loaded  : {len(documents)}")
 
print(f"Characters Loaded : {len(raw_content)}")
 
print("\nPreview\n")
 
print(raw_content[:1000])
 
 
# ---------------------------------------------------------
 
# 5. Normalize line endings
 
# ---------------------------------------------------------
 
normalized_content = (
 
    raw_content
 
    .replace("\r\n", "\n")
 
    .replace("\r", "\n")
 
)
 
 
# ---------------------------------------------------------
 
# 6. Split content using empty-line separators
 
# ---------------------------------------------------------
 
# No chunk size, overlap, proposition chunking, ingestion-time
 
# LLM analysis, descriptions, summaries, or generated context.
 
sections = [
 
    section.strip()
 
    for section in re.split(r"\n\s*\n", normalized_content)
 
    if section.strip()
 
]
 
if not sections:
 
    raise ValueError("No non-empty movie sections were found.")
 
 
def create_section_id(section_number: int, section_content: str) -> str:
 
    value = f"{section_number}|{section_content}"
 
    return hashlib.sha256(value.encode("utf-8")).hexdigest()[:16]
 
 
raw_docs = []
 
for section_number, section in enumerate(sections, start=1):
 
    raw_docs.append(
 
        Document(
 
            page_content=section,
 
            metadata={
 
                "section_id": create_section_id(section_number, section),
 
                "section_number": section_number,
 
                "source": str(FILE_PATH),
 
                "chunking_strategy": "empty_line_separator",
 
                "content_enrichment": "none",
 
                "proposition_chunking": False
 
            }
 
        )
 
    )
 
print("\n")
 
print("=" * 80)
 
print("RAW SECTION VERIFICATION")
 
print("=" * 80)
 
print(f"Raw Sections Created : {len(raw_docs)}")
 
for index, doc in enumerate(raw_docs[:5], start=1):
 
    print("\n")
 
    print("-" * 80)
 
    print(f"Raw Section {index}")
 
    print("-" * 80)
 
    print(doc.page_content[:500])
 
    print("\nMetadata")
 
    print(doc.metadata)
 
 
# ---------------------------------------------------------
 
# 7. Create embeddings and store raw sections in LanceDB
 
# ---------------------------------------------------------
 
embeddings = OpenAIEmbeddings(model=EMBEDDING_MODEL)
 
db = lancedb.connect(LANCEDB_FOLDER)
 
vector_store = LanceDB.from_documents(
 
    documents=raw_docs,
 
    embedding=embeddings,
 
    connection=db,
 
    table_name=LANCEDB_TABLE,
 
    mode="overwrite"
 
)
 
table = db.open_table(LANCEDB_TABLE)
 
stored_row_count = table.count_rows()
 
print("\n")
 
print("=" * 80)
 
print("LANCEDB VERIFICATION")
 
print("=" * 80)
 
print(f"Raw Documents : {len(raw_docs)}")
 
print(f"LanceDB Rows  : {stored_row_count}")
 
if stored_row_count == len(raw_docs):
 
    print("Verification successful. Every raw section was stored.")
 
else:
 
    print("Warning: LanceDB row count does not match raw document count.")
 
print("\n")
 
print("=" * 80)
 
print("LANCEDB RAW DATA SAMPLE")
 
print("=" * 80)
 
""" stored_records = table.to_pandas().head(5)
 
display_columns = [
 
    column
 
    for column in [
 
        "section_id",
 
        "section_number",
 
        "source",
 
        "chunking_strategy",
 
        "content_enrichment",
 
        "proposition_chunking",
 
        "text"
 
    ]
 
    if column in stored_records.columns
 
]
 
if display_columns:
 
    print(stored_records[display_columns].to_string(index=False))
 
else:
 
    print(stored_records.to_string(index=False))
 
 
# ---------------------------------------------------------
 
 """
 # 8. Create base retriever and query-time LLM
 
# ---------------------------------------------------------
 
base_retriever = vector_store.as_retriever(
 
    search_type="similarity",
 
    search_kwargs={"k": RESULTS_PER_QUERY}
 
)
 
query_llm = ChatOpenAI(
 
    model=CHAT_MODEL,
 
    temperature=0
 
)
 
 
# ---------------------------------------------------------
 
# 9. Query rewriting chain
 
# ---------------------------------------------------------
 
query_rewrite_prompt = ChatPromptTemplate.from_messages(
 
    [
 
        (
 
            "system",
 
            """
 
Rewrite the user's question for semantic retrieval from a
 
Rajinikanth movie vector database.
 
Rules:
 
1. Preserve the exact user intent.
 
2. Produce one retrieval-friendly question.
 
3. Make implicit movie concepts explicit.
 
4. Use relevant alternate terminology.
 
5. Distinguish multiple roles from fake identities.
 
6. Do not answer the question.
 
7. Do not add movie names or factual movie information.
 
8. Do not use outside movie knowledge.
 
Multiple roles means the actor plays two or more genuinely distinct
 
characters or roles. Fake identity means one actual character uses a
 
disguise, alias, impersonation, or assumed identity.
 
"""
 
        ),
 
        ("human", "Original Question:\n\n{question}")
 
    ]
 
)
 
query_rewrite_chain = (
 
    query_rewrite_prompt
 
    | query_llm.with_structured_output(RewrittenQuery)
 
)
 
 
# ---------------------------------------------------------
 
# 10. Step-back query chain
 
# ---------------------------------------------------------
 
step_back_prompt = ChatPromptTemplate.from_messages(
 
    [
 
        (
 
            "system",
 
            """
 
Generate one broader conceptual search question from the supplied
 
movie question.
 
Rules:
 
1. Preserve the original topic.
 
2. Make the question more general.
 
3. Do not answer the question.
 
4. Do not add movie names or factual movie information.
 
5. Do not use outside movie knowledge.
 
6. Focus on roles, characters, disguises, aliases,
 
   impersonations, or identities.
 
"""
 
        ),
 
        ("human", "Original Question:\n\n{question}")
 
    ]
 
)
 
step_back_chain = (
 
    step_back_prompt
 
    | query_llm.with_structured_output(StepBackQuery)
 
)
 
 
# ---------------------------------------------------------
 
# 11. Sub-query decomposition chain
 
# ---------------------------------------------------------
 
sub_query_prompt = ChatPromptTemplate.from_messages(
 
    [
 
        (
 
            "system",
 
            """
 
Break the supplied movie question into focused, independently
 
searchable sub-queries.
 
Rules:
 
1. Preserve the original intent.
 
2. Each sub-query must have one retrieval objective.
 
3. Separate multiple-role and fake-identity questions when needed.
 
4. Return between one and four sub-queries.
 
5. Do not answer the sub-queries.
 
6. Do not add movie names or factual movie information.
 
7. Do not use outside movie knowledge.
 
8. Do not create duplicates.
 
"""
 
        ),
 
        ("human", "Original Question:\n\n{question}")
 
    ]
 
)
 
sub_query_chain = (
 
    sub_query_prompt
 
    | query_llm.with_structured_output(SubQueryCollection)
 
)
 
 
# ---------------------------------------------------------
 
# 12. Query expansion chain
 
# ---------------------------------------------------------
 
query_expansion_prompt = ChatPromptTemplate.from_messages(
 
    [
 
        (
 
            "system",
 
            f"""
 
Generate up to {QUERY_EXPANSION_COUNT} alternate semantic search
 
queries for a Rajinikanth movie database.
 
Rules:
 
1. Preserve the original intent.
 
2. Use alternate vocabulary and useful synonyms.
 
3. Keep each query independently searchable.
 
4. Distinguish multiple roles from fake identities.
 
5. Do not answer the question.
 
6. Do not add movie names or factual movie information.
 
7. Do not use outside movie knowledge.
 
8. Do not create duplicates.
 
Possible terminology:
 
- Multiple roles: multiple characters, dual roles, triple roles,
 
  distinct characters, several characters.
 
- Fake identity: false identity, assumed identity, alias, disguise,
 
  impersonation, pretended to be another person.
 
"""
 
        ),
 
        ("human", "Original Question:\n\n{question}")
 
    ]
 
)
 
query_expansion_chain = (
 
    query_expansion_prompt
 
    | query_llm.with_structured_output(ExpandedQueryCollection)
 
)
 
 
# ---------------------------------------------------------
 
# 13. Query transformation helpers
 
# ---------------------------------------------------------
 
def normalize_query(query: str) -> str:
 
    normalized = re.sub(r"\s+", " ", query.lower().strip())
 
    return re.sub(r"[^\w\s]", "", normalized)
 
 
def add_unique_query(
 
    query_entries: List[dict],
 
    seen_queries: set,
 
    query_text: str,
 
    transformation_type: str
 
) -> None:
 
    cleaned_query = query_text.strip()
 
    if not cleaned_query:
 
        return
 
    normalized = normalize_query(cleaned_query)
 
    if not normalized or normalized in seen_queries:
 
        return
 
    seen_queries.add(normalized)
 
    query_entries.append(
 
        {
 
            "query": cleaned_query,
 
            "transformation": transformation_type
 
        }
 
    )
 
 
def transform_query(question: str) -> List[dict]:
 
    query_entries = []
 
    seen_queries = set()
 
    if ENABLE_ORIGINAL_QUERY:
 
        add_unique_query(
 
            query_entries,
 
            seen_queries,
 
            question,
 
            "original_query"
 
        )
 
    if ENABLE_QUERY_REWRITE:
 
        try:
 
            result = query_rewrite_chain.invoke({"question": question})
 
            add_unique_query(
 
                query_entries,
 
                seen_queries,
 
                result.rewritten_query,
 
                "query_rewrite"
 
            )
 
        except Exception as error:
 
            print(f"\nQuery rewrite failed: {error}")
 
    if ENABLE_STEP_BACK:
 
        try:
 
            result = step_back_chain.invoke({"question": question})
 
            add_unique_query(
 
                query_entries,
 
                seen_queries,
 
                result.step_back_query,
 
                "step_back_query"
 
            )
 
        except Exception as error:
 
            print(f"\nStep-back query generation failed: {error}")
 
    if ENABLE_SUB_QUERY_DECOMPOSITION:
 
        try:
 
            result = sub_query_chain.invoke({"question": question})
 
            for sub_query in result.sub_queries[:4]:
 
                add_unique_query(
 
                    query_entries,
 
                    seen_queries,
 
                    sub_query,
 
                    "sub_query"
 
                )
 
        except Exception as error:
 
            print(f"\nSub-query decomposition failed: {error}")
 
    if ENABLE_QUERY_EXPANSION:
 
        try:
 
            result = query_expansion_chain.invoke({"question": question})
 
            for expanded_query in result.expanded_queries[:QUERY_EXPANSION_COUNT]:
 
                add_unique_query(
 
                    query_entries,
 
                    seen_queries,
 
                    expanded_query,
 
                    "query_expansion"
 
                )
 
        except Exception as error:
 
            print(f"\nQuery expansion failed: {error}")
 
    if not query_entries:
 
        add_unique_query(
 
            query_entries,
 
            seen_queries,
 
            question,
 
            "original_query_fallback"
 
        )
 
    return query_entries
 
 
# ---------------------------------------------------------
 
# 14. Reciprocal Rank Fusion
 
# ---------------------------------------------------------
 
def get_document_key(doc: Document) -> str:
 
    section_id = doc.metadata.get("section_id")
 
    if section_id:
 
        return str(section_id)
 
    return hashlib.sha256(
 
        doc.page_content.encode("utf-8")
 
    ).hexdigest()[:16]
 
 
def reciprocal_rank_fusion(
 
    ranked_result_sets: List[dict],
 
    rrf_k: int = RRF_K
 
) -> List[dict]:
 
    fused_scores = defaultdict(float)
 
    document_map = {}
 
    query_matches = defaultdict(list)
 
    rank_evidence = defaultdict(list)
 
    transformation_evidence = defaultdict(set)
 
    for result_set in ranked_result_sets:
 
        query_text = result_set["query"]
 
        transformation_type = result_set["transformation"]
 
        for rank, doc in enumerate(result_set["documents"], start=1):
 
            document_key = get_document_key(doc)
 
            document_map[document_key] = doc
 
            fused_scores[document_key] += 1.0 / (rrf_k + rank)
 
            rank_evidence[document_key].append(rank)
 
            transformation_evidence[document_key].add(transformation_type)
 
            query_matches[document_key].append(
 
                {
 
                    "query": query_text,
 
                    "transformation": transformation_type,
 
                    "rank": rank
 
                }
 
            )
 
    sorted_keys = sorted(
 
        fused_scores,
 
        key=fused_scores.get,
 
        reverse=True
 
    )
 
    return [
 
        {
 
            "document": document_map[key],
 
            "document_key": key,
 
            "rrf_score": fused_scores[key],
 
            "fused_rank": fused_rank,
 
            "query_matches": query_matches[key],
 
            "retrieval_count": len(query_matches[key]),
 
            "individual_ranks": rank_evidence[key],
 
            "transformation_types": sorted(transformation_evidence[key])
 
        }
 
        for fused_rank, key in enumerate(sorted_keys, start=1)
 
    ]
 
 
# ---------------------------------------------------------
 
# 15. Retrieval functions
 
# ---------------------------------------------------------
 
def retrieve_baseline(question: str) -> List[Document]:
 
    return base_retriever.invoke(question)
 
 
def retrieve_with_transformations(
 
    question: str
 
) -> tuple[List[dict], List[dict]]:
 
    transformed_queries = transform_query(question)
 
    ranked_result_sets = []
 
    for query_entry in transformed_queries:
 
        retrieved_docs = base_retriever.invoke(query_entry["query"])
 
        ranked_result_sets.append(
 
            {
 
                "query": query_entry["query"],
 
                "transformation": query_entry["transformation"],
 
                "documents": retrieved_docs
 
            }
 
        )
 
    fused_results = reciprocal_rank_fusion(
 
        ranked_result_sets=ranked_result_sets,
 
        rrf_k=RRF_K
 
    )
 
    return transformed_queries, fused_results[:FINAL_TOP_K]
 
 
# ---------------------------------------------------------
 
# 16. Display functions
 
# ---------------------------------------------------------
 
def print_transformed_queries(transformed_queries: List[dict]) -> None:
 
    print("\n")
 
    print("=" * 80)
 
    print("GENERATED RETRIEVAL QUERIES")
 
    print("=" * 80)
 
    for index, entry in enumerate(transformed_queries, start=1):
 
        print("\n")
 
        print(f"Query {index}")
 
        print(f"Transformation : {entry['transformation']}")
 
        print(f"Query Text     : {entry['query']}")
 
 
def print_baseline_results(baseline_docs: List[Document]) -> None:
 
    print("\n")
 
    print("=" * 80)
 
    print("BASELINE DIRECT-QUERY RETRIEVAL")
 
    print("=" * 80)
 
    if not baseline_docs:
 
        print("No baseline documents were retrieved.")
 
        return
 
    for rank, doc in enumerate(baseline_docs, start=1):
 
        print("\n")
 
        print("-" * 80)
 
        print(f"Baseline Rank : {rank}")
 
        print(f"Section       : {doc.metadata.get('section_number')}")
 
        print(f"Section ID    : {doc.metadata.get('section_id')}")
 
        print("-" * 80)
 
        print(doc.page_content[:800])
 
 
def print_fused_results(fused_results: List[dict]) -> None:
 
    print("\n")
 
    print("=" * 80)
 
    print("QUERY TRANSFORMATION RRF RESULTS")
 
    print("=" * 80)
 
    if not fused_results:
 
        print("No transformed-query documents were retrieved.")
 
        return
 
    for result in fused_results:
 
        doc = result["document"]
 
        print("\n")
 
        print("-" * 80)
 
        print(f"Fused Rank           : {result['fused_rank']}")
 
        print(f"RRF Score            : {result['rrf_score']:.6f}")
 
        print(f"Retrieval Hits       : {result['retrieval_count']}")
 
        print(f"Individual Ranks     : {result['individual_ranks']}")
 
        print(f"Transformation Types : {result['transformation_types']}")
 
        print(f"Section              : {doc.metadata.get('section_number')}")
 
        print(f"Section ID           : {doc.metadata.get('section_id')}")
 
        print("\nMatched Through")
 
        for match in result["query_matches"]:
 
            print(
 
                f"  - {match['transformation']} at rank {match['rank']}: "
 
                f"{match['query']}"
 
            )
 
        print("\nRetrieved Content")
 
        print(doc.page_content[:1000])
 
 
def compare_retrieval_results(
 
    baseline_docs: List[Document],
 
    fused_results: List[dict]
 
) -> None:
 
    baseline_keys = [get_document_key(doc) for doc in baseline_docs]
 
    transformed_keys = [result["document_key"] for result in fused_results]
 
    baseline_set = set(baseline_keys)
 
    transformed_set = set(transformed_keys)
 
    common_keys = baseline_set.intersection(transformed_set)
 
    transformation_only = [
 
        key for key in transformed_keys if key not in baseline_set
 
    ]
 
    baseline_only = [
 
        key for key in baseline_keys if key not in transformed_set
 
    ]
 
    print("\n")
 
    print("=" * 80)
 
    print("RETRIEVAL COMPARISON")
 
    print("=" * 80)
 
    print(f"Baseline Retrieved        : {len(baseline_docs)}")
 
    print(f"Transformed/Fused Results : {len(fused_results)}")
 
    print(f"Common Results            : {len(common_keys)}")
 
    print(f"Transformation-Only       : {len(transformation_only)}")
 
    print(f"Baseline-Only             : {len(baseline_only)}")
 
    print(f"\nBaseline Section IDs      : {baseline_keys}")
 
    print(f"Transformed Section IDs   : {transformed_keys}")
 
    print(f"Transformation-Only IDs   : {transformation_only}")
 
    print(f"Baseline-Only IDs         : {baseline_only}")
 
 
# ---------------------------------------------------------
 
# 17. Final grounded answer generation
 
# ---------------------------------------------------------
 
answer_llm = ChatOpenAI(
 
    model=CHAT_MODEL,
 
    temperature=0
 
)
 
answer_system_prompt = """
 
Answer questions about Rajinikanth movies using only the retrieved raw
 
movie sections. The stored content has no LLM-generated descriptions,
 
concepts, summaries, generated context, or proposition chunks.
 
Rules:
 
1. Use only the retrieved raw movie content.
 
2. Do not use outside movie knowledge.
 
3. Do not invent movie names, character names, roles, disguises,
 
   aliases, identities, or plot details.
 
4. Multiple roles means genuinely distinct characters or roles.
 
5. Fake identity means one actual character uses a disguise, alias,
 
   impersonation, or assumed identity.
 
6. Mark a movie as containing both only when the source supports both.
 
7. Group matching information by movie.
 
8. Give a short grounded description for each matching movie.
 
9. Do not include a movie merely because it was retrieved.
 
10. Remove duplicate information and keep the answer concise.
 
11. If the retrieved content does not contain the answer, say:
 
    I don't know based on the available movie data.
 
Retrieved Raw Movie Sections:
 
{context}
 
"""
 
answer_prompt = ChatPromptTemplate.from_messages(
 
    [
 
        ("system", answer_system_prompt),
 
        ("human", "{question}")
 
    ]
 
)
 
 
def build_fused_context(fused_results: List[dict]) -> str:
 
    context_items = []
 
    seen_section_ids = set()
 
    for result in fused_results:
 
        doc = result["document"]
 
        section_id = str(doc.metadata.get("section_id", ""))
 
        if section_id and section_id in seen_section_ids:
 
            continue
 
        if section_id:
 
            seen_section_ids.add(section_id)
 
        context_items.append(
 
            f"""
 
Section Number:
 
{doc.metadata.get('section_number')}
 
Section ID:
 
{doc.metadata.get('section_id')}
 
Raw Movie Content:
 
{doc.page_content}
 
""".strip()
 
        )
 
    return "\n\n".join(context_items)
 
 
def generate_answer(question: str, fused_results: List[dict]) -> str:
 
    if not fused_results:
 
        return "I don't know based on the available movie data."
 
    response = answer_llm.invoke(
 
        answer_prompt.invoke(
 
            {
 
                "question": question,
 
                "context": build_fused_context(fused_results)
 
            }
 
        )
 
    )
 
    return response.content
 
 
# ---------------------------------------------------------
 
# 18. Complete RAG execution
 
# ---------------------------------------------------------
 
def ask_question(question: str) -> str:
 
    baseline_docs = []
 
    if RUN_BASELINE_COMPARISON:
 
        baseline_docs = retrieve_baseline(question)
 
        print_baseline_results(baseline_docs)
 
    transformed_queries, fused_results = retrieve_with_transformations(
 
        question
 
    )
 
    print_transformed_queries(transformed_queries)
 
    print_fused_results(fused_results)
 
    if RUN_BASELINE_COMPARISON:
 
        compare_retrieval_results(
 
            baseline_docs=baseline_docs,
 
            fused_results=fused_results
 
        )
 
    return generate_answer(
 
        question=question,
 
        fused_results=fused_results
 
    )
 
 
# ---------------------------------------------------------
 
# 19. Test questions
 
# ---------------------------------------------------------
 
test_questions = [
 
    (
 
        "Movies where Rajini played "
 
        "multiple characters?"
 
    ),
 
    (
 
        "Movies where Rajini played "
 
        "one role but faked other "
 
        "identities?"
 
    )
 
]
 
if RUN_TEST_QUESTIONS:
 
    for question in test_questions:
 
        print("\n")
 
        print("#" * 80)
 
        print("TEST QUESTION")
 
        print("#" * 80)
 
        print(question)
 
        try:
 
            answer = ask_question(question)
 
            print("\n")
 
            print("=" * 80)
 
            print("FINAL ANSWER")
 
            print("=" * 80)
 
            print(answer)
 
        except Exception as error:
 
            print("\n")
 
            print("=" * 80)
 
            print("QUESTION PROCESSING ERROR")
 
            print("=" * 80)
 
            print(f"Question: {question}")
 
            print(f"Reason: {error}")
 
 
# ---------------------------------------------------------
 
# 20. Interactive mode
 
# ---------------------------------------------------------
 
print("\n")
 
print("=" * 80)
 
print("QUERY TRANSFORMATION RAG")
 
print("=" * 80)
 
print("LanceDB contains only raw empty-line-separated movie sections.")
 
print("No ingestion-time LLM content enrichment was performed.")
 
print("No proposition chunking was performed.")
 
print(f"Original Query          : {ENABLE_ORIGINAL_QUERY}")
 
print(f"Query Rewrite           : {ENABLE_QUERY_REWRITE}")
 
print(f"Step-Back Query         : {ENABLE_STEP_BACK}")
 
print(f"Sub-Query Decomposition : {ENABLE_SUB_QUERY_DECOMPOSITION}")
 
print(f"Query Expansion         : {ENABLE_QUERY_EXPANSION}")
 
print(f"Baseline Comparison     : {RUN_BASELINE_COMPARISON}")
 
while True:
 
    question = input("\nAsk Question (exit to quit): ").strip()
 
    if question.lower() == "exit":
 
        break
 
    if not question:
 
        continue
 
    try:
 
        answer = ask_question(question)
 
        print("\n")
 
        print("=" * 80)
 
        print("FINAL ANSWER")
 
        print("=" * 80)
 
        print(answer)
 
    except Exception as error:
 
        print("\n")
 
        print("=" * 80)
 
        print("ERROR")
 
        print("=" * 80)
 
        print("Unable to process the question.")
 
        print(f"Reason: {error}")
 
print("\n")
 
print("=" * 80)
 
print("PROGRAM FINISHED")
 
print("=" * 80)
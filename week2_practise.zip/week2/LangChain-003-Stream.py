from pydantic import BaseModel, Field
from langchain_core.output_parsers import PydanticOutputParser
from langchain_core.prompts import PromptTemplate
from langchain_openai import ChatOpenAI
import os
from dotenv import load_dotenv
 
 
#load_dotenv(dotenv_path=os.path.join('..', '.env'))
load_dotenv()
assert os.environ.get('OPENAI_API_KEY'), (
    'OPENAI_API_KEY not found. Add it to the project-root .env file.'
)
from langchain_openai import ChatOpenAI
 
llm = ChatOpenAI(
    model="gpt-4o-mini",
    temperature=0,
    max_tokens=None,
    timeout=None,
    max_retries=2,
    api_key= os.environ.get('OPENAI_API_KEY'),  # if you prefer to pass api key in directly instaed of using env vars
)
 
for chunk in llm.stream(
    "what will be future AI market?."
):
    print(chunk.content, end="", flush=True)